"use strict";
const electron = require("electron");
const preload = require("@electron-toolkit/preload");
const os = require("os");
const IpcStoreRouteDefinitions = {
  "get-current-user-data": async () => null,
  "get-canvas-current-user-data": async () => null,
  "get-current-canvas-host": async () => null,
  "get-app-state": async () => null,
  /**
   * *******************************
   * Course Queries
   * *******************************
   */
  "get-all-courses": async () => [],
  "get-main-courses": async () => [],
  "get-course-by-id": async (courseId) => null,
  "update-course-by-id": async (courseId, params) => {
  },
  /**
   * *******************************
   * Assignment Queries
   * *******************************
   */
  "get-course-assignments": async (courseId) => [],
  "get-course-assignments-summary": async (courseId) => null,
  "get-assignments": async (options) => [],
  "get-assignment-by-id": async (id) => null,
  "update-assignment-by-id": async (id, data) => {
  },
  /**
   * *******************************
   * Announcement Queries
   * *******************************
   */
  "get-announcements": async (options) => [],
  "get-announcement-by-id": async (id) => null,
  /**
   * *******************************
   * Planner Queries
   * *******************************
   */
  "get-planner-items": async (options) => [],
  "update-planner-item": async (id, data) => {
  },
  /**
   * *******************************
   * File & Folder Queries
   * *******************************
   */
  "get-course-root-folder-id": async (courseId) => null,
  "get-items-by-folder-id": async (folderId) => {
    return {
      parentFolders: [],
      files: [],
      folders: []
    };
  },
  /**
   * *******************************
   * Search Queries
   * *******************************
   */
  "search-items": async (query) => {
    return {
      assignments: [],
      files: [],
      courses: []
    };
  },
  /**
   * *******************************
   * Settings Queries
   * *******************************
   */
  "save-settings": async (data) => {
  },
  "save-canvas-data": async (data) => {
  }
};
const IpcNavRouteDefinitions = {
  "to-canvas-login": async (hostname) => {
  },
  // "open-link-as-new-window": async (url: string): Promise<void> => {},
  "open-external": async (url) => {
  },
  "close-window": async () => {
  },
  "minimize-window": async () => {
  },
  "maximize-window": async () => {
  },
  /**
   * *******************************
   * U
   * *******************************
   */
  "show-notification": async (params) => {
  }
};
const IpcAPIRouteDefinitions = {
  "fetch-main-courses": async () => [],
  "fetch-all-student-courses": async () => [],
  "fetch-course-data": async (courseId) => {
  },
  "fetch-course-data-latest": async (courseId) => {
  },
  "fetch-home-info": async () => null,
  "fetch-course-assignments": async (courseId) => [],
  "fetch-course-announcements": async (courseId) => [],
  "fetch-course-syllabus": async (courseId) => "",
  "fetch-course-pages": async (courseId) => [],
  "fetch-assignment-detail": async (assignmentId) => null,
  logout: async () => {
  },
  "fetch-course-files": async (courseId) => {
    return {
      files: [],
      folders: [],
      rootFolderId: 0
    };
  },
  "set-course-color": async (courseId, color) => {
  },
  "set-course-favorite": async (courseId, isFavorite) => {
  },
  "fetch-main-course-data": async () => {
  },
  "quick-refresh": async () => {
  },
  "search-universities-by-name": async (name) => [],
  "search-universities-by-domain": async (domain) => [],
  "mark-discussion-as-read": async (discussionId) => {
  },
  "download-file": async (fileId) => null
};
const IpcMainEventDefinitions = {
  "show-message": async (message, options) => {
  },
  "db-update": async (type, data) => {
  }
};
const api = {};
for (const route of Object.keys(IpcAPIRouteDefinitions)) {
  api[route] = (...args) => {
    return electron.ipcRenderer.invoke(route, ...args);
  };
}
for (const route of Object.keys(IpcStoreRouteDefinitions)) {
  api[route] = (...args) => {
    return electron.ipcRenderer.invoke(route, ...args);
  };
}
for (const route of Object.keys(IpcNavRouteDefinitions)) {
  api[route] = (...args) => {
    return electron.ipcRenderer.invoke(route, ...args);
  };
}
const toCamelCase = (str) => str.replace(/-./g, (match) => match[1].toUpperCase());
const mainEvents = Object.fromEntries(
  Object.keys(IpcMainEventDefinitions).map((eventName) => [
    `on${toCamelCase(eventName.charAt(0).toUpperCase() + eventName.slice(1))}`,
    (callback) => {
      electron.ipcRenderer.on(eventName, (_, payload) => callback(payload));
    }
  ])
);
if (process.contextIsolated) {
  try {
    electron.contextBridge.exposeInMainWorld("electron", preload.electronAPI);
    electron.contextBridge.exposeInMainWorld("api", api);
    electron.contextBridge.exposeInMainWorld("mainEvents", mainEvents);
    electron.contextBridge.exposeInMainWorld("platformInfo", {
      os: os.platform(),
      arch: os.arch(),
      release: os.release(),
      version: os.version(),
      hostname: os.hostname(),
      userInfo: os.userInfo(),
      networkInterfaces: os.networkInterfaces()
    });
  } catch (error) {
    console.error(error);
  }
} else {
  window.electron = preload.electronAPI;
  window.api = api;
}
