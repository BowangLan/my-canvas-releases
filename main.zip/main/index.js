"use strict";
const electron = require("electron");
const utils = require("@electron-toolkit/utils");
const require$$1 = require("path");
const fs = require("fs");
const jsdom = require("jsdom");
require("date-fns");
const Database = require("better-sqlite3");
const posthogNode = require("posthog-node");
const crypto = require("crypto");
const electronUpdater = require("electron-updater");
const log = require("electron-log/main");
require("unzipper");
require("axios");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const require$$1__namespace = /* @__PURE__ */ _interopNamespaceDefault(require$$1);
const fs__namespace = /* @__PURE__ */ _interopNamespaceDefault(fs);
const icon = require$$1.join(__dirname, "../../resources/icon.png");
function getDomainFromUrl(url) {
  const urlObject = new URL(url);
  return urlObject.hostname;
}
function getHostnameFromCookies(cookies) {
  const hostname = cookies.find(
    (cookie) => cookie.name === "last_known_canvas_host"
  )?.value;
  return hostname ?? "";
}
function getCsrfTokenFromCookies(cookies) {
  const csrfToken = cookies.find((cookie) => cookie.name === "_csrf_token")?.value;
  return decodeURIComponent(csrfToken ?? "");
}
function getCanvasUserIdFromCookies(cookies) {
  const canvasUserId = cookies.find(
    (cookie) => cookie.name === "canvas_user_id"
  )?.value;
  return decodeURIComponent(canvasUserId ?? "");
}
function extractCanvasUserDataFromCookies(cookies) {
  return {
    hostname: getHostnameFromCookies(cookies),
    userId: getCanvasUserIdFromCookies(cookies),
    user: null,
    session: {
      cookies,
      csrfToken: getCsrfTokenFromCookies(cookies)
    },
    canvas_preferences: {
      custom_colors: {}
    }
  };
}
function getErrorMessage(err) {
  if (err instanceof Error) {
    return err.message;
  } else {
    return String(err);
  }
}
const CANVAS_SESSION_PARTITION_KEY = "persist:loginSession";
const DefaultThemeSets = [{
  "name": "Uniform Dark",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 1,
  "main_content_bg_color": "#1c1c1c",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#050505",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#f5f5f5",
  "font_color_active": "#000000",
  "is_dark": true
}, {
  "name": "Uniform Light",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#141414",
  "main_content_opacity": 1,
  "main_content_bg_color": "#ffffff",
  "window_background_image": "",
  "window_background_overlay": 0.25,
  "window_background_color": "#ffffff",
  "window_background_color_opacity": 1,
  "window_background_type": "color",
  "primary_color": "#f2f2f2",
  "font_color_active": "#000000",
  "is_dark": false
}, {
  "name": "Dark Blue",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#e9ecfb",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#000419",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#031149",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#132aa0",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Dark Purple",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#fdfaff",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#0e0014",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#34004d",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#810ab8",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Dark Red",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#f5e6e6",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#000000",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#490303",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#a01313",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Dark Cyan",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#e5f5f5",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#000a0a",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#003832",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#008077",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Galaxy",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.6,
  "main_content_bg_color": "#0a0a0a",
  "window_background_image": "https://images.unsplash.com/photo-1538370965046-79c0d6907d47?q=80&w=3269&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.22,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.75,
  "window_background_type": "image",
  "primary_color": "#375ed2",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Night Sky",
  "font_family": "geometric-humanist",
  "font_size": 16,
  "font_color": "#d7d5f0",
  "main_content_opacity": 0.6,
  "main_content_bg_color": "#000000",
  "window_background_image": "https://images.unsplash.com/photo-1444080748397-f442aa95c3e5?q=80&w=3264&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.22,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.75,
  "window_background_type": "image",
  "primary_color": "#28309f",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Aurora",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.6,
  "main_content_bg_color": "#000500",
  "window_background_image": "https://images.unsplash.com/photo-1488415032361-b7e238421f1b?q=80&w=3269&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.22,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.73,
  "window_background_type": "image",
  "primary_color": "#25ad4d",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Mountain Blue",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.63,
  "main_content_bg_color": "#0d0d0d",
  "window_background_image": "https://images.unsplash.com/photo-1480241352829-e1573ff2414e?q=80&w=3270&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.17,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.24,
  "window_background_type": "image",
  "primary_color": "#2d6cbe",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Transparent Light",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#141414",
  "main_content_opacity": 1,
  "main_content_bg_color": "#ffffff",
  "window_background_image": "",
  "window_background_overlay": 0.25,
  "window_background_color": "#ffffff",
  "window_background_color_opacity": 0.51,
  "window_background_type": "color",
  "primary_color": "#f2f2f2",
  "font_color_active": "#000000",
  "is_dark": false
}, {
  "name": "Transparent Dark",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.9,
  "main_content_bg_color": "#000000",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#000000",
  "window_background_color_opacity": 0.42,
  "window_background_type": "color",
  "primary_color": "#ffffff",
  "font_color_active": "#000000",
  "is_dark": true
}, {
  "name": "Light Blue",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#000314",
  "main_content_opacity": 1,
  "main_content_bg_color": "#fafbff",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#ccd6ff",
  "window_background_color_opacity": 1,
  "window_background_type": "color",
  "primary_color": "#516cf0",
  "font_color_active": "#ffffff",
  "is_dark": false
}];
({
  ...DefaultThemeSets[0],
  name: "New Theme"
});
const INITIAL_SETTINGS = {
  theme: DefaultThemeSets[0],
  courses: {},
  show_course_card_image: true,
  dashboard_course_display_type: "favorite",
  show_assignment_due_date_threshold: 24 * 3,
  urgent_assignment_threshold: 24,
  warning_assignment_threshold: 48
};
const USER_DATA_STORE_FILENAME = "user-data.json";
function getUserDataKey(userId, hostname) {
  return `${userId}-${hostname}`;
}
const EMPTY_CANVAS_PREFERENCES = {
  custom_colors: {}
};
const DEFAULT_USER_DATA = {
  currentCanvasUserKey: null,
  currentCanvasHost: null,
  users: []
};
class UserDataStore {
  filePath;
  constructor() {
    this.filePath = require$$1__namespace.join(
      electron.app.getPath("userData"),
      USER_DATA_STORE_FILENAME
    );
    if (utils.is.dev) {
      console.log("User data store path:", this.filePath);
    }
    if (!fs__namespace.existsSync(this.filePath)) {
      fs__namespace.writeFileSync(
        this.filePath,
        JSON.stringify(DEFAULT_USER_DATA),
        "utf-8"
      );
    }
  }
  /**
   * Reads data from the storage file.
   * @returns {Record<string, T>} The parsed JSON data from the file.
   */
  _readFile() {
    try {
      const data = fs__namespace.readFileSync(this.filePath, "utf-8");
      return JSON.parse(data);
    } catch (error) {
      console.error("Failed to read storage file:", error);
      return DEFAULT_USER_DATA;
    }
  }
  /**
   * Writes data to the storage file.
   * @param {Record<string, T>} data The data to write to the file.
   */
  _writeFile(data) {
    try {
      fs__namespace.writeFileSync(this.filePath, JSON.stringify(data, null, 2), "utf-8");
    } catch (error) {
      console.error("Failed to write to storage file:", error);
    }
  }
  getUserByCanvasUserKey(key) {
    const data = this._readFile();
    return data.users.find(
      (u) => `${u.canvas.userId}-${u.canvas.hostname}` === key
    );
  }
  getCurrentUserIndex() {
    const data = this._readFile();
    const currentCanvasUserKey = data.currentCanvasUserKey;
    if (!currentCanvasUserKey) {
      return -1;
    }
    return data.users.findIndex(
      (u) => `${u.canvas.userId}-${u.canvas.hostname}` === currentCanvasUserKey
    );
  }
  getCurrentUserData() {
    const data = this._readFile();
    const currentCanvasUserKey = data.currentCanvasUserKey;
    if (!currentCanvasUserKey) {
      return null;
    }
    const u = this.getUserByCanvasUserKey(currentCanvasUserKey);
    if (!u) {
      return null;
    }
    return u;
  }
  getCurrentCanvasUserData() {
    return this.getCurrentUserData()?.canvas ?? null;
  }
  getCurrentCanvasUserId() {
    const data = this._readFile();
    if (!data.currentCanvasUserKey) {
      return null;
    }
    const u = this.getUserByCanvasUserKey(data.currentCanvasUserKey);
    return !!u ? u.canvas.userId : null;
  }
  getCurrentCanvasHost() {
    const data = this._readFile();
    return data.currentCanvasHost;
  }
  setCurrentCanvasHost(hostname) {
    const data = this._readFile();
    data.currentCanvasHost = hostname;
    this._writeFile(data);
  }
  setCurrentCanvasUserData(newCanvasUserData) {
    const data = this._readFile();
    const newData = {
      ...data,
      users: data.users.map((u2) => {
        if (getUserDataKey(u2.canvas.userId, u2.canvas.hostname) === data.currentCanvasUserKey) {
          return {
            ...u2,
            canvas: {
              ...u2.canvas,
              ...newCanvasUserData
            }
          };
        }
        return u2;
      })
    };
    this._writeFile(newData);
  }
  saveCurrentUserSettings(settings) {
    const data = this._readFile();
    const idx = this.getCurrentUserIndex();
    const newData = {
      ...data,
      users: data.users.map((u, i) => i === idx ? { ...u, settings } : u)
    };
    this._writeFile(newData);
  }
  canvasLogin(userId, hostname, session) {
    const data = this._readFile();
    const key = getUserDataKey(userId, hostname);
    const u = this.getUserByCanvasUserKey(key);
    let newUsers = [...data.users];
    if (!u) {
      newUsers.push({
        canvas: {
          session,
          userId,
          user: null,
          hostname,
          canvas_preferences: EMPTY_CANVAS_PREFERENCES
        },
        settings: INITIAL_SETTINGS
      });
    } else {
      newUsers = data.users.map((u2) => {
        if (u2.canvas.userId === userId && u2.canvas.hostname === hostname) {
          return {
            ...u2,
            canvas: {
              ...u2.canvas,
              session
            }
          };
        }
        return u2;
      });
    }
    this._writeFile({
      currentCanvasHost: hostname,
      currentCanvasUserKey: key,
      users: newUsers
    });
  }
  updateCurrentUserCanvasCookies(cookies) {
    const u = this.getCurrentCanvasUserData();
    if (!u) {
      return;
    }
    const { session } = extractCanvasUserDataFromCookies(cookies);
    this.setCurrentCanvasUserData({
      session
    });
  }
  canvasLogoutCurrentUser() {
    const data = this._readFile();
    const u = this.getCurrentCanvasUserData();
    if (!u) {
      return;
    }
    u.session = null;
    data.currentCanvasUserKey = null;
    this._writeFile(data);
  }
}
const userDataStore = new UserDataStore();
const MAIN_WINDOW_HTML_PATH = require$$1.join(__dirname, "../renderer/index.html");
const PRELOAD_PATH = require$$1.join(__dirname, "../preload/index.js");
const WINDOW_WIDTH$1 = 1300;
const WINDOW_HEIGHT$1 = 800;
const NAVBAR_HEIGHT = 56;
let mainWindow = null;
async function loadMainWindow() {
  if (!mainWindow) return;
  if (utils.is.dev && process.env["ELECTRON_RENDERER_URL"]) {
    await mainWindow.loadURL(process.env["ELECTRON_RENDERER_URL"]);
  } else {
    await mainWindow.loadFile(MAIN_WINDOW_HTML_PATH);
  }
}
function getMainWindow() {
  return mainWindow;
}
function createMainWindow() {
  const _mainWindow = new electron.BrowserWindow({
    width: WINDOW_WIDTH$1,
    height: WINDOW_HEIGHT$1,
    frame: false,
    transparent: true,
    titleBarStyle: "hidden",
    trafficLightPosition: {
      x: 16,
      y: NAVBAR_HEIGHT / 2 - 8
    },
    vibrancy: "fullscreen-ui",
    backgroundMaterial: "auto",
    backgroundColor: "#00000000",
    show: false,
    autoHideMenuBar: true,
    ...process.platform === "linux" ? { icon } : {},
    webPreferences: {
      preload: PRELOAD_PATH,
      sandbox: false,
      partition: CANVAS_SESSION_PARTITION_KEY,
      nodeIntegration: true,
      webviewTag: true
      // devTools: true,
    }
  });
  _mainWindow.on("ready-to-show", () => {
    _mainWindow.show();
  });
  _mainWindow.webContents.setWindowOpenHandler((details) => {
    electron.shell.openExternal(details.url);
    return { action: "deny" };
  });
  _mainWindow.webContents.on("did-navigate", async (event, url) => {
    console.log("did-navigate", url);
  });
  mainWindow = _mainWindow;
  loadMainWindow();
  return _mainWindow;
}
const COMMON_HEADERS$1 = {
  accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  "accept-language": "en-US,en;q=0.9",
  connection: "keep-alive",
  "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0"
};
function stringifyCookies(cookies) {
  return cookies.map(
    (cookie) => `${cookie.name}=${decodeURIComponent(cookie.value)}`
  ).join("; ");
}
async function fetch_wrapper(url, options) {
  const canvasSession = await userDataStore.getCurrentCanvasUserData();
  if (!canvasSession || !canvasSession.session) {
    throw new Error("Canvas session not found");
  }
  const _url = `https://${canvasSession.hostname}${url}`;
  const { headers, ...rest } = {};
  const res = await fetch(_url, {
    headers: {
      ...COMMON_HEADERS$1,
      cookie: stringifyCookies(canvasSession.session.cookies),
      host: canvasSession.hostname,
      ...headers ?? {}
    },
    ...rest ?? {}
  });
  console.log(`🚀 [${res.status}] ${_url}`);
  return res;
}
function extract_home_env_info_from_html(html) {
  const doc = new jsdom.JSDOM(html).window.document;
  let script = doc.querySelectorAll("script")[1];
  let t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  if (!t) {
    script = doc.querySelectorAll("script")[2];
    t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  }
  if (!t) {
    console.log("No ENV found in Canvas home page", script);
    return null;
  }
  try {
    const data = JSON.parse(t + "}");
    return {
      user: {
        id: data["current_user"]["id"],
        display_name: data["current_user"]["display_name"],
        avatar_image_url: data["current_user"]["avatar_image_url"],
        html_url: data["current_user"]["html_url"],
        pronouns: data["current_user"]["pronouns"],
        email: data["current_user"]["email"]
      },
      preferences: {
        custom_colors: data["PREFERENCES"]["custom_colors"]
      },
      courses: data["STUDENT_PLANNER_COURSES"].map((c) => ({ ...c, tabs: [] }))
    };
  } catch (e) {
    console.error("failed to parse Canvas Home env", e);
    console.log("env_str", t);
    return null;
  }
}
async function get_home_info() {
  const res = await fetch_wrapper("/");
  if (res.status === 401) {
    return null;
  }
  const html = await res.text();
  return extract_home_env_info_from_html(html);
}
const pagination_wrapper = async (make_fetch, page_size) => {
  let cur_page = 1;
  let res = await make_fetch(page_size, cur_page);
  const data = await res.json();
  let cur = data;
  let output = [...cur];
  while (cur.length === page_size) {
    cur_page += 1;
    res = await make_fetch(page_size, cur_page);
    cur = await res.json();
    output = [...output, ...cur];
  }
  return output;
};
async function fetch_course_announcements(courseId, page_size = 10) {
  const res = await pagination_wrapper(
    (page_size2, page) => fetch_wrapper(
      `/api/v1/courses/${courseId}/discussion_topics?only_announcements=true&per_page=${page_size2}&page=${page}&filter_by=all&no_avatar_fallback=1&include[]=sections_user_count&include[]=sections`
    ),
    page_size
  );
  return res.map((a) => ({
    ...a,
    id: `${a.id}`,
    // @ts-ignore
    author: !!a.author ? a.author : null,
    course_id: courseId
  }));
}
async function fetch_course_syllabus(courseId) {
  const res = await fetch_wrapper(`/courses/${courseId}/assignments/syllabus`);
  const html = await res.text();
  const win = new jsdom.JSDOM(html);
  return win.window.document.querySelector("#content")?.innerHTML ?? "";
}
const search_universities_by_domain = async (domain) => {
  const universities = await fetch(
    "https://sso.canvaslms.com/api/v1/accounts/search?domain=" + domain
  ).then((res) => res.json());
  return universities;
};
const search_universities_by_name = async (name) => {
  const universities = await fetch(
    "https://sso.canvaslms.com/api/v1/accounts/search?name=" + name
  ).then((res) => res.json());
  return universities;
};
function getDateString(date) {
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "numeric",
    day: "numeric"
  });
}
function getAssignmentDueDate(assignment) {
  return !!assignment.due_at ? new Date(assignment.due_at) : null;
}
function groupAssignmentsByDueDate(assignmentList) {
  const dateMap = /* @__PURE__ */ new Map();
  dateMap.set("invalid", {
    items: []
  });
  const dateArray = [];
  assignmentList.forEach((assignment) => {
    const dueDate = getAssignmentDueDate(assignment);
    if (!dueDate) {
      dateMap.get("invalid").items.push(assignment);
    } else {
      const date = getDateString(dueDate);
      if (!dateMap.has(date)) {
        dateMap.set(date, {
          items: [],
          nextDate: void 0,
          prevDate: void 0
        });
        dateArray.push(date);
      }
      dateMap.get(date).items.push(assignment);
    }
  });
  dateArray.sort();
  dateArray.forEach((date, index) => {
    if (index < dateArray.length - 1) {
      dateMap.get(date).nextDate = dateArray[index + 1];
    }
    if (index > 0) {
      dateMap.get(date).prevDate = dateArray[index - 1];
    }
  });
  return { dateMap, dateArray };
}
function calculateAssignmentDoneState(assignment) {
  if (!assignment.submissions || assignment.submissions.length === 0 || assignment.submissions[0].workflow_state === "unsubmitted" || assignment.submissions[0].missing || !assignment.submissions[0].submitted_at) {
    return false;
  }
  return true;
}
const DB_PATH = require$$1.join(electron.app.getPath("userData"), "database.db");
if (utils.is.dev && fs.existsSync(DB_PATH)) {
  fs.unlinkSync(DB_PATH);
  console.log("Development mode: Database reset.");
}
const db = new Database(DB_PATH, {
  // verbose: console.log,
});
function initializeDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS user (
      id TEXT PRIMARY KEY,
      display_name TEXT,
      avatar_image_url TEXT,
      html_url TEXT,
      pronouns TEXT,
      email TEXT
    );

    CREATE TABLE IF NOT EXISTS course (
      id TEXT PRIMARY KEY,
      courseCode TEXT,
      dataInit BOOLEAN DEFAULT 0,
      pinned BOOLEAN,
      data TEXT
    );

    CREATE TABLE IF NOT EXISTS assignment_groups (
      id INTEGER PRIMARY KEY,
      courseId TEXT,
      name TEXT,
      data TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS assignments (
      id INTEGER PRIMARY KEY,
      courseId TEXT,
      assignmentGroupId INTEGER,
      name TEXT,
      dueAt TEXT,
      done BOOLEAN,
      done_local_overwrite BOOLEAN,
      data TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id),
      FOREIGN KEY (assignmentGroupId) REFERENCES assignment_groups (id)
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id TEXT PRIMARY KEY,
      courseId TEXT,
      data TEXT,
      postedAt TEXT,
      readState TEXT,
      title TEXT,
      message TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY,
      assignmentId INTEGER,
      data TEXT,

      FOREIGN KEY (assignmentId) REFERENCES assignments (id)
    );

    CREATE TABLE IF NOT EXISTS course_root_folders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      courseId TEXT UNIQUE,
      folderId INTEGER,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS folders (
      id INTEGER PRIMARY KEY,
      parentFolderId INTEGER,
      data TEXT
    );

    CREATE TABLE IF NOT EXISTS files (
      id INTEGER PRIMARY KEY,
      folderId INTEGER,
      url TEXT,
      displayName TEXT,
      createdAt TEXT,
      updatedAt TEXT,
      data TEXT,

      FOREIGN KEY (folderId) REFERENCES folders (id)
    );

    CREATE TABLE IF NOT EXISTS pages (
      id TEXT PRIMARY KEY,
      title TEXT,
      courseId TEXT,
      data TEXT,
      createdAt TEXT,
      updatedAt TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS planner_items (
      id TEXT PRIMARY KEY,
      courseId TEXT,
      title TEXT,
      date TEXT,
      done BOOLEAN DEFAULT 0,
      ignored BOOLEAN DEFAULT 0,
      data TEXT
    );
  `);
}
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
initializeDb();
function upsertCourseAssignments(courseId, assignmentGroups) {
  const upsertAssignmentGroupStmt = db.prepare(`
    INSERT INTO assignment_groups (id, courseId, name, data)
    VALUES (@id, @courseId, @name, @data)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      data = excluded.data;
  `);
  const upsertAssignmentStmt = db.prepare(`
    INSERT INTO assignments (id, courseId, assignmentGroupId, data, dueAt, name)
    VALUES (@id, @courseId, @assignmentGroupId, @data, @dueAt, @name)
    ON CONFLICT(id) DO UPDATE SET
      assignmentGroupId = excluded.assignmentGroupId,
      dueAt = excluded.dueAt,
      name = excluded.name,
      data = excluded.data;
  `);
  const transaction = db.transaction((assignmentGroups2) => {
    for (const group of assignmentGroups2) {
      upsertAssignmentGroupStmt.run({
        id: group.id,
        courseId,
        name: group.name,
        data: JSON.stringify(group)
      });
      for (const assignment of group.assignments) {
        upsertAssignmentStmt.run({
          id: assignment.id,
          courseId,
          assignmentGroupId: group.id,
          dueAt: assignment.due_at,
          name: assignment.name,
          data: JSON.stringify(assignment)
        });
      }
    }
  });
  transaction(assignmentGroups);
}
function getAssignmentGroupRowsByCourseId(courseId) {
  const stmt = db.prepare(`
    SELECT id, courseId, name, data FROM assignment_groups WHERE courseId = ?
  `);
  return stmt.all(courseId).map((row) => {
    return {
      ...JSON.parse(row.data),
      id: row.id,
      assignments: [],
      course_id: row.courseId,
      name: row.name
    };
  });
}
function getCourseAssignmentGroups(courseId) {
  const assignmentGroupRows = getAssignmentGroupRowsByCourseId(courseId);
  const output = assignmentGroupRows.map((g) => {
    const aData = getAssignments({
      assignmentGroupId: g.id,
      limit: 100,
      page: 1
    });
    return {
      ...g,
      assignments: aData
    };
  });
  return output;
}
function mergeAssignmentSubmissionRows(assignmentSubmissionRows) {
  const aIdToSId = /* @__PURE__ */ new Map();
  const sMap = /* @__PURE__ */ new Map();
  const aMap = /* @__PURE__ */ new Map();
  for (const row of assignmentSubmissionRows) {
    const aId = `${row.assignmentId}`;
    const sId = !!row.submissionId ? `${row.submissionId}` : null;
    if (!aIdToSId.has(aId)) {
      aIdToSId.set(aId, !sId ? [] : [sId]);
    } else if (!!sId) {
      aIdToSId.get(aId).push(sId);
    }
    if (!!sId) {
      sMap.set(sId, JSON.parse(row.submissionData));
    }
    aMap.set(aId, {
      ...JSON.parse(row.assignmentData),
      done: row.done,
      done_local_overwrite: row.done_local_overwrite
    });
  }
  const assignments = [];
  for (const [aId, sIds] of aIdToSId) {
    const assignment = aMap.get(aId);
    assignments.push({
      ...assignment,
      submissions: sIds.map((sId) => sMap.get(sId))
    });
  }
  return assignments;
}
function getAssignments(options) {
  if (!options.page || !options.limit) {
    options.page = 1;
    options.limit = 100;
  }
  if (!options.order) {
    options.order = "desc";
  }
  if (!options.courseIds) {
    options.courseIds = [];
  }
  let where = "";
  if (options.courseIds.length > 0 || !!options.assignmentGroupId || !!options.searchTerm || typeof options.done === "boolean" || !!options.dueAtStart || !!options.dueAtEnd || !!options.favoriteOnly) {
    where += "where ";
    let whereItems = [];
    if (options.courseIds.length > 0) {
      whereItems.push(`courseId in (${options.courseIds.map((id) => `'${id}'`).join(",")})`);
    }
    if (!!options.assignmentGroupId) {
      whereItems.push(`assignmentGroupId = '${options.assignmentGroupId}'`);
    }
    if (!!options.searchTerm) {
      whereItems.push(`assignments.name like '%${options.searchTerm}%'`);
    }
    if (typeof options.done === "boolean") {
      whereItems.push(`done = ${options.done ? 1 : 0}`);
    }
    if (!!options.dueAtStart) {
      whereItems.push(`dueAt >= '${options.dueAtStart}'`);
    }
    if (!!options.dueAtEnd) {
      whereItems.push(`dueAt <= '${options.dueAtEnd}'`);
    }
    if (!!options.favoriteOnly) {
      whereItems.push(`course.favorite = 1`);
    }
    where += whereItems.join(" and ");
  }
  const assignmentsStmt = db.prepare(`
    SELECT 
      assignments.id as assignmentId, courseId, assignments.data as assignmentData, dueAt, done, done_local_overwrite,
      submissions.id as submissionId, submissions.data as submissionData
    FROM assignments
    left join submissions on assignments.id = submissions.assignmentId
    inner join course on assignments.courseId = course.id
    ${where}
    ORDER BY ${options.orderBy || "dueAt"} ${options.order.toUpperCase()}
    LIMIT ? OFFSET ?
  `);
  const assignmentSubmissionRows = assignmentsStmt.all([
    options.limit,
    (options.page - 1) * options.limit
  ]);
  const assignments = mergeAssignmentSubmissionRows(
    assignmentSubmissionRows
  );
  assignments.sort((a, b) => {
    const aDate = new Date(a.due_at ?? "");
    const bDate = new Date(b.due_at ?? "");
    if (options.order === "asc") {
      return aDate.getTime() - bDate.getTime();
    } else {
      return bDate.getTime() - aDate.getTime();
    }
  });
  return assignments;
}
function getAssignmentById(id) {
  const stmt = db.prepare(`
    SELECT 
      assignments.id as assignmentId, courseId, assignments.data as assignmentData, dueAt, done, done_local_overwrite,
      submissions.id as submissionId, submissions.data as submissionData
    FROM assignments
    left join submissions on assignments.id = submissions.assignmentId
    WHERE assignments.id = ?
  `);
  const rows = stmt.all(id);
  if (rows.length > 0) {
    return mergeAssignmentSubmissionRows(rows)[0];
  }
  return null;
}
function updateAssignmentById(id, params) {
  const oldAssignment = getAssignmentById(id);
  if (!params.data) {
    params.data = JSON.stringify(oldAssignment);
  }
  if (!params.done) {
    params.done = calculateAssignmentDoneState(oldAssignment);
  }
  if (!params.done_local_overwrite) {
    params.done_local_overwrite = !!oldAssignment.done_local_overwrite;
  }
  const stmt = db.prepare(`
    UPDATE assignments
    SET data = ?, done = ?, done_local_overwrite = ?
    WHERE id = ?
  `);
  stmt.run(
    params.data,
    params.done ? 1 : 0,
    params.done_local_overwrite ? 1 : 0,
    id
  );
}
function syncAssignmentsWithSubmissions(assignmentIds) {
  assignmentIds.forEach((id) => {
    const oldAssignment = getAssignmentById(id);
    if (!oldAssignment) {
      return;
    }
    const doneFromServer = calculateAssignmentDoneState(oldAssignment);
    const overwrite = !!oldAssignment.done === doneFromServer ? false : !!oldAssignment.done_local_overwrite;
    updateAssignmentById(id, {
      data: JSON.stringify(oldAssignment),
      // respect user's overwrite state
      done: overwrite ? oldAssignment.done : doneFromServer,
      // if the server state is the same from the local state, set done_local_overwrite
      // to false, otherwise leave it unchanged
      done_local_overwrite: overwrite
    });
  });
}
function getCourseAssignmentsSummary(courseId) {
  const allAssignments = getAssignments({
    courseIds: [courseId],
    limit: 1e3
  });
  const { dateMap } = groupAssignmentsByDueDate(allAssignments);
  const dateMapShort = /* @__PURE__ */ new Map();
  dateMap.forEach((value, key) => {
    dateMapShort.set(key, {
      count: value.items.length,
      doneCount: value.items.filter((a) => a.done).length
    });
  });
  return {
    dateMap: dateMapShort
  };
}
function upsertAnnouncements(announcements) {
  const upsertAnnouncementStmt = db.prepare(`
    INSERT INTO announcements (id, courseId, data, postedAt, readState, title, message)
    VALUES (@id, @courseId, @data, @postedAt, @readState, @title, @message)
    ON CONFLICT(id) DO UPDATE SET
      courseId = excluded.courseId,
      data = excluded.data,
      postedAt = excluded.postedAt,
      readState = excluded.readState,
      title = excluded.title,
      message = excluded.message;
  `);
  const transaction = db.transaction((announcements2) => {
    for (const announcement of announcements2) {
      upsertAnnouncementStmt.run({
        id: announcement.id,
        courseId: announcement.course_id,
        data: JSON.stringify(announcement),
        postedAt: announcement.posted_at,
        readState: announcement.read_state,
        title: announcement.title,
        message: announcement.message
      });
    }
  });
  transaction(announcements);
}
function getAnnouncements(options) {
  const getAllAnnouncementsStmt = db.prepare(`
    SELECT id, courseId, data, postedAt, readState, title, message
    FROM announcements
    ${!!options.courseId ? `WHERE courseId = '${options.courseId}'` : ""}
    ORDER BY ${options.orderBy || "postedAt"} DESC
    LIMIT ? OFFSET ?
  `);
  const rows = getAllAnnouncementsStmt.all([
    options.limit,
    (options.page - 1) * options.limit
  ]);
  return rows.map((row) => {
    return {
      id: row.id,
      course_id: row.courseId,
      posted_at: row.postedAt,
      read_state: row.readState,
      title: row.title,
      message: row.message,
      ...JSON.parse(row.data)
    };
  });
}
function getAnnouncementById(id) {
  const getAnnouncementByIdStmt = db.prepare(`
    SELECT *
    FROM announcements
    WHERE id = ?
  `);
  const row = getAnnouncementByIdStmt.get(id);
  if (row) {
    return {
      id: row.id,
      course_id: row.courseId,
      posted_at: row.postedAt,
      read_state: row.readState,
      title: row.title,
      message: row.message,
      ...JSON.parse(row.data)
    };
  }
  return null;
}
function build_include_fields(fields) {
  return fields.map((f) => `include[]=${f}`).join("&");
}
function stringify_cookies(cookies) {
  return cookies.map(
    (cookie) => `${cookie.name}=${decodeURIComponent(cookie.value)}`
  ).join("; ");
}
function build_search_queries(options) {
  return Object.entries(options).map(([key, value]) => {
    if (Array.isArray(value)) {
      return value.map((v) => `${key}=${v}`).join("&");
    } else {
      return `${key}=${value}`;
    }
  }).join("&");
}
function parseCookiesFromResponse(response) {
  const rawSetCookieHeaders = response.headers.get("set-cookie")?.split(", ");
  if (!rawSetCookieHeaders || rawSetCookieHeaders.length === 0) {
    return [];
  }
  const domain = new URL(response.url).hostname;
  const cookies = rawSetCookieHeaders.map((setCookieStr) => {
    return parseSetCookieString(setCookieStr, domain);
  });
  return cookies.filter(Boolean);
}
function parseSetCookieString(setCookieStr, domain) {
  const parts = setCookieStr.split("; ").map((p) => p.trim());
  const [nameValue, ...attributes] = parts;
  if (!nameValue) {
    return null;
  }
  const [cookieName, cookieValue] = nameValue.split("=");
  if (!cookieName || cookieValue === void 0) {
    return null;
  }
  const cookie = {
    name: cookieName,
    value: cookieValue,
    domain,
    path: "/",
    secure: false,
    httpOnly: false,
    sameSite: "lax"
    // You can include other Electron.Cookie attributes as needed
    // e.g. expirationDate
  };
  attributes.forEach((attr) => {
    const [key, val] = attr.split("=");
    const lowerKey = key.toLowerCase().trim();
    switch (lowerKey) {
      case "domain":
        cookie.domain = val;
        break;
      case "path":
        cookie.path = val;
        break;
      case "secure":
        cookie.secure = true;
        break;
      case "httponly":
        cookie.httpOnly = true;
        break;
    }
  });
  return cookie;
}
function mergeCookieLists(listA, listB) {
  const cookieMap = /* @__PURE__ */ new Map();
  function createCookieKey(cookie) {
    const domain = cookie.domain || "";
    const path = cookie.path || "";
    const name = cookie.name || "";
    return `${domain}::${path}::${name}`;
  }
  for (const cookie of listA) {
    cookieMap.set(createCookieKey(cookie), cookie);
  }
  for (const cookie of listB) {
    cookieMap.set(createCookieKey(cookie), cookie);
  }
  return Array.from(cookieMap.values());
}
function extractEnvFromCoursePageHTML(html) {
  const doc = new jsdom.JSDOM(html).window.document;
  let script = doc.querySelectorAll("script")[1];
  let t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  if (!t) {
    script = doc.querySelectorAll("script")[2];
    t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  }
  if (!t) {
    return null;
  }
  try {
    const data = JSON.parse(t + "}");
    return data;
  } catch (e) {
    console.error("failed to parse ENV from course page HTML:", e);
    return null;
  }
}
const CourseIncludeFields = [
  "tabs",
  // favorite is not accurate; use get dashboard courses instead
  "favorites",
  "banner_image",
  "syllabus_body",
  "total_students",
  "term",
  "course_image",
  "teachers",
  "concluded"
];
const COMMON_HEADERS = {
  accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  "accept-language": "en-US,en;q=0.9",
  connection: "keep-alive",
  "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0"
};
function createCanvasClient() {
  const canvasUserData = userDataStore.getCurrentCanvasUserData();
  const session = canvasUserData?.session;
  if (!session) {
    throw new Error("No canvas user data found");
  }
  return new CanvasClient(
    canvasUserData.hostname,
    session
  );
}
class CanvasClient {
  hostname;
  cookies;
  cookieString;
  csrfToken;
  constructor(hostname, canvasSession) {
    this.hostname = hostname;
    this.cookies = canvasSession.cookies;
    this.csrfToken = canvasSession.csrfToken;
    this.cookieString = stringify_cookies(canvasSession.cookies);
  }
  async fetch_wrapper(url, options, {
    rawUrl = false
  } = {}) {
    const _url = rawUrl ? url : `https://${this.hostname}${url}`;
    const { headers, ...rest } = options ?? {};
    const start = performance.now();
    const _headers = {
      ...COMMON_HEADERS,
      cookie: this.cookieString,
      host: this.hostname,
      ...headers
    };
    const res = await fetch(_url, {
      headers: _headers,
      ...rest ?? {}
    });
    const end = performance.now();
    const newCookies = parseCookiesFromResponse(res);
    if (newCookies.length > 0) {
      newCookies.map((c) => c.name).join(", ");
      this.cookies = mergeCookieLists(this.cookies, newCookies);
      userDataStore.updateCurrentUserCanvasCookies(this.cookies);
      this.cookieString = stringify_cookies(this.cookies);
    }
    console.log(`🚀 [${res.status}] (+${(end - start).toFixed(2)}ms) ${_url}`);
    return res;
  }
  async fetch_json(url, options) {
    const { headers = {}, ...rest } = options ?? {};
    const res = await this.fetch_wrapper(url, {
      headers: {
        accept: "application/json+canvas-string-ids, application/json",
        "x-csrf-token": this.csrfToken,
        "x-requested-with": "XMLHttpRequest",
        ...headers
      },
      ...rest
    });
    const json = await res.json();
    return json;
  }
  async graphql(name, query, variables) {
    query = `query ${name} { ${query} }`;
    const res = await this.fetch_json("/api/graphql", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ operationName: name, query, variables })
    });
    const data = res;
    console.log("GraphQL: " + name);
    return data;
  }
  async fetch_dashboard_courses() {
    const includeFields = build_include_fields(CourseIncludeFields);
    const res = await this.fetch_json(
      `/api/v1/users/self/favorites/courses?${includeFields}`
    );
    return res.map((c) => ({
      id: `${c.id}`,
      root_folder_id: null,
      is_favorite: true,
      // tabs: [],
      ...c
    }));
  }
  /**
   * Using https://canvas.instructure.com/doc/api/courses.html#method.courses.index
   * @returns
   */
  async fetch_courses(options = {}) {
    if (!options["include[]"]) {
      options["include[]"] = CourseIncludeFields;
    }
    if (!options["state[]"]) {
      options["state[]"] = ["available", "completed", "deleted"];
    }
    const queries = build_search_queries(options);
    const res = await this.fetch_json(
      `/api/v1/courses?${queries}&per_page=150`
    );
    return res.map((c) => ({
      id: `${c.id}`,
      root_folder_id: null,
      // tabs: [],
      ...c
    }));
  }
  async set_course_favorite(courseId, favorite) {
    const res = await this.fetch_json(
      `/api/v1/users/self/favorites/courses/${courseId}`,
      {
        method: favorite ? "POST" : "DELETE",
        headers: {
          "content-length": "0"
        }
      }
    );
    if (!res.ok) {
      console.error(
        `Failed to set favorite to ${favorite} for course ${courseId}: ${res.status} ${res.statusText}`
      );
      throw new Error(`Failed to set favorite for course ${courseId}`);
    }
  }
  async fetch_course_home_page(courseId) {
    const res = await this.fetch_wrapper(`/courses/${courseId}`);
    const html = await res.text();
    const data = extractEnvFromCoursePageHTML(html);
    return {
      wiki_page: data?.["WIKI_PAGE"] ?? null
    };
  }
  async fetch_course_tabs(courseId) {
    const res = await this.fetch_json(`/api/v1/courses/${courseId}/tabs`);
    return res;
  }
  /**
   * Using https://canvas.instructure.com/doc/api/planner.html#method.planner.index
   * @returns
   */
  async fetch_planner_items({
    per_page = 100,
    page = 1,
    start_date,
    order = "asc"
  }) {
    const res = await this.fetch_json(
      `/api/v1/planner/items?per_page=${per_page}&page=${page}&start_date=${start_date}&order=${order}`
    );
    return res;
  }
  async fetch_course_quizzes(courseId) {
    const res = await this.fetch_json(`/api/v1/courses/${courseId}/quizzes`);
    return res;
  }
  async fetch_course_assignments(courseId, { per_page = 100 } = {}) {
    const AssignmentsOptions = {
      "exclude_assignment_submission_types[]": ["wiki_page"],
      "exclude_response_fields[]": ["description", "rubric"],
      "include[]": ["assignments", "discussion_topic", "assessment_requests"],
      "per_page": per_page
    };
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/assignment_groups?` + build_search_queries(
        AssignmentsOptions
      )
    );
    return res;
  }
  async fetch_course_submissions(courseId, { limit = 100 } = {}) {
    const options = {
      "include[]": ["submission_comments"],
      "per_page": limit
    };
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/students/submissions?` + build_search_queries(options)
    );
    console.log(`Fetched ${res.length} submissions for course ${courseId}`);
    return res;
  }
  async fetch_course_files(courseId, { limit = 100 } = {}) {
    const COURSE_FILE_INCLUDE_FIELDS = ["enhanced_preview_url"];
    const includeFields = build_include_fields(COURSE_FILE_INCLUDE_FIELDS);
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/files?per_page=${limit}&${includeFields}`
    );
    return res.map((f) => ({ ...f, course_id: courseId }));
  }
  async fetch_course_folders(courseId, { limit = 100 } = {}) {
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/folders?per_page=${limit}`
    );
    return res;
  }
  async fetch_course_root_folder(courseId) {
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/folders/root`
    );
    return res;
  }
  async fetch_announcements(courseIds) {
    let queries = courseIds.map(
      (courseId) => `context_codes[]=course_${courseId}`
    ).join("&");
    const now = (/* @__PURE__ */ new Date()).toISOString();
    queries += "&start_date=2000-01-01T00:00:00Z&end_date=" + now + "&per_page=200";
    const res = await this.fetch_json(`/api/v1/announcements?${queries}`);
    const byCourse = res.reduce((acc, a) => {
      if (!acc[a["context_code"]]) {
        acc[a["context_code"]] = [];
      }
      acc[a["context_code"]].push(a);
      return acc;
    }, {});
    Object.entries(byCourse).forEach(([contextCode, announcements]) => {
      const courseId = contextCode.split("_")[1];
      console.log(
        `Course ${courseId} has ${announcements.length} announcements`
      );
    });
    console.log("Total announcements:", res.length);
    return res.map((a) => ({
      ...a,
      course_id: a["context_code"].split("_")[1]
    }));
  }
  async fetch_course_pages(courseId) {
    const Fields = {
      sort: "title",
      per_page: 100,
      order: "asc"
    };
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/pages?` + build_search_queries(Fields)
    );
    return res;
  }
  async set_color(name, color) {
    const userId = userDataStore.getCurrentCanvasUserId();
    if (!userId) {
      throw new Error("No canvas user data found");
    }
    const formData = new URLSearchParams();
    formData.set("hexcode", color);
    await this.fetch_json(
      `/api/v1/users/${userId}/colors/${name}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: formData
      }
    );
  }
  async set_course_color(courseId, color) {
    await this.set_color(`course_${courseId}`, color);
  }
  // async fetch_assignment_description(assignmentId: number): Promise<string> {
  async fetch_assignment_description(href) {
    const res = await this.fetch_wrapper(href, {}, {
      rawUrl: true
    });
    const html = await res.text();
    const doc = new jsdom.JSDOM(html);
    const content = doc.window.document.querySelector("div.user_content");
    return content?.innerHTML ?? "";
  }
  async download_file(url, filePath) {
    fs.mkdirSync(require$$1.dirname(filePath), { recursive: true });
    const response = await this.fetch_wrapper(url, {}, { rawUrl: true });
    if (!response.ok) {
      throw new Error(
        `Failed to download file: ${response.status} ${response.statusText}`
      );
    }
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    fs.writeFileSync(filePath, new Uint8Array(buffer));
    return filePath;
  }
}
function upsertCourses(courses) {
  const upsertCourseStmt = db.prepare(`
    INSERT INTO course (id, courseCode, pinned, data)
    VALUES (@id, @courseCode, @pinned, @data)
    ON CONFLICT(id) DO UPDATE SET
      courseCode = excluded.courseCode,
      pinned = excluded.pinned,
      dataInit = 1,
      data = excluded.data;
  `);
  const transaction = db.transaction((courses2) => {
    for (const course of courses2) {
      upsertCourseStmt.run({
        id: course.id,
        courseCode: course.course_code,
        pinned: course.is_favorite ? 1 : 0,
        data: JSON.stringify(course)
      });
    }
  });
  transaction(courses);
}
function updateCourse(courseId, data) {
  const existing = db.prepare(
    `
    SELECT id, data FROM course WHERE id = ?
  `
  ).get(courseId);
  const newData = { ...JSON.parse(existing.data), ...data };
  const updateCourseStmt = db.prepare(
    `
    UPDATE course
    SET data = @data
    WHERE id = @id
  `
  );
  updateCourseStmt.run({
    id: courseId,
    data: JSON.stringify(newData)
  });
}
function getPinnedCourses() {
  const getPinnedCoursesStmt = db.prepare(`
    SELECT id, courseCode, pinned, data
    FROM course
    WHERE pinned = 1
  `);
  const rows = getPinnedCoursesStmt.all();
  return rows.map((row) => {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      pinned: !!row.pinned,
      ...parsedData
    };
  });
}
function getAllCourses() {
  const getAllCoursesStmt = db.prepare(`
    SELECT id, courseCode, pinned, data, dataInit
    FROM course
  `);
  const rows = getAllCoursesStmt.all();
  return rows.map((row) => {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      pinned: !!row.pinned,
      ...parsedData,
      dataInit: !!row.dataInit
    };
  });
}
function getCourseById(courseId) {
  const stmt = db.prepare(`
    SELECT id, courseCode, pinned, data
    FROM course
    WHERE id = ?
  `);
  const row = stmt.get(courseId);
  if (row) {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      ...parsedData
    };
  }
  return null;
}
function getAllCourseIdSet() {
  const getAllCourseIdsStmt = db.prepare(`
    SELECT id
    FROM course
  `);
  return new Set(getAllCourseIdsStmt.all().map((row) => row.id));
}
function setFavoriteCourses(courseIds) {
  const allCourseIds = getAllCourseIdSet();
  const favoriteCourseIds = new Set(courseIds);
  const favoriteCourses = new Set(
    Array.from(allCourseIds).filter((id) => favoriteCourseIds.has(id))
  );
  const stmt = db.prepare(`
    UPDATE course
    SET pinned = CASE WHEN id IN (${Array.from(favoriteCourses).join(
    ","
  )}) THEN 1 ELSE 0 END
  `);
  stmt.run();
}
function getCourses({ searchTerm }) {
  const stmt = db.prepare(`
    SELECT id, courseCode, pinned, data
    FROM course
    WHERE courseCode LIKE '%${searchTerm}%'
  `);
  return stmt.all().map((row) => {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      pinned: !!row.pinned,
      ...parsedData
    };
  });
}
function upsertSubmissions(submissions) {
  const upsertSubmissionStmt = db.prepare(`
    INSERT INTO submissions (id, data, assignmentId)
    VALUES (@id, @data, @assignmentId)
    ON CONFLICT(id) DO UPDATE SET
      data = excluded.data;
  `);
  const transaction = db.transaction((submissions2) => {
    for (const submission of submissions2) {
      upsertSubmissionStmt.run({
        id: submission.id,
        assignmentId: submission.assignment_id,
        data: JSON.stringify(submission)
      });
    }
  });
  transaction(submissions);
}
function upsertFolders(folders) {
  const upsertFolderStmt = db.prepare(`
    INSERT INTO folders (id, parentFolderId, data)
    VALUES (@id, @parentFolderId, @data)
    ON CONFLICT(id) DO UPDATE SET
      parentFolderId = excluded.parentFolderId,
      data = excluded.data;
  `);
  const transaction = db.transaction((folders2) => {
    for (const folder of folders2) {
      upsertFolderStmt.run({
        id: folder.id,
        parentFolderId: folder.parent_folder_id ?? null,
        data: JSON.stringify(folder)
      });
    }
  });
  transaction(folders);
}
function upsertFiles(files) {
  const upsertFileStmt = db.prepare(`
    INSERT INTO files (id, folderId, url, displayName, createdAt, updatedAt, data)
    VALUES (@id, @folderId, @url, @displayName, @createdAt, @updatedAt, @data)
    ON CONFLICT(id) DO UPDATE SET
      folderId = excluded.folderId,
      url = excluded.url,
      displayName = excluded.displayName,
      createdAt = excluded.createdAt,
      updatedAt = excluded.updatedAt,
      data = excluded.data;
  `);
  const transaction = db.transaction((files2) => {
    for (const file of files2) {
      upsertFileStmt.run({
        id: file.id,
        folderId: file.folder_id,
        url: file.url,
        displayName: file.display_name,
        createdAt: file.created_at,
        updatedAt: file.updated_at,
        data: JSON.stringify(file)
      });
    }
  });
  transaction(files);
}
function getItemsByFolderId(folderId) {
  const getFoldersStmt = db.prepare(`
    SELECT id, parentFolderId, data
    FROM folders
    WHERE parentFolderId = ?
  `);
  const getFilesStmt = db.prepare(`
    SELECT id, folderId, url, displayName, createdAt, updatedAt, data
    FROM files
    WHERE folderId = ?
  `);
  const folders = getFoldersStmt.all(folderId).map((row) => ({
    ...JSON.parse(row.data),
    id: row.id,
    parentFolderId: row.parent_folder_id
  }));
  const files = getFilesStmt.all(folderId).map((row) => ({
    ...JSON.parse(row.data),
    id: row.id,
    folderId: row.folder_id,
    url: row.url,
    displayName: row.display_name,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt
  }));
  return {
    files,
    folders
  };
}
function upsertCourseRootFolderId(courseId, folderId) {
  const possibleRootFolderId = getCourseRootFolderId(courseId);
  if (possibleRootFolderId) {
    db.prepare(`
      UPDATE course_root_folders
      SET folderId = ?
      WHERE courseId = ?
    `).run([folderId, courseId]);
  } else {
    db.prepare(`
      INSERT INTO course_root_folders (courseId, folderId)
      VALUES (?, ?)
    `).run([courseId, folderId]);
  }
}
function getCourseRootFolderId(courseId) {
  const stmt = db.prepare(`
    SELECT folderId
    FROM course_root_folders
    WHERE courseId = ?
  `);
  const row = stmt.get(courseId);
  return row?.folderId ?? null;
}
function getRecursiveParentFolders(folderId) {
  const stmt = db.prepare(`
    SELECT id, parentFolderId, data
    FROM folders
    WHERE id = ?
  `);
  const row = stmt.get(folderId);
  if (!row) return [];
  return [
    ...getRecursiveParentFolders(row.parentFolderId),
    {
      id: row.id,
      parent_folder_id: row.parentFolderId,
      ...JSON.parse(row.data)
    }
  ];
}
function getFiles({ folderId, searchTerm }) {
  let where = "";
  if (!!folderId || !!searchTerm) {
    where += "where ";
    let whereItems = [];
    if (!!folderId) {
      whereItems.push(`folderId = ${folderId}`);
    }
    if (!!searchTerm) {
      whereItems.push(`displayName LIKE '%${searchTerm}%'`);
    }
    where += whereItems.join(" AND ");
  }
  const stmt = db.prepare(`
    SELECT id, folderId, url, displayName, createdAt, updatedAt, data
    FROM files
    ${where}
  `);
  return stmt.all().map((row) => ({
    ...JSON.parse(row.data)
  }));
}
function getFileById(id) {
  const stmt = db.prepare(`
    SELECT id, folderId, url, displayName, createdAt, updatedAt, data
    FROM files
    WHERE id = ?
  `);
  const row = stmt.get(id);
  if (!row) return null;
  return {
    ...JSON.parse(row.data)
  };
}
const CUSTOM_MENU_LABELS = ["Courses", "Window"];
function makeMenu() {
  const defaultMenu = electron.Menu.getApplicationMenu() ?? { items: [] };
  const courses = getPinnedCourses();
  const menuTemplate = [
    ...defaultMenu.items.map((item) => item).filter(
      (item) => !CUSTOM_MENU_LABELS.includes(item.label)
    ),
    // {
    //   label: "Window",
    //   submenu: [
    //     {
    //       label: "New Window",
    //       click: () => {
    //         // window.electron.ipcRenderer.send("openCourse", course.id);
    //       },
    //     },
    //   ],
    // },
    {
      label: "Courses",
      submenu: courses.map((course) => ({
        label: course.course_code,
        submenu: course.tabs.map((t) => ({
          label: t.label,
          click: () => {
            electron.shell.openExternal(t.full_url);
          }
        }))
      }))
    }
  ];
  return menuTemplate;
}
function updateMenu() {
  const menuTemplate = makeMenu();
  const menu = electron.Menu.buildFromTemplate(menuTemplate);
  electron.Menu.setApplicationMenu(menu);
}
function upsertPages(pages, courseId) {
  const stmt = db.prepare(
    `
    INSERT OR REPLACE INTO pages (id, courseId, data, title, updatedAt, createdAt)
    VALUES (@id, @courseId, @data, @title, @updatedAt, @createdAt)
    ON CONFLICT(id) DO UPDATE SET
      data = excluded.data,
      title = excluded.title,
      updatedAt = excluded.updatedAt,
      createdAt = excluded.createdAt;
  `
  );
  const transaction = db.transaction((pages2) => {
    for (const page of pages2) {
      stmt.run({
        id: `${page.url}:${courseId}`,
        courseId,
        data: JSON.stringify(page),
        title: page.title,
        updatedAt: page.updated_at,
        createdAt: page.created_at
      });
    }
  });
  transaction(pages);
}
function upsertPlannerItems(items) {
  const insertStmt = db.prepare(`
    INSERT INTO planner_items (id, courseId, title, date, data)
    VALUES (@id, @courseId, @title, @date, @data)
    ON CONFLICT(id) DO UPDATE SET
      title = excluded.title,
      date = excluded.date,
      data = excluded.data;
    `);
  const transaction = db.transaction((items2) => {
    for (const item of items2) {
      insertStmt.run({
        id: item.plannable_id,
        courseId: item.course_id,
        title: item.plannable.title,
        date: item.plannable_date,
        data: JSON.stringify(item)
      });
    }
  });
  transaction(items);
}
function getPlannerItems(options = {}) {
  if (!options.page || !options.limit) {
    options.page = 1;
    options.limit = 100;
  }
  if (!options.order) {
    options.order = "asc";
  }
  let where = "";
  if (!!options.courseId) {
    where += "where courseId = ?";
  }
  const plannerItemsStmt = db.prepare(`
    SELECT id, courseId, title, date, data, done, ignored
    FROM planner_items
    ${where}
    ORDER BY date ${options.order.toUpperCase()}
    LIMIT ? OFFSET ?
  `);
  const plannerItemsRows = plannerItemsStmt.all([
    options.courseId,
    options.limit,
    (options.page - 1) * options.limit
  ]);
  return plannerItemsRows.map((row) => ({
    id: row.id,
    courseId: row.courseId,
    title: row.title,
    date: row.date,
    data: JSON.parse(row.data)
  }));
}
function getPlannerItemById(id) {
  const stmt = db.prepare(`
    SELECT id, courseId, title, date, data, done, ignored
    FROM planner_items
    WHERE id = ?
  `);
  const row = stmt.get(id);
  if (!row) return null;
  return {
    id: row.id,
    courseId: row.courseId,
    title: row.title,
    date: row.date,
    done: row.done,
    ignored: row.ignored,
    data: JSON.parse(row.data)
  };
}
function updatePlannerItemById(id, data) {
  const oldData = getPlannerItemById(id);
  if (!oldData) {
    return;
  }
  if (!data.data) {
    data.data = oldData.data;
  }
  if (!data.done) {
    data.done = oldData.done;
  }
  if (!data.ignored) {
    data.ignored = oldData.ignored;
  }
  const stmt = db.prepare(`
    UPDATE planner_items
    SET data = @data, done = @done, ignored = @ignored
    WHERE id = @id
  `);
  stmt.run({ ...data, id });
}
const courseDataFetchers = {
  // announcements: async (client, courseId) => {
  //   const announcements = await client.fetch_announcements([courseId]);
  //   upsertAnnouncements(announcements);
  // },
  // "files" tab might imply fetching root folder, folder listings, and file listings.
  files: async (client, courseId) => {
    const [rootFolder, files, folders] = await Promise.all([
      client.fetch_course_root_folder(courseId),
      client.fetch_course_files(courseId),
      client.fetch_course_folders(courseId)
    ]);
    upsertCourseRootFolderId(courseId, rootFolder.id);
    upsertFolders(folders);
    upsertFiles(files);
  },
  pages: async (client, courseId) => {
    const pages = await client.fetch_course_pages(courseId);
    upsertPages(pages, courseId);
  }
  // syllabus: async (client, courseId) => {
  //   const syllabus = await fetch_course_syllabus(courseId);
  //   updateCourse(courseId, { syllabus_body: syllabus });
  // },
};
const NonTabCourseDataFetchers = [
  async (client, courseId) => {
    const env = await client.fetch_course_home_page(courseId);
    updateCourse(courseId, { ...env });
  },
  async (client, courseId) => {
    const [assignmentGroups, submissions] = await Promise.all([
      client.fetch_course_assignments(courseId),
      client.fetch_course_submissions(courseId)
    ]);
    upsertCourseAssignments(courseId, assignmentGroups);
    upsertSubmissions(submissions);
    syncAssignmentsWithSubmissions(
      assignmentGroups.flatMap((g) => g.assignments.map((a) => a.id))
    );
  }
];
const TabsWithDataFetchers = new Set(Object.keys(courseDataFetchers));
async function fetch_global_course_data(client, courseIds) {
  const [announcements, plannerItems] = await Promise.all([
    client.fetch_announcements(courseIds),
    client.fetch_planner_items({ start_date: "2024-01-01" })
  ]);
  upsertAnnouncements(announcements);
  upsertPlannerItems(plannerItems);
}
async function fetch_single_course_data(client, course) {
  await Promise.all(
    [
      ...course.tabs.map((t) => t.label.toLowerCase()).filter(
        (t) => TabsWithDataFetchers.has(t)
      ).map((t) => courseDataFetchers[t](client, course.id)),
      ...NonTabCourseDataFetchers.map((f) => f(client, course.id))
    ]
  );
}
const APIHandlers = {
  "fetch-main-courses": async () => {
    const client = createCanvasClient();
    let courses = await client.fetch_dashboard_courses();
    upsertCourses(courses);
    setFavoriteCourses(courses.map((c) => c.id));
    updateMenu();
    return courses;
  },
  "fetch-main-course-data": async () => {
    const mainCourses = getPinnedCourses();
    const client = createCanvasClient();
    await Promise.all([
      fetch_global_course_data(client, mainCourses.map((c) => c.id)),
      ...mainCourses.map((c) => fetch_single_course_data(client, c))
    ]);
  },
  "fetch-course-data": async (courseId) => {
    const course = getCourseById(courseId);
    if (!course) {
      console.error(`Course ${courseId} not found`);
      return;
    }
    const client = createCanvasClient();
    fetch_single_course_data(client, course);
  },
  "fetch-course-data-latest": async (courseId) => {
    const client = createCanvasClient();
    const [
      assignmentGroups,
      submissions,
      announcements,
      files,
      folders
    ] = await Promise.all([
      client.fetch_course_assignments(courseId),
      client.fetch_course_submissions(courseId),
      client.fetch_announcements([courseId]),
      client.fetch_course_files(courseId),
      client.fetch_course_folders(courseId)
    ]);
    upsertCourseAssignments(courseId, assignmentGroups);
    upsertSubmissions(submissions);
    upsertAnnouncements(announcements);
    upsertFolders(folders);
    upsertFiles(files);
  },
  "fetch-home-info": async () => {
    try {
      const response = await get_home_info();
      if (!!response) {
        userDataStore.setCurrentCanvasUserData({
          user: response.user,
          canvas_preferences: response.preferences
        });
      }
      return response;
    } catch (e) {
      console.error("Failed to fetch home info:", getErrorMessage(e));
      return null;
    }
  },
  "fetch-all-student-courses": async () => {
    const client = createCanvasClient();
    const [aCourses, cCourses, fCourses] = await Promise.all([
      client.fetch_courses({
        enrollment_type: "student",
        enrollment_state: "active"
      }),
      client.fetch_courses({
        enrollment_type: "student",
        enrollment_state: "completed"
      }),
      client.fetch_dashboard_courses()
    ]);
    const fCourseIdSet = new Set(fCourses.map((c) => c.id));
    const courses = [...aCourses, ...cCourses].map(
      (c) => ({
        ...c,
        is_favorite: fCourseIdSet.has(c.id)
      })
    );
    upsertCourses(courses);
    return courses;
  },
  "fetch-course-assignments": async (courseId) => {
    const client = createCanvasClient();
    const [assignments, submissions] = await Promise.all([
      client.fetch_course_assignments(courseId),
      client.fetch_course_submissions(courseId)
    ]);
    upsertCourseAssignments(courseId, assignments);
    upsertSubmissions(submissions);
    return getCourseAssignmentGroups(courseId);
  },
  "fetch-course-announcements": async (courseId) => {
    const response = await fetch_course_announcements(courseId);
    upsertAnnouncements(response);
    return response;
  },
  "fetch-course-syllabus": async (courseId) => {
    const response = await fetch_course_syllabus(courseId);
    return response;
  },
  "fetch-assignment-detail": async (assignmentId) => {
    const client = createCanvasClient();
    const aData = await getAssignmentById(assignmentId);
    if (!aData) return null;
    const description = await client.fetch_assignment_description(
      // aData.id,
      aData.html_url
    );
    return { ...aData, description };
  },
  "fetch-course-files": async (courseId) => {
    const client = createCanvasClient();
    const rootFolderIdFromDb = getCourseRootFolderId(courseId);
    const [files, folders, rootFolderId] = await Promise.all([
      client.fetch_course_files(courseId),
      client.fetch_course_folders(courseId),
      new Promise((resolve) => {
        if (rootFolderIdFromDb) {
          resolve(rootFolderIdFromDb);
        } else {
          client.fetch_course_root_folder(courseId).then((rootFolder) => {
            upsertCourseRootFolderId(courseId, rootFolder.id);
            resolve(rootFolder.id);
          });
        }
      })
    ]);
    upsertFolders(folders);
    upsertFiles(files);
    return {
      files,
      folders,
      rootFolderId
    };
  },
  "fetch-course-pages": async (courseId) => {
    const client = createCanvasClient();
    const pages = await client.fetch_course_pages(courseId);
    upsertPages(pages, courseId);
    return pages;
  },
  "set-course-color": async (courseId, color) => {
    const client = createCanvasClient();
    await client.set_course_color(courseId, color);
  },
  "download-file": async (fileId) => {
    const client = createCanvasClient();
    const f = getFileById(fileId);
    if (!f) {
      console.error(`File ${fileId} not found`);
      return null;
    }
    const filepath = await client.download_file(f.url, "./" + f.display_name);
    electron.shell.openPath(filepath);
    return filepath;
  },
  "set-course-favorite": async (courseId, isFavorite) => {
    const client = createCanvasClient();
    await client.set_course_favorite(courseId, isFavorite);
  },
  "search-universities-by-name": async (name) => {
    const universities = await search_universities_by_name(name);
    return universities;
  },
  "search-universities-by-domain": async (domain) => {
    const universities = await search_universities_by_domain(domain);
    return universities;
  },
  logout: async () => {
    userDataStore.canvasLogoutCurrentUser();
  }
};
const POSTHOG_ID_FILENAME = require$$1.join(
  electron.app.getPath("userData"),
  "posthog.json"
);
const posthog = new posthogNode.PostHog(
  "phc_HL4vvIv8ExFUd77UgNtpqZL3ZDYECUW6WHNh5uMEkyo",
  { host: "https://us.i.posthog.com" }
);
function writeNewUUID() {
  const uuid = crypto.randomUUID();
  fs.writeFileSync(
    POSTHOG_ID_FILENAME,
    JSON.stringify({
      uuid
    })
  );
  return uuid;
}
function getUUID() {
  const fileData = JSON.parse(
    fs.readFileSync(POSTHOG_ID_FILENAME, "utf-8")
  );
  return fileData.uuid;
}
function initializePosthog() {
  let uuid;
  if (!fs.existsSync(POSTHOG_ID_FILENAME)) {
    uuid = writeNewUUID();
  } else {
    const fileData = JSON.parse(
      fs.readFileSync(POSTHOG_ID_FILENAME, "utf-8")
    );
    uuid = fileData.uuid;
    if (typeof uuid !== "string") {
      uuid = writeNewUUID();
    }
  }
  posthog.identify({
    distinctId: uuid
  });
}
function sendStartUpEvent({
  startup_time: startup_time2
}) {
  posthog.capture({
    distinctId: getUUID(),
    event: "Start Up",
    properties: {
      app_version: electron.app.getVersion(),
      platform: process.platform,
      arch: process.arch,
      is_packaged: electron.app.isPackaged,
      node_version: process.versions.node,
      electron_version: process.versions.electron,
      startup_time: startup_time2
    }
  });
}
function sendCanvasLoginSuccessEvent() {
  posthog.capture({
    distinctId: getUUID(),
    event: "Canvas Login Success"
  });
}
const WINDOW_WIDTH = 900;
const WINDOW_HEIGHT = 600;
async function handleCanvasLogin(window2) {
  const ses = electron.session.fromPartition(CANVAS_SESSION_PARTITION_KEY);
  const cookies = await ses.cookies.get({});
  const canvasUserData = extractCanvasUserDataFromCookies(cookies);
  const html = await window2.webContents.executeJavaScript(
    `document.documentElement.innerHTML`
  );
  const info = extract_home_env_info_from_html(html);
  if (!info) {
    throw new Error("Failed to parse home info");
  }
  userDataStore.canvasLogin(
    info.user.id,
    canvasUserData.hostname,
    canvasUserData.session
  );
  userDataStore.setCurrentCanvasUserData({
    user: info.user,
    canvas_preferences: info.preferences
  });
}
function openCanvasLoginWindow(hostname) {
  const _mainWindow = new electron.BrowserWindow({
    width: WINDOW_WIDTH,
    height: WINDOW_HEIGHT,
    title: "Canvas Login",
    backgroundMaterial: "auto",
    backgroundColor: "#00000000",
    show: false,
    ...process.platform === "linux" ? { icon } : {},
    webPreferences: {
      preload: require$$1.join(__dirname, "../preload/index.js"),
      sandbox: false,
      partition: CANVAS_SESSION_PARTITION_KEY,
      nodeIntegration: true,
      webviewTag: true
      // devTools: true,
    }
  });
  _mainWindow.on("ready-to-show", () => {
    _mainWindow.show();
  });
  _mainWindow.on("close", () => {
    loadMainWindow();
  });
  _mainWindow.webContents.setWindowOpenHandler((details) => {
    electron.shell.openExternal(details.url);
    return { action: "deny" };
  });
  _mainWindow.webContents.on("did-navigate", async (event, url) => {
    console.log("did-navigate", url);
    const domain = getDomainFromUrl(url);
    const currentCanvasHost = userDataStore.getCurrentCanvasHost();
    if (domain === currentCanvasHost) {
      console.log("Login success");
      sendCanvasLoginSuccessEvent();
      await handleCanvasLogin(_mainWindow);
      _mainWindow.close();
      loadMainWindow();
    }
  });
  _mainWindow.loadURL(`https://${hostname}`);
  return _mainWindow;
}
const NavHandlers = {
  "to-canvas-login": async (hostname) => {
    userDataStore.setCurrentCanvasHost(hostname);
    openCanvasLoginWindow(hostname);
  },
  "open-external": async (url) => {
    electron.shell.openExternal(url);
  },
  "close-window": async () => {
    getMainWindow()?.close();
  },
  "maximize-window": async () => {
    const mainWindow2 = getMainWindow();
    if (!mainWindow2) return;
    if (mainWindow2.isMaximized()) {
      mainWindow2.unmaximize();
    } else {
      mainWindow2.maximize();
    }
  },
  "minimize-window": async () => {
    const mainWindow2 = getMainWindow();
    if (!mainWindow2) return;
    mainWindow2.minimize();
  }
};
function searchAllItems(searchTerm) {
  const assignments = getAssignments({ searchTerm });
  const files = getFiles({ searchTerm });
  const courses = getCourses({ searchTerm });
  return {
    assignments,
    files,
    courses
  };
}
const StoreHandlers = {
  /**
   * *******************************
   * User Data Queries
   * *******************************
   */
  "get-current-user-data": async () => {
    return userDataStore.getCurrentUserData();
  },
  "get-canvas-current-user-data": async () => {
    return userDataStore.getCurrentCanvasUserData();
  },
  "get-current-canvas-host": async () => {
    return userDataStore.getCurrentCanvasHost();
  },
  /**
   * *******************************
   * Course Queries
   * *******************************
   */
  "get-all-courses": async () => {
    const response = await getAllCourses();
    return response;
  },
  "get-main-courses": async () => {
    const response = await getPinnedCourses();
    return response;
  },
  "get-course-by-id": async (courseId) => {
    const response = await getCourseById(courseId);
    return response;
  },
  /**
   * *******************************
   * Assignment Queries
   * *******************************
   */
  "get-course-assignments": async (courseId) => {
    return getCourseAssignmentGroups(courseId);
  },
  "get-assignments": async (options) => {
    return getAssignments(options);
  },
  "get-course-assignments-summary": async (courseId) => {
    return getCourseAssignmentsSummary(courseId);
  },
  "get-assignment-by-id": async (id) => {
    return getAssignmentById(id);
  },
  "update-assignment-by-id": async (id, data) => {
    return updateAssignmentById(id, data);
  },
  /**
   * *******************************
   * Announcement Queries
   * *******************************
   */
  "get-announcements": async (options) => {
    return getAnnouncements(options);
  },
  "get-announcement-by-id": async (id) => {
    return getAnnouncementById(id);
  },
  /**
   * *******************************
   * Planner Queries
   * *******************************
   */
  "get-planner-items": async (options) => {
    return getPlannerItems(options);
  },
  "update-planner-item": async (id, data) => {
    return updatePlannerItemById(id, data);
  },
  /**
   * *******************************
   * File & Folder Queries
   * *******************************
   */
  "get-course-root-folder-id": async (courseId) => {
    return getCourseRootFolderId(courseId);
  },
  "get-items-by-folder-id": async (folderId) => {
    const { files, folders } = getItemsByFolderId(folderId);
    const parentFolders = getRecursiveParentFolders(folderId);
    return {
      files,
      folders,
      parentFolders
    };
  },
  /**
   * *******************************
   * Search Queries
   * *******************************
   */
  "search-items": async (query) => {
    return searchAllItems(query);
  },
  /**
   * *******************************
   * Settings
   * *******************************
   */
  "save-settings": async (settings) => {
    console.log("Saving settings...");
    userDataStore.saveCurrentUserSettings(settings);
  }
};
const setupHandlers = (handleMap) => {
  Object.entries(handleMap).forEach(([key, handler]) => {
    electron.ipcMain.handle(key, (_key, ...args) => {
      return handler(...args);
    });
  });
};
function setupAllIpcRoutes() {
  setupHandlers(APIHandlers);
  setupHandlers(StoreHandlers);
  setupHandlers(NavHandlers);
}
function getUpdater() {
  const { autoUpdater } = electronUpdater;
  return autoUpdater;
}
class AutoUpdater {
  updater;
  constructor() {
    this.updater = getUpdater();
    this.updater.forceDevUpdateConfig = true;
  }
  setup(mainWindow2) {
    this.updater.on("checking-for-update", () => {
      log.info("Checking for update...");
      mainWindow2.webContents.send("checking-for-update");
    });
    this.updater.on("update-available", (info) => {
      log.info("Update available.", info);
      mainWindow2.webContents.send("update-available", info);
    });
    this.updater.on("update-not-available", (info) => {
      log.info("Update not available.", info);
    });
    this.updater.on("error", (err) => {
      log.error("Error in auto-updater.", err);
    });
    this.updater.on("download-progress", (progressObj) => {
      let logMessage = `Download speed: ${progressObj.bytesPerSecond}`;
      logMessage += ` - Downloaded ${progressObj.percent}%`;
      logMessage += ` (${progressObj.transferred}/${progressObj.total})`;
      log.info(logMessage);
    });
    this.updater.on("update-downloaded", (info) => {
      log.log("Update downloaded", info);
      mainWindow2.webContents.send("update-downloaded", info);
    });
    electron.ipcMain.on("restart-and-update", () => {
      log.log("Restarting and updating...");
      setTimeout(() => {
        this.updater.quitAndInstall();
      }, 1e3);
    });
    electron.ipcMain.on("check-update", () => {
      log.log("Checking for update...");
      this.updater.checkForUpdatesAndNotify();
    });
  }
}
const startup_time = performance.now();
const updater = new AutoUpdater();
electron.app.whenReady().then(() => {
  electron.app.setName("My Canvas");
  utils.electronApp.setAppUserModelId("com.mycanvas.app");
  electron.app.on("browser-window-created", (_, window) => {
    utils.optimizer.watchWindowShortcuts(window);
  });
  setupAllIpcRoutes();
  updateMenu();
  const mainWindow2 = createMainWindow();
  updater.setup(mainWindow2);
  electron.app.on("activate", function() {
    if (electron.BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
  initializePosthog();
  sendStartUpEvent({ startup_time: performance.now() - startup_time });
});
electron.app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    electron.app.quit();
  }
});
electron.app.on("before-quit", () => {
  posthog.shutdown();
});
