"use strict";
const electron = require("electron");
const utils$2 = require("@electron-toolkit/utils");
const path$d = require("path");
require("color");
require("date-fns");
const fs$k = require("fs");
const electronUpdater = require("electron-updater");
const log = require("electron-log/main");
const require$$0 = require("constants");
const require$$0$1 = require("stream");
const require$$4 = require("util");
const require$$5 = require("assert");
const unzipper = require("unzipper");
const axios = require("axios");
const jsdom = require("jsdom");
const Database = require("better-sqlite3");
const posthogNode = require("posthog-node");
const crypto = require("crypto");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const path__namespace = /* @__PURE__ */ _interopNamespaceDefault(path$d);
const fs__namespace = /* @__PURE__ */ _interopNamespaceDefault(fs$k);
const icon = path$d.join(__dirname, "../../resources/icon.png");
function getDomainFromUrl(url) {
  const urlObject = new URL(url);
  return urlObject.hostname;
}
function getCurrentWeekDays(today) {
  if (!today) {
    today = /* @__PURE__ */ new Date();
  }
  const currentDayIndex = today.getDay();
  const currentWeek = [];
  for (let i = 0; i < 7; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() - currentDayIndex + i);
    currentWeek.push(date);
  }
  return currentWeek;
}
console.log(getCurrentWeekDays());
function getDateString(date) {
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "numeric",
    day: "numeric"
  });
}
function toISODatetimeString(s) {
  const d = new Date(s);
  return d.toISOString().slice(0, 19) + "Z";
}
function getHostnameFromCookies(cookies) {
  const hostname = cookies.find(
    (cookie) => cookie.name === "last_known_canvas_host"
  )?.value;
  return hostname ?? "";
}
function getCsrfTokenFromCookies(cookies) {
  const csrfToken = cookies.find((cookie) => cookie.name === "_csrf_token")?.value;
  return decodeURIComponent(csrfToken ?? "");
}
function getCanvasUserIdFromCookies(cookies) {
  const canvasUserId = cookies.find(
    (cookie) => cookie.name === "canvas_user_id"
  )?.value;
  return decodeURIComponent(canvasUserId ?? "");
}
function extractCanvasUserDataFromCookies(cookies) {
  return {
    hostname: getHostnameFromCookies(cookies),
    user_id: getCanvasUserIdFromCookies(cookies),
    user: null,
    session: {
      cookies,
      csrfToken: getCsrfTokenFromCookies(cookies)
    },
    canvas_preferences: {
      custom_colors: {}
    }
  };
}
function getErrorMessage(err) {
  if (err instanceof Error) {
    return err.message;
  } else {
    return String(err);
  }
}
const CANVAS_SESSION_PARTITION_KEY = "persist:loginSession";
const DefaultThemeSets = [{
  "name": "Uniform Dark",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 1,
  "main_content_bg_color": "#1c1c1c",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#050505",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#f5f5f5",
  "font_color_active": "#000000",
  "is_dark": true
}, {
  "name": "Uniform Light",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#141414",
  "main_content_opacity": 1,
  "main_content_bg_color": "#ffffff",
  "window_background_image": "",
  "window_background_overlay": 0.25,
  "window_background_color": "#ffffff",
  "window_background_color_opacity": 1,
  "window_background_type": "color",
  "primary_color": "#f2f2f2",
  "font_color_active": "#000000",
  "is_dark": false
}, {
  "name": "Dark Blue",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#e9ecfb",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#000419",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#031149",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#132aa0",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Dark Purple",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#fdfaff",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#0e0014",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#34004d",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#810ab8",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Dark Red",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#f5e6e6",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#000000",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#490303",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#a01313",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Dark Cyan",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#e5f5f5",
  "main_content_opacity": 0.94,
  "main_content_bg_color": "#000a0a",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#003832",
  "window_background_color_opacity": 0.83,
  "window_background_type": "color",
  "primary_color": "#008077",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Galaxy",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.6,
  "main_content_bg_color": "#0a0a0a",
  "window_background_image": "https://images.unsplash.com/photo-1538370965046-79c0d6907d47?q=80&w=3269&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.22,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.75,
  "window_background_type": "image",
  "primary_color": "#375ed2",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Night Sky",
  "font_family": "geometric-humanist",
  "font_size": 16,
  "font_color": "#d7d5f0",
  "main_content_opacity": 0.6,
  "main_content_bg_color": "#000000",
  "window_background_image": "https://images.unsplash.com/photo-1444080748397-f442aa95c3e5?q=80&w=3264&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.22,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.75,
  "window_background_type": "image",
  "primary_color": "#28309f",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Aurora",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.6,
  "main_content_bg_color": "#000500",
  "window_background_image": "https://images.unsplash.com/photo-1488415032361-b7e238421f1b?q=80&w=3269&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.22,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.73,
  "window_background_type": "image",
  "primary_color": "#25ad4d",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Mountain Blue",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.63,
  "main_content_bg_color": "#0d0d0d",
  "window_background_image": "https://images.unsplash.com/photo-1480241352829-e1573ff2414e?q=80&w=3270&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "window_background_overlay": 0.17,
  "window_background_color": "#fff",
  "window_background_color_opacity": 0.24,
  "window_background_type": "image",
  "primary_color": "#2d6cbe",
  "font_color_active": "#ffffff",
  "is_dark": true
}, {
  "name": "Transparent Light",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#141414",
  "main_content_opacity": 1,
  "main_content_bg_color": "#ffffff",
  "window_background_image": "",
  "window_background_overlay": 0.25,
  "window_background_color": "#ffffff",
  "window_background_color_opacity": 0.51,
  "window_background_type": "color",
  "primary_color": "#f2f2f2",
  "font_color_active": "#000000",
  "is_dark": false
}, {
  "name": "Transparent Dark",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#ffffff",
  "main_content_opacity": 0.9,
  "main_content_bg_color": "#000000",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#000000",
  "window_background_color_opacity": 0.42,
  "window_background_type": "color",
  "primary_color": "#ffffff",
  "font_color_active": "#000000",
  "is_dark": true
}, {
  "name": "Light Blue",
  "font_family": "neo-grotesque",
  "font_size": 16,
  "font_color": "#000314",
  "main_content_opacity": 1,
  "main_content_bg_color": "#fafbff",
  "window_background_image": "",
  "window_background_overlay": 0.22,
  "window_background_color": "#ccd6ff",
  "window_background_color_opacity": 1,
  "window_background_type": "color",
  "primary_color": "#516cf0",
  "font_color_active": "#ffffff",
  "is_dark": false
}];
({
  ...DefaultThemeSets[0],
  name: "New Theme"
});
const INITIAL_SETTINGS = {
  theme: DefaultThemeSets[0],
  courses: {},
  show_course_card_image: true,
  dashboard_course_display_type: "favorite",
  show_assignment_due_date_threshold: 24 * 3,
  urgent_assignment_threshold: 24,
  warning_assignment_threshold: 48
};
const USER_DATA_STORE_FILENAME = "user-data.json";
function getUserDataKey(userId, hostname) {
  return `${userId}-${hostname}`;
}
const EMPTY_CANVAS_PREFERENCES = {
  custom_colors: {}
};
const DEFAULT_USER_DATA = {
  currentCanvasUserKey: null,
  currentCanvasHost: null,
  users: []
};
class UserDataStore {
  filePath;
  constructor() {
    this.filePath = path__namespace.join(
      electron.app.getPath("userData"),
      USER_DATA_STORE_FILENAME
    );
    if (utils$2.is.dev) {
      console.log("User data store path:", this.filePath);
    }
    if (!fs__namespace.existsSync(this.filePath)) {
      fs__namespace.writeFileSync(
        this.filePath,
        JSON.stringify(DEFAULT_USER_DATA),
        "utf-8"
      );
    }
  }
  /**
   * Reads data from the storage file.
   * @returns {Record<string, T>} The parsed JSON data from the file.
   */
  _readFile() {
    try {
      const data = fs__namespace.readFileSync(this.filePath, "utf-8");
      return JSON.parse(data);
    } catch (error) {
      console.error("Failed to read storage file:", error);
      return DEFAULT_USER_DATA;
    }
  }
  /**
   * Writes data to the storage file.
   * @param {Record<string, T>} data The data to write to the file.
   */
  _writeFile(data) {
    try {
      fs__namespace.writeFileSync(this.filePath, JSON.stringify(data, null, 2), "utf-8");
    } catch (error) {
      console.error("Failed to write to storage file:", error);
    }
  }
  getUserByCanvasUserKey(key) {
    const data = this._readFile();
    return data.users.find(
      (u2) => `${u2.canvas.user_id}-${u2.canvas.hostname}` === key
    );
  }
  getCurrentUserIndex() {
    const data = this._readFile();
    const currentCanvasUserKey = data.currentCanvasUserKey;
    if (!currentCanvasUserKey) {
      return -1;
    }
    return data.users.findIndex(
      (u2) => `${u2.canvas.user_id}-${u2.canvas.hostname}` === currentCanvasUserKey
    );
  }
  getCurrentUserData() {
    const data = this._readFile();
    const currentCanvasUserKey = data.currentCanvasUserKey;
    if (!currentCanvasUserKey) {
      return null;
    }
    const u2 = this.getUserByCanvasUserKey(currentCanvasUserKey);
    if (!u2) {
      return null;
    }
    return u2;
  }
  getCurrentCanvasUserData() {
    return this.getCurrentUserData()?.canvas ?? null;
  }
  getCurrentCanvasUserId() {
    const data = this._readFile();
    if (!data.currentCanvasUserKey) {
      return null;
    }
    const u2 = this.getUserByCanvasUserKey(data.currentCanvasUserKey);
    return !!u2 ? u2.canvas.user_id : null;
  }
  getCurrentCanvasHost() {
    const data = this._readFile();
    return data.currentCanvasHost;
  }
  setCurrentCanvasHost(hostname) {
    const data = this._readFile();
    data.currentCanvasHost = hostname;
    this._writeFile(data);
  }
  setCurrentCanvasUserData(newCanvasUserData) {
    const data = this._readFile();
    const newData = {
      ...data,
      users: data.users.map((u2) => {
        if (getUserDataKey(u2.canvas.user_id, u2.canvas.hostname) === data.currentCanvasUserKey) {
          return {
            ...u2,
            canvas: {
              ...u2.canvas,
              ...newCanvasUserData
            }
          };
        }
        return u2;
      })
    };
    this._writeFile(newData);
  }
  saveCurrentUserSettings(settings) {
    const data = this._readFile();
    const idx = this.getCurrentUserIndex();
    const newData = {
      ...data,
      users: data.users.map((u2, i) => i === idx ? { ...u2, settings } : u2)
    };
    this._writeFile(newData);
  }
  canvasLogin(userId, hostname, session) {
    const data = this._readFile();
    const key = getUserDataKey(userId, hostname);
    const u2 = this.getUserByCanvasUserKey(key);
    let newUsers = [...data.users];
    if (!u2) {
      newUsers.push({
        canvas: {
          session,
          user_id: userId,
          user: null,
          hostname,
          canvas_preferences: EMPTY_CANVAS_PREFERENCES
        },
        settings: INITIAL_SETTINGS
      });
    } else {
      newUsers = data.users.map((u22) => {
        if (u22.canvas.user_id === userId && u22.canvas.hostname === hostname) {
          return {
            ...u22,
            canvas: {
              ...u22.canvas,
              session
            }
          };
        }
        return u22;
      });
    }
    this._writeFile({
      currentCanvasHost: hostname,
      currentCanvasUserKey: key,
      users: newUsers
    });
  }
  updateCurrentUserCanvasCookies(cookies) {
    const u2 = this.getCurrentCanvasUserData();
    if (!u2) {
      return;
    }
    const { session } = extractCanvasUserDataFromCookies(cookies);
    this.setCurrentCanvasUserData({
      session
    });
  }
  canvasLogoutCurrentUser() {
    const data = this._readFile();
    const u2 = this.getCurrentCanvasUserData();
    if (!u2) {
      return;
    }
    u2.session = null;
    data.currentCanvasUserKey = null;
    this._writeFile(data);
  }
}
const userDataStore = new UserDataStore();
const RELEASE_REPO_NAME = "BowangLan/my-canvas-releases";
const PRELOAD_PATH = path$d.join(__dirname, "../preload/index.js");
const MAIN_WINDOW_HTML_PATH = path$d.join(electron.app.getPath("userData"), "assets/renderer/index.html");
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
var fs$j = {};
var universalify$1 = {};
universalify$1.fromCallback = function(fn) {
  return Object.defineProperty(function(...args) {
    if (typeof args[args.length - 1] === "function") fn.apply(this, args);
    else {
      return new Promise((resolve, reject) => {
        args.push((err, res) => err != null ? reject(err) : resolve(res));
        fn.apply(this, args);
      });
    }
  }, "name", { value: fn.name });
};
universalify$1.fromPromise = function(fn) {
  return Object.defineProperty(function(...args) {
    const cb = args[args.length - 1];
    if (typeof cb !== "function") return fn.apply(this, args);
    else {
      args.pop();
      fn.apply(this, args).then((r) => cb(null, r), cb);
    }
  }, "name", { value: fn.name });
};
var constants = require$$0;
var origCwd = process.cwd;
var cwd = null;
var platform = process.env.GRACEFUL_FS_PLATFORM || process.platform;
process.cwd = function() {
  if (!cwd)
    cwd = origCwd.call(process);
  return cwd;
};
try {
  process.cwd();
} catch (er) {
}
if (typeof process.chdir === "function") {
  var chdir = process.chdir;
  process.chdir = function(d) {
    cwd = null;
    chdir.call(process, d);
  };
  if (Object.setPrototypeOf) Object.setPrototypeOf(process.chdir, chdir);
}
var polyfills$1 = patch$1;
function patch$1(fs2) {
  if (constants.hasOwnProperty("O_SYMLINK") && process.version.match(/^v0\.6\.[0-2]|^v0\.5\./)) {
    patchLchmod(fs2);
  }
  if (!fs2.lutimes) {
    patchLutimes(fs2);
  }
  fs2.chown = chownFix(fs2.chown);
  fs2.fchown = chownFix(fs2.fchown);
  fs2.lchown = chownFix(fs2.lchown);
  fs2.chmod = chmodFix(fs2.chmod);
  fs2.fchmod = chmodFix(fs2.fchmod);
  fs2.lchmod = chmodFix(fs2.lchmod);
  fs2.chownSync = chownFixSync(fs2.chownSync);
  fs2.fchownSync = chownFixSync(fs2.fchownSync);
  fs2.lchownSync = chownFixSync(fs2.lchownSync);
  fs2.chmodSync = chmodFixSync(fs2.chmodSync);
  fs2.fchmodSync = chmodFixSync(fs2.fchmodSync);
  fs2.lchmodSync = chmodFixSync(fs2.lchmodSync);
  fs2.stat = statFix(fs2.stat);
  fs2.fstat = statFix(fs2.fstat);
  fs2.lstat = statFix(fs2.lstat);
  fs2.statSync = statFixSync(fs2.statSync);
  fs2.fstatSync = statFixSync(fs2.fstatSync);
  fs2.lstatSync = statFixSync(fs2.lstatSync);
  if (fs2.chmod && !fs2.lchmod) {
    fs2.lchmod = function(path2, mode, cb) {
      if (cb) process.nextTick(cb);
    };
    fs2.lchmodSync = function() {
    };
  }
  if (fs2.chown && !fs2.lchown) {
    fs2.lchown = function(path2, uid, gid, cb) {
      if (cb) process.nextTick(cb);
    };
    fs2.lchownSync = function() {
    };
  }
  if (platform === "win32") {
    fs2.rename = typeof fs2.rename !== "function" ? fs2.rename : function(fs$rename) {
      function rename2(from, to, cb) {
        var start = Date.now();
        var backoff = 0;
        fs$rename(from, to, function CB(er) {
          if (er && (er.code === "EACCES" || er.code === "EPERM" || er.code === "EBUSY") && Date.now() - start < 6e4) {
            setTimeout(function() {
              fs2.stat(to, function(stater, st) {
                if (stater && stater.code === "ENOENT")
                  fs$rename(from, to, CB);
                else
                  cb(er);
              });
            }, backoff);
            if (backoff < 100)
              backoff += 10;
            return;
          }
          if (cb) cb(er);
        });
      }
      if (Object.setPrototypeOf) Object.setPrototypeOf(rename2, fs$rename);
      return rename2;
    }(fs2.rename);
  }
  fs2.read = typeof fs2.read !== "function" ? fs2.read : function(fs$read) {
    function read(fd, buffer, offset, length, position, callback_) {
      var callback;
      if (callback_ && typeof callback_ === "function") {
        var eagCounter = 0;
        callback = function(er, _, __) {
          if (er && er.code === "EAGAIN" && eagCounter < 10) {
            eagCounter++;
            return fs$read.call(fs2, fd, buffer, offset, length, position, callback);
          }
          callback_.apply(this, arguments);
        };
      }
      return fs$read.call(fs2, fd, buffer, offset, length, position, callback);
    }
    if (Object.setPrototypeOf) Object.setPrototypeOf(read, fs$read);
    return read;
  }(fs2.read);
  fs2.readSync = typeof fs2.readSync !== "function" ? fs2.readSync : /* @__PURE__ */ function(fs$readSync) {
    return function(fd, buffer, offset, length, position) {
      var eagCounter = 0;
      while (true) {
        try {
          return fs$readSync.call(fs2, fd, buffer, offset, length, position);
        } catch (er) {
          if (er.code === "EAGAIN" && eagCounter < 10) {
            eagCounter++;
            continue;
          }
          throw er;
        }
      }
    };
  }(fs2.readSync);
  function patchLchmod(fs22) {
    fs22.lchmod = function(path2, mode, callback) {
      fs22.open(
        path2,
        constants.O_WRONLY | constants.O_SYMLINK,
        mode,
        function(err, fd) {
          if (err) {
            if (callback) callback(err);
            return;
          }
          fs22.fchmod(fd, mode, function(err2) {
            fs22.close(fd, function(err22) {
              if (callback) callback(err2 || err22);
            });
          });
        }
      );
    };
    fs22.lchmodSync = function(path2, mode) {
      var fd = fs22.openSync(path2, constants.O_WRONLY | constants.O_SYMLINK, mode);
      var threw = true;
      var ret;
      try {
        ret = fs22.fchmodSync(fd, mode);
        threw = false;
      } finally {
        if (threw) {
          try {
            fs22.closeSync(fd);
          } catch (er) {
          }
        } else {
          fs22.closeSync(fd);
        }
      }
      return ret;
    };
  }
  function patchLutimes(fs22) {
    if (constants.hasOwnProperty("O_SYMLINK") && fs22.futimes) {
      fs22.lutimes = function(path2, at, mt, cb) {
        fs22.open(path2, constants.O_SYMLINK, function(er, fd) {
          if (er) {
            if (cb) cb(er);
            return;
          }
          fs22.futimes(fd, at, mt, function(er2) {
            fs22.close(fd, function(er22) {
              if (cb) cb(er2 || er22);
            });
          });
        });
      };
      fs22.lutimesSync = function(path2, at, mt) {
        var fd = fs22.openSync(path2, constants.O_SYMLINK);
        var ret;
        var threw = true;
        try {
          ret = fs22.futimesSync(fd, at, mt);
          threw = false;
        } finally {
          if (threw) {
            try {
              fs22.closeSync(fd);
            } catch (er) {
            }
          } else {
            fs22.closeSync(fd);
          }
        }
        return ret;
      };
    } else if (fs22.futimes) {
      fs22.lutimes = function(_a, _b, _c, cb) {
        if (cb) process.nextTick(cb);
      };
      fs22.lutimesSync = function() {
      };
    }
  }
  function chmodFix(orig) {
    if (!orig) return orig;
    return function(target, mode, cb) {
      return orig.call(fs2, target, mode, function(er) {
        if (chownErOk(er)) er = null;
        if (cb) cb.apply(this, arguments);
      });
    };
  }
  function chmodFixSync(orig) {
    if (!orig) return orig;
    return function(target, mode) {
      try {
        return orig.call(fs2, target, mode);
      } catch (er) {
        if (!chownErOk(er)) throw er;
      }
    };
  }
  function chownFix(orig) {
    if (!orig) return orig;
    return function(target, uid, gid, cb) {
      return orig.call(fs2, target, uid, gid, function(er) {
        if (chownErOk(er)) er = null;
        if (cb) cb.apply(this, arguments);
      });
    };
  }
  function chownFixSync(orig) {
    if (!orig) return orig;
    return function(target, uid, gid) {
      try {
        return orig.call(fs2, target, uid, gid);
      } catch (er) {
        if (!chownErOk(er)) throw er;
      }
    };
  }
  function statFix(orig) {
    if (!orig) return orig;
    return function(target, options, cb) {
      if (typeof options === "function") {
        cb = options;
        options = null;
      }
      function callback(er, stats) {
        if (stats) {
          if (stats.uid < 0) stats.uid += 4294967296;
          if (stats.gid < 0) stats.gid += 4294967296;
        }
        if (cb) cb.apply(this, arguments);
      }
      return options ? orig.call(fs2, target, options, callback) : orig.call(fs2, target, callback);
    };
  }
  function statFixSync(orig) {
    if (!orig) return orig;
    return function(target, options) {
      var stats = options ? orig.call(fs2, target, options) : orig.call(fs2, target);
      if (stats) {
        if (stats.uid < 0) stats.uid += 4294967296;
        if (stats.gid < 0) stats.gid += 4294967296;
      }
      return stats;
    };
  }
  function chownErOk(er) {
    if (!er)
      return true;
    if (er.code === "ENOSYS")
      return true;
    var nonroot = !process.getuid || process.getuid() !== 0;
    if (nonroot) {
      if (er.code === "EINVAL" || er.code === "EPERM")
        return true;
    }
    return false;
  }
}
var Stream = require$$0$1.Stream;
var legacyStreams = legacy$1;
function legacy$1(fs2) {
  return {
    ReadStream,
    WriteStream
  };
  function ReadStream(path2, options) {
    if (!(this instanceof ReadStream)) return new ReadStream(path2, options);
    Stream.call(this);
    var self2 = this;
    this.path = path2;
    this.fd = null;
    this.readable = true;
    this.paused = false;
    this.flags = "r";
    this.mode = 438;
    this.bufferSize = 64 * 1024;
    options = options || {};
    var keys = Object.keys(options);
    for (var index = 0, length = keys.length; index < length; index++) {
      var key = keys[index];
      this[key] = options[key];
    }
    if (this.encoding) this.setEncoding(this.encoding);
    if (this.start !== void 0) {
      if ("number" !== typeof this.start) {
        throw TypeError("start must be a Number");
      }
      if (this.end === void 0) {
        this.end = Infinity;
      } else if ("number" !== typeof this.end) {
        throw TypeError("end must be a Number");
      }
      if (this.start > this.end) {
        throw new Error("start must be <= end");
      }
      this.pos = this.start;
    }
    if (this.fd !== null) {
      process.nextTick(function() {
        self2._read();
      });
      return;
    }
    fs2.open(this.path, this.flags, this.mode, function(err, fd) {
      if (err) {
        self2.emit("error", err);
        self2.readable = false;
        return;
      }
      self2.fd = fd;
      self2.emit("open", fd);
      self2._read();
    });
  }
  function WriteStream(path2, options) {
    if (!(this instanceof WriteStream)) return new WriteStream(path2, options);
    Stream.call(this);
    this.path = path2;
    this.fd = null;
    this.writable = true;
    this.flags = "w";
    this.encoding = "binary";
    this.mode = 438;
    this.bytesWritten = 0;
    options = options || {};
    var keys = Object.keys(options);
    for (var index = 0, length = keys.length; index < length; index++) {
      var key = keys[index];
      this[key] = options[key];
    }
    if (this.start !== void 0) {
      if ("number" !== typeof this.start) {
        throw TypeError("start must be a Number");
      }
      if (this.start < 0) {
        throw new Error("start must be >= zero");
      }
      this.pos = this.start;
    }
    this.busy = false;
    this._queue = [];
    if (this.fd === null) {
      this._open = fs2.open;
      this._queue.push([this._open, this.path, this.flags, this.mode, void 0]);
      this.flush();
    }
  }
}
var clone_1 = clone$1;
var getPrototypeOf = Object.getPrototypeOf || function(obj) {
  return obj.__proto__;
};
function clone$1(obj) {
  if (obj === null || typeof obj !== "object")
    return obj;
  if (obj instanceof Object)
    var copy2 = { __proto__: getPrototypeOf(obj) };
  else
    var copy2 = /* @__PURE__ */ Object.create(null);
  Object.getOwnPropertyNames(obj).forEach(function(key) {
    Object.defineProperty(copy2, key, Object.getOwnPropertyDescriptor(obj, key));
  });
  return copy2;
}
var fs$i = fs$k;
var polyfills = polyfills$1;
var legacy = legacyStreams;
var clone = clone_1;
var util$1 = require$$4;
var gracefulQueue;
var previousSymbol;
if (typeof Symbol === "function" && typeof Symbol.for === "function") {
  gracefulQueue = Symbol.for("graceful-fs.queue");
  previousSymbol = Symbol.for("graceful-fs.previous");
} else {
  gracefulQueue = "___graceful-fs.queue";
  previousSymbol = "___graceful-fs.previous";
}
function noop() {
}
function publishQueue(context, queue2) {
  Object.defineProperty(context, gracefulQueue, {
    get: function() {
      return queue2;
    }
  });
}
var debug = noop;
if (util$1.debuglog)
  debug = util$1.debuglog("gfs4");
else if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || ""))
  debug = function() {
    var m = util$1.format.apply(util$1, arguments);
    m = "GFS4: " + m.split(/\n/).join("\nGFS4: ");
    console.error(m);
  };
if (!fs$i[gracefulQueue]) {
  var queue = commonjsGlobal[gracefulQueue] || [];
  publishQueue(fs$i, queue);
  fs$i.close = function(fs$close) {
    function close(fd, cb) {
      return fs$close.call(fs$i, fd, function(err) {
        if (!err) {
          resetQueue();
        }
        if (typeof cb === "function")
          cb.apply(this, arguments);
      });
    }
    Object.defineProperty(close, previousSymbol, {
      value: fs$close
    });
    return close;
  }(fs$i.close);
  fs$i.closeSync = function(fs$closeSync) {
    function closeSync(fd) {
      fs$closeSync.apply(fs$i, arguments);
      resetQueue();
    }
    Object.defineProperty(closeSync, previousSymbol, {
      value: fs$closeSync
    });
    return closeSync;
  }(fs$i.closeSync);
  if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || "")) {
    process.on("exit", function() {
      debug(fs$i[gracefulQueue]);
      require$$5.equal(fs$i[gracefulQueue].length, 0);
    });
  }
}
if (!commonjsGlobal[gracefulQueue]) {
  publishQueue(commonjsGlobal, fs$i[gracefulQueue]);
}
var gracefulFs = patch(clone(fs$i));
if (process.env.TEST_GRACEFUL_FS_GLOBAL_PATCH && !fs$i.__patched) {
  gracefulFs = patch(fs$i);
  fs$i.__patched = true;
}
function patch(fs2) {
  polyfills(fs2);
  fs2.gracefulify = patch;
  fs2.createReadStream = createReadStream;
  fs2.createWriteStream = createWriteStream;
  var fs$readFile = fs2.readFile;
  fs2.readFile = readFile2;
  function readFile2(path2, options, cb) {
    if (typeof options === "function")
      cb = options, options = null;
    return go$readFile(path2, options, cb);
    function go$readFile(path22, options2, cb2, startTime) {
      return fs$readFile(path22, options2, function(err) {
        if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
          enqueue([go$readFile, [path22, options2, cb2], err, startTime || Date.now(), Date.now()]);
        else {
          if (typeof cb2 === "function")
            cb2.apply(this, arguments);
        }
      });
    }
  }
  var fs$writeFile = fs2.writeFile;
  fs2.writeFile = writeFile2;
  function writeFile2(path2, data, options, cb) {
    if (typeof options === "function")
      cb = options, options = null;
    return go$writeFile(path2, data, options, cb);
    function go$writeFile(path22, data2, options2, cb2, startTime) {
      return fs$writeFile(path22, data2, options2, function(err) {
        if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
          enqueue([go$writeFile, [path22, data2, options2, cb2], err, startTime || Date.now(), Date.now()]);
        else {
          if (typeof cb2 === "function")
            cb2.apply(this, arguments);
        }
      });
    }
  }
  var fs$appendFile = fs2.appendFile;
  if (fs$appendFile)
    fs2.appendFile = appendFile;
  function appendFile(path2, data, options, cb) {
    if (typeof options === "function")
      cb = options, options = null;
    return go$appendFile(path2, data, options, cb);
    function go$appendFile(path22, data2, options2, cb2, startTime) {
      return fs$appendFile(path22, data2, options2, function(err) {
        if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
          enqueue([go$appendFile, [path22, data2, options2, cb2], err, startTime || Date.now(), Date.now()]);
        else {
          if (typeof cb2 === "function")
            cb2.apply(this, arguments);
        }
      });
    }
  }
  var fs$copyFile = fs2.copyFile;
  if (fs$copyFile)
    fs2.copyFile = copyFile2;
  function copyFile2(src, dest, flags, cb) {
    if (typeof flags === "function") {
      cb = flags;
      flags = 0;
    }
    return go$copyFile(src, dest, flags, cb);
    function go$copyFile(src2, dest2, flags2, cb2, startTime) {
      return fs$copyFile(src2, dest2, flags2, function(err) {
        if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
          enqueue([go$copyFile, [src2, dest2, flags2, cb2], err, startTime || Date.now(), Date.now()]);
        else {
          if (typeof cb2 === "function")
            cb2.apply(this, arguments);
        }
      });
    }
  }
  var fs$readdir = fs2.readdir;
  fs2.readdir = readdir;
  var noReaddirOptionVersions = /^v[0-5]\./;
  function readdir(path2, options, cb) {
    if (typeof options === "function")
      cb = options, options = null;
    var go$readdir = noReaddirOptionVersions.test(process.version) ? function go$readdir2(path22, options2, cb2, startTime) {
      return fs$readdir(path22, fs$readdirCallback(
        path22,
        options2,
        cb2,
        startTime
      ));
    } : function go$readdir2(path22, options2, cb2, startTime) {
      return fs$readdir(path22, options2, fs$readdirCallback(
        path22,
        options2,
        cb2,
        startTime
      ));
    };
    return go$readdir(path2, options, cb);
    function fs$readdirCallback(path22, options2, cb2, startTime) {
      return function(err, files) {
        if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
          enqueue([
            go$readdir,
            [path22, options2, cb2],
            err,
            startTime || Date.now(),
            Date.now()
          ]);
        else {
          if (files && files.sort)
            files.sort();
          if (typeof cb2 === "function")
            cb2.call(this, err, files);
        }
      };
    }
  }
  if (process.version.substr(0, 4) === "v0.8") {
    var legStreams = legacy(fs2);
    ReadStream = legStreams.ReadStream;
    WriteStream = legStreams.WriteStream;
  }
  var fs$ReadStream = fs2.ReadStream;
  if (fs$ReadStream) {
    ReadStream.prototype = Object.create(fs$ReadStream.prototype);
    ReadStream.prototype.open = ReadStream$open;
  }
  var fs$WriteStream = fs2.WriteStream;
  if (fs$WriteStream) {
    WriteStream.prototype = Object.create(fs$WriteStream.prototype);
    WriteStream.prototype.open = WriteStream$open;
  }
  Object.defineProperty(fs2, "ReadStream", {
    get: function() {
      return ReadStream;
    },
    set: function(val) {
      ReadStream = val;
    },
    enumerable: true,
    configurable: true
  });
  Object.defineProperty(fs2, "WriteStream", {
    get: function() {
      return WriteStream;
    },
    set: function(val) {
      WriteStream = val;
    },
    enumerable: true,
    configurable: true
  });
  var FileReadStream = ReadStream;
  Object.defineProperty(fs2, "FileReadStream", {
    get: function() {
      return FileReadStream;
    },
    set: function(val) {
      FileReadStream = val;
    },
    enumerable: true,
    configurable: true
  });
  var FileWriteStream = WriteStream;
  Object.defineProperty(fs2, "FileWriteStream", {
    get: function() {
      return FileWriteStream;
    },
    set: function(val) {
      FileWriteStream = val;
    },
    enumerable: true,
    configurable: true
  });
  function ReadStream(path2, options) {
    if (this instanceof ReadStream)
      return fs$ReadStream.apply(this, arguments), this;
    else
      return ReadStream.apply(Object.create(ReadStream.prototype), arguments);
  }
  function ReadStream$open() {
    var that = this;
    open(that.path, that.flags, that.mode, function(err, fd) {
      if (err) {
        if (that.autoClose)
          that.destroy();
        that.emit("error", err);
      } else {
        that.fd = fd;
        that.emit("open", fd);
        that.read();
      }
    });
  }
  function WriteStream(path2, options) {
    if (this instanceof WriteStream)
      return fs$WriteStream.apply(this, arguments), this;
    else
      return WriteStream.apply(Object.create(WriteStream.prototype), arguments);
  }
  function WriteStream$open() {
    var that = this;
    open(that.path, that.flags, that.mode, function(err, fd) {
      if (err) {
        that.destroy();
        that.emit("error", err);
      } else {
        that.fd = fd;
        that.emit("open", fd);
      }
    });
  }
  function createReadStream(path2, options) {
    return new fs2.ReadStream(path2, options);
  }
  function createWriteStream(path2, options) {
    return new fs2.WriteStream(path2, options);
  }
  var fs$open = fs2.open;
  fs2.open = open;
  function open(path2, flags, mode, cb) {
    if (typeof mode === "function")
      cb = mode, mode = null;
    return go$open(path2, flags, mode, cb);
    function go$open(path22, flags2, mode2, cb2, startTime) {
      return fs$open(path22, flags2, mode2, function(err, fd) {
        if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
          enqueue([go$open, [path22, flags2, mode2, cb2], err, startTime || Date.now(), Date.now()]);
        else {
          if (typeof cb2 === "function")
            cb2.apply(this, arguments);
        }
      });
    }
  }
  return fs2;
}
function enqueue(elem) {
  debug("ENQUEUE", elem[0].name, elem[1]);
  fs$i[gracefulQueue].push(elem);
  retry();
}
var retryTimer;
function resetQueue() {
  var now = Date.now();
  for (var i = 0; i < fs$i[gracefulQueue].length; ++i) {
    if (fs$i[gracefulQueue][i].length > 2) {
      fs$i[gracefulQueue][i][3] = now;
      fs$i[gracefulQueue][i][4] = now;
    }
  }
  retry();
}
function retry() {
  clearTimeout(retryTimer);
  retryTimer = void 0;
  if (fs$i[gracefulQueue].length === 0)
    return;
  var elem = fs$i[gracefulQueue].shift();
  var fn = elem[0];
  var args = elem[1];
  var err = elem[2];
  var startTime = elem[3];
  var lastTime = elem[4];
  if (startTime === void 0) {
    debug("RETRY", fn.name, args);
    fn.apply(null, args);
  } else if (Date.now() - startTime >= 6e4) {
    debug("TIMEOUT", fn.name, args);
    var cb = args.pop();
    if (typeof cb === "function")
      cb.call(null, err);
  } else {
    var sinceAttempt = Date.now() - lastTime;
    var sinceStart = Math.max(lastTime - startTime, 1);
    var desiredDelay = Math.min(sinceStart * 1.2, 100);
    if (sinceAttempt >= desiredDelay) {
      debug("RETRY", fn.name, args);
      fn.apply(null, args.concat([startTime]));
    } else {
      fs$i[gracefulQueue].push(elem);
    }
  }
  if (retryTimer === void 0) {
    retryTimer = setTimeout(retry, 0);
  }
}
(function(exports) {
  const u2 = universalify$1.fromCallback;
  const fs2 = gracefulFs;
  const api = [
    "access",
    "appendFile",
    "chmod",
    "chown",
    "close",
    "copyFile",
    "fchmod",
    "fchown",
    "fdatasync",
    "fstat",
    "fsync",
    "ftruncate",
    "futimes",
    "lchmod",
    "lchown",
    "link",
    "lstat",
    "mkdir",
    "mkdtemp",
    "open",
    "opendir",
    "readdir",
    "readFile",
    "readlink",
    "realpath",
    "rename",
    "rm",
    "rmdir",
    "stat",
    "symlink",
    "truncate",
    "unlink",
    "utimes",
    "writeFile"
  ].filter((key) => {
    return typeof fs2[key] === "function";
  });
  Object.assign(exports, fs2);
  api.forEach((method) => {
    exports[method] = u2(fs2[method]);
  });
  exports.exists = function(filename, callback) {
    if (typeof callback === "function") {
      return fs2.exists(filename, callback);
    }
    return new Promise((resolve) => {
      return fs2.exists(filename, resolve);
    });
  };
  exports.read = function(fd, buffer, offset, length, position, callback) {
    if (typeof callback === "function") {
      return fs2.read(fd, buffer, offset, length, position, callback);
    }
    return new Promise((resolve, reject) => {
      fs2.read(fd, buffer, offset, length, position, (err, bytesRead, buffer2) => {
        if (err) return reject(err);
        resolve({ bytesRead, buffer: buffer2 });
      });
    });
  };
  exports.write = function(fd, buffer, ...args) {
    if (typeof args[args.length - 1] === "function") {
      return fs2.write(fd, buffer, ...args);
    }
    return new Promise((resolve, reject) => {
      fs2.write(fd, buffer, ...args, (err, bytesWritten, buffer2) => {
        if (err) return reject(err);
        resolve({ bytesWritten, buffer: buffer2 });
      });
    });
  };
  if (typeof fs2.writev === "function") {
    exports.writev = function(fd, buffers, ...args) {
      if (typeof args[args.length - 1] === "function") {
        return fs2.writev(fd, buffers, ...args);
      }
      return new Promise((resolve, reject) => {
        fs2.writev(fd, buffers, ...args, (err, bytesWritten, buffers2) => {
          if (err) return reject(err);
          resolve({ bytesWritten, buffers: buffers2 });
        });
      });
    };
  }
  if (typeof fs2.realpath.native === "function") {
    exports.realpath.native = u2(fs2.realpath.native);
  } else {
    process.emitWarning(
      "fs.realpath.native is not a function. Is fs being monkey-patched?",
      "Warning",
      "fs-extra-WARN0003"
    );
  }
})(fs$j);
var makeDir$1 = {};
var utils$1 = {};
const path$c = path$d;
utils$1.checkPath = function checkPath(pth) {
  if (process.platform === "win32") {
    const pathHasInvalidWinCharacters = /[<>:"|?*]/.test(pth.replace(path$c.parse(pth).root, ""));
    if (pathHasInvalidWinCharacters) {
      const error = new Error(`Path contains invalid characters: ${pth}`);
      error.code = "EINVAL";
      throw error;
    }
  }
};
const fs$h = fs$j;
const { checkPath: checkPath2 } = utils$1;
const getMode = (options) => {
  const defaults2 = { mode: 511 };
  if (typeof options === "number") return options;
  return { ...defaults2, ...options }.mode;
};
makeDir$1.makeDir = async (dir, options) => {
  checkPath2(dir);
  return fs$h.mkdir(dir, {
    mode: getMode(options),
    recursive: true
  });
};
makeDir$1.makeDirSync = (dir, options) => {
  checkPath2(dir);
  return fs$h.mkdirSync(dir, {
    mode: getMode(options),
    recursive: true
  });
};
const u$a = universalify$1.fromPromise;
const { makeDir: _makeDir, makeDirSync } = makeDir$1;
const makeDir = u$a(_makeDir);
var mkdirs$2 = {
  mkdirs: makeDir,
  mkdirsSync: makeDirSync,
  // alias
  mkdirp: makeDir,
  mkdirpSync: makeDirSync,
  ensureDir: makeDir,
  ensureDirSync: makeDirSync
};
const u$9 = universalify$1.fromPromise;
const fs$g = fs$j;
function pathExists$6(path2) {
  return fs$g.access(path2).then(() => true).catch(() => false);
}
var pathExists_1 = {
  pathExists: u$9(pathExists$6),
  pathExistsSync: fs$g.existsSync
};
const fs$f = gracefulFs;
function utimesMillis$1(path2, atime, mtime, callback) {
  fs$f.open(path2, "r+", (err, fd) => {
    if (err) return callback(err);
    fs$f.futimes(fd, atime, mtime, (futimesErr) => {
      fs$f.close(fd, (closeErr) => {
        if (callback) callback(futimesErr || closeErr);
      });
    });
  });
}
function utimesMillisSync$1(path2, atime, mtime) {
  const fd = fs$f.openSync(path2, "r+");
  fs$f.futimesSync(fd, atime, mtime);
  return fs$f.closeSync(fd);
}
var utimes = {
  utimesMillis: utimesMillis$1,
  utimesMillisSync: utimesMillisSync$1
};
const fs$e = fs$j;
const path$b = path$d;
const util = require$$4;
function getStats$2(src, dest, opts) {
  const statFunc = opts.dereference ? (file2) => fs$e.stat(file2, { bigint: true }) : (file2) => fs$e.lstat(file2, { bigint: true });
  return Promise.all([
    statFunc(src),
    statFunc(dest).catch((err) => {
      if (err.code === "ENOENT") return null;
      throw err;
    })
  ]).then(([srcStat, destStat]) => ({ srcStat, destStat }));
}
function getStatsSync(src, dest, opts) {
  let destStat;
  const statFunc = opts.dereference ? (file2) => fs$e.statSync(file2, { bigint: true }) : (file2) => fs$e.lstatSync(file2, { bigint: true });
  const srcStat = statFunc(src);
  try {
    destStat = statFunc(dest);
  } catch (err) {
    if (err.code === "ENOENT") return { srcStat, destStat: null };
    throw err;
  }
  return { srcStat, destStat };
}
function checkPaths(src, dest, funcName, opts, cb) {
  util.callbackify(getStats$2)(src, dest, opts, (err, stats) => {
    if (err) return cb(err);
    const { srcStat, destStat } = stats;
    if (destStat) {
      if (areIdentical$2(srcStat, destStat)) {
        const srcBaseName = path$b.basename(src);
        const destBaseName = path$b.basename(dest);
        if (funcName === "move" && srcBaseName !== destBaseName && srcBaseName.toLowerCase() === destBaseName.toLowerCase()) {
          return cb(null, { srcStat, destStat, isChangingCase: true });
        }
        return cb(new Error("Source and destination must not be the same."));
      }
      if (srcStat.isDirectory() && !destStat.isDirectory()) {
        return cb(new Error(`Cannot overwrite non-directory '${dest}' with directory '${src}'.`));
      }
      if (!srcStat.isDirectory() && destStat.isDirectory()) {
        return cb(new Error(`Cannot overwrite directory '${dest}' with non-directory '${src}'.`));
      }
    }
    if (srcStat.isDirectory() && isSrcSubdir(src, dest)) {
      return cb(new Error(errMsg(src, dest, funcName)));
    }
    return cb(null, { srcStat, destStat });
  });
}
function checkPathsSync(src, dest, funcName, opts) {
  const { srcStat, destStat } = getStatsSync(src, dest, opts);
  if (destStat) {
    if (areIdentical$2(srcStat, destStat)) {
      const srcBaseName = path$b.basename(src);
      const destBaseName = path$b.basename(dest);
      if (funcName === "move" && srcBaseName !== destBaseName && srcBaseName.toLowerCase() === destBaseName.toLowerCase()) {
        return { srcStat, destStat, isChangingCase: true };
      }
      throw new Error("Source and destination must not be the same.");
    }
    if (srcStat.isDirectory() && !destStat.isDirectory()) {
      throw new Error(`Cannot overwrite non-directory '${dest}' with directory '${src}'.`);
    }
    if (!srcStat.isDirectory() && destStat.isDirectory()) {
      throw new Error(`Cannot overwrite directory '${dest}' with non-directory '${src}'.`);
    }
  }
  if (srcStat.isDirectory() && isSrcSubdir(src, dest)) {
    throw new Error(errMsg(src, dest, funcName));
  }
  return { srcStat, destStat };
}
function checkParentPaths(src, srcStat, dest, funcName, cb) {
  const srcParent = path$b.resolve(path$b.dirname(src));
  const destParent = path$b.resolve(path$b.dirname(dest));
  if (destParent === srcParent || destParent === path$b.parse(destParent).root) return cb();
  fs$e.stat(destParent, { bigint: true }, (err, destStat) => {
    if (err) {
      if (err.code === "ENOENT") return cb();
      return cb(err);
    }
    if (areIdentical$2(srcStat, destStat)) {
      return cb(new Error(errMsg(src, dest, funcName)));
    }
    return checkParentPaths(src, srcStat, destParent, funcName, cb);
  });
}
function checkParentPathsSync(src, srcStat, dest, funcName) {
  const srcParent = path$b.resolve(path$b.dirname(src));
  const destParent = path$b.resolve(path$b.dirname(dest));
  if (destParent === srcParent || destParent === path$b.parse(destParent).root) return;
  let destStat;
  try {
    destStat = fs$e.statSync(destParent, { bigint: true });
  } catch (err) {
    if (err.code === "ENOENT") return;
    throw err;
  }
  if (areIdentical$2(srcStat, destStat)) {
    throw new Error(errMsg(src, dest, funcName));
  }
  return checkParentPathsSync(src, srcStat, destParent, funcName);
}
function areIdentical$2(srcStat, destStat) {
  return destStat.ino && destStat.dev && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev;
}
function isSrcSubdir(src, dest) {
  const srcArr = path$b.resolve(src).split(path$b.sep).filter((i) => i);
  const destArr = path$b.resolve(dest).split(path$b.sep).filter((i) => i);
  return srcArr.reduce((acc, cur, i) => acc && destArr[i] === cur, true);
}
function errMsg(src, dest, funcName) {
  return `Cannot ${funcName} '${src}' to a subdirectory of itself, '${dest}'.`;
}
var stat$4 = {
  checkPaths,
  checkPathsSync,
  checkParentPaths,
  checkParentPathsSync,
  isSrcSubdir,
  areIdentical: areIdentical$2
};
const fs$d = gracefulFs;
const path$a = path$d;
const mkdirs$1 = mkdirs$2.mkdirs;
const pathExists$5 = pathExists_1.pathExists;
const utimesMillis = utimes.utimesMillis;
const stat$3 = stat$4;
function copy$2(src, dest, opts, cb) {
  if (typeof opts === "function" && !cb) {
    cb = opts;
    opts = {};
  } else if (typeof opts === "function") {
    opts = { filter: opts };
  }
  cb = cb || function() {
  };
  opts = opts || {};
  opts.clobber = "clobber" in opts ? !!opts.clobber : true;
  opts.overwrite = "overwrite" in opts ? !!opts.overwrite : opts.clobber;
  if (opts.preserveTimestamps && process.arch === "ia32") {
    process.emitWarning(
      "Using the preserveTimestamps option in 32-bit node is not recommended;\n\n	see https://github.com/jprichardson/node-fs-extra/issues/269",
      "Warning",
      "fs-extra-WARN0001"
    );
  }
  stat$3.checkPaths(src, dest, "copy", opts, (err, stats) => {
    if (err) return cb(err);
    const { srcStat, destStat } = stats;
    stat$3.checkParentPaths(src, srcStat, dest, "copy", (err2) => {
      if (err2) return cb(err2);
      if (opts.filter) return handleFilter(checkParentDir, destStat, src, dest, opts, cb);
      return checkParentDir(destStat, src, dest, opts, cb);
    });
  });
}
function checkParentDir(destStat, src, dest, opts, cb) {
  const destParent = path$a.dirname(dest);
  pathExists$5(destParent, (err, dirExists) => {
    if (err) return cb(err);
    if (dirExists) return getStats$1(destStat, src, dest, opts, cb);
    mkdirs$1(destParent, (err2) => {
      if (err2) return cb(err2);
      return getStats$1(destStat, src, dest, opts, cb);
    });
  });
}
function handleFilter(onInclude, destStat, src, dest, opts, cb) {
  Promise.resolve(opts.filter(src, dest)).then((include) => {
    if (include) return onInclude(destStat, src, dest, opts, cb);
    return cb();
  }, (error) => cb(error));
}
function startCopy$1(destStat, src, dest, opts, cb) {
  if (opts.filter) return handleFilter(getStats$1, destStat, src, dest, opts, cb);
  return getStats$1(destStat, src, dest, opts, cb);
}
function getStats$1(destStat, src, dest, opts, cb) {
  const stat2 = opts.dereference ? fs$d.stat : fs$d.lstat;
  stat2(src, (err, srcStat) => {
    if (err) return cb(err);
    if (srcStat.isDirectory()) return onDir$1(srcStat, destStat, src, dest, opts, cb);
    else if (srcStat.isFile() || srcStat.isCharacterDevice() || srcStat.isBlockDevice()) return onFile$1(srcStat, destStat, src, dest, opts, cb);
    else if (srcStat.isSymbolicLink()) return onLink$1(destStat, src, dest, opts, cb);
    else if (srcStat.isSocket()) return cb(new Error(`Cannot copy a socket file: ${src}`));
    else if (srcStat.isFIFO()) return cb(new Error(`Cannot copy a FIFO pipe: ${src}`));
    return cb(new Error(`Unknown file: ${src}`));
  });
}
function onFile$1(srcStat, destStat, src, dest, opts, cb) {
  if (!destStat) return copyFile$1(srcStat, src, dest, opts, cb);
  return mayCopyFile$1(srcStat, src, dest, opts, cb);
}
function mayCopyFile$1(srcStat, src, dest, opts, cb) {
  if (opts.overwrite) {
    fs$d.unlink(dest, (err) => {
      if (err) return cb(err);
      return copyFile$1(srcStat, src, dest, opts, cb);
    });
  } else if (opts.errorOnExist) {
    return cb(new Error(`'${dest}' already exists`));
  } else return cb();
}
function copyFile$1(srcStat, src, dest, opts, cb) {
  fs$d.copyFile(src, dest, (err) => {
    if (err) return cb(err);
    if (opts.preserveTimestamps) return handleTimestampsAndMode(srcStat.mode, src, dest, cb);
    return setDestMode$1(dest, srcStat.mode, cb);
  });
}
function handleTimestampsAndMode(srcMode, src, dest, cb) {
  if (fileIsNotWritable$1(srcMode)) {
    return makeFileWritable$1(dest, srcMode, (err) => {
      if (err) return cb(err);
      return setDestTimestampsAndMode(srcMode, src, dest, cb);
    });
  }
  return setDestTimestampsAndMode(srcMode, src, dest, cb);
}
function fileIsNotWritable$1(srcMode) {
  return (srcMode & 128) === 0;
}
function makeFileWritable$1(dest, srcMode, cb) {
  return setDestMode$1(dest, srcMode | 128, cb);
}
function setDestTimestampsAndMode(srcMode, src, dest, cb) {
  setDestTimestamps$1(src, dest, (err) => {
    if (err) return cb(err);
    return setDestMode$1(dest, srcMode, cb);
  });
}
function setDestMode$1(dest, srcMode, cb) {
  return fs$d.chmod(dest, srcMode, cb);
}
function setDestTimestamps$1(src, dest, cb) {
  fs$d.stat(src, (err, updatedSrcStat) => {
    if (err) return cb(err);
    return utimesMillis(dest, updatedSrcStat.atime, updatedSrcStat.mtime, cb);
  });
}
function onDir$1(srcStat, destStat, src, dest, opts, cb) {
  if (!destStat) return mkDirAndCopy$1(srcStat.mode, src, dest, opts, cb);
  return copyDir$1(src, dest, opts, cb);
}
function mkDirAndCopy$1(srcMode, src, dest, opts, cb) {
  fs$d.mkdir(dest, (err) => {
    if (err) return cb(err);
    copyDir$1(src, dest, opts, (err2) => {
      if (err2) return cb(err2);
      return setDestMode$1(dest, srcMode, cb);
    });
  });
}
function copyDir$1(src, dest, opts, cb) {
  fs$d.readdir(src, (err, items) => {
    if (err) return cb(err);
    return copyDirItems(items, src, dest, opts, cb);
  });
}
function copyDirItems(items, src, dest, opts, cb) {
  const item = items.pop();
  if (!item) return cb();
  return copyDirItem$1(items, item, src, dest, opts, cb);
}
function copyDirItem$1(items, item, src, dest, opts, cb) {
  const srcItem = path$a.join(src, item);
  const destItem = path$a.join(dest, item);
  stat$3.checkPaths(srcItem, destItem, "copy", opts, (err, stats) => {
    if (err) return cb(err);
    const { destStat } = stats;
    startCopy$1(destStat, srcItem, destItem, opts, (err2) => {
      if (err2) return cb(err2);
      return copyDirItems(items, src, dest, opts, cb);
    });
  });
}
function onLink$1(destStat, src, dest, opts, cb) {
  fs$d.readlink(src, (err, resolvedSrc) => {
    if (err) return cb(err);
    if (opts.dereference) {
      resolvedSrc = path$a.resolve(process.cwd(), resolvedSrc);
    }
    if (!destStat) {
      return fs$d.symlink(resolvedSrc, dest, cb);
    } else {
      fs$d.readlink(dest, (err2, resolvedDest) => {
        if (err2) {
          if (err2.code === "EINVAL" || err2.code === "UNKNOWN") return fs$d.symlink(resolvedSrc, dest, cb);
          return cb(err2);
        }
        if (opts.dereference) {
          resolvedDest = path$a.resolve(process.cwd(), resolvedDest);
        }
        if (stat$3.isSrcSubdir(resolvedSrc, resolvedDest)) {
          return cb(new Error(`Cannot copy '${resolvedSrc}' to a subdirectory of itself, '${resolvedDest}'.`));
        }
        if (destStat.isDirectory() && stat$3.isSrcSubdir(resolvedDest, resolvedSrc)) {
          return cb(new Error(`Cannot overwrite '${resolvedDest}' with '${resolvedSrc}'.`));
        }
        return copyLink$1(resolvedSrc, dest, cb);
      });
    }
  });
}
function copyLink$1(resolvedSrc, dest, cb) {
  fs$d.unlink(dest, (err) => {
    if (err) return cb(err);
    return fs$d.symlink(resolvedSrc, dest, cb);
  });
}
var copy_1 = copy$2;
const fs$c = gracefulFs;
const path$9 = path$d;
const mkdirsSync$1 = mkdirs$2.mkdirsSync;
const utimesMillisSync = utimes.utimesMillisSync;
const stat$2 = stat$4;
function copySync$1(src, dest, opts) {
  if (typeof opts === "function") {
    opts = { filter: opts };
  }
  opts = opts || {};
  opts.clobber = "clobber" in opts ? !!opts.clobber : true;
  opts.overwrite = "overwrite" in opts ? !!opts.overwrite : opts.clobber;
  if (opts.preserveTimestamps && process.arch === "ia32") {
    process.emitWarning(
      "Using the preserveTimestamps option in 32-bit node is not recommended;\n\n	see https://github.com/jprichardson/node-fs-extra/issues/269",
      "Warning",
      "fs-extra-WARN0002"
    );
  }
  const { srcStat, destStat } = stat$2.checkPathsSync(src, dest, "copy", opts);
  stat$2.checkParentPathsSync(src, srcStat, dest, "copy");
  return handleFilterAndCopy(destStat, src, dest, opts);
}
function handleFilterAndCopy(destStat, src, dest, opts) {
  if (opts.filter && !opts.filter(src, dest)) return;
  const destParent = path$9.dirname(dest);
  if (!fs$c.existsSync(destParent)) mkdirsSync$1(destParent);
  return getStats(destStat, src, dest, opts);
}
function startCopy(destStat, src, dest, opts) {
  if (opts.filter && !opts.filter(src, dest)) return;
  return getStats(destStat, src, dest, opts);
}
function getStats(destStat, src, dest, opts) {
  const statSync = opts.dereference ? fs$c.statSync : fs$c.lstatSync;
  const srcStat = statSync(src);
  if (srcStat.isDirectory()) return onDir(srcStat, destStat, src, dest, opts);
  else if (srcStat.isFile() || srcStat.isCharacterDevice() || srcStat.isBlockDevice()) return onFile(srcStat, destStat, src, dest, opts);
  else if (srcStat.isSymbolicLink()) return onLink(destStat, src, dest, opts);
  else if (srcStat.isSocket()) throw new Error(`Cannot copy a socket file: ${src}`);
  else if (srcStat.isFIFO()) throw new Error(`Cannot copy a FIFO pipe: ${src}`);
  throw new Error(`Unknown file: ${src}`);
}
function onFile(srcStat, destStat, src, dest, opts) {
  if (!destStat) return copyFile(srcStat, src, dest, opts);
  return mayCopyFile(srcStat, src, dest, opts);
}
function mayCopyFile(srcStat, src, dest, opts) {
  if (opts.overwrite) {
    fs$c.unlinkSync(dest);
    return copyFile(srcStat, src, dest, opts);
  } else if (opts.errorOnExist) {
    throw new Error(`'${dest}' already exists`);
  }
}
function copyFile(srcStat, src, dest, opts) {
  fs$c.copyFileSync(src, dest);
  if (opts.preserveTimestamps) handleTimestamps(srcStat.mode, src, dest);
  return setDestMode(dest, srcStat.mode);
}
function handleTimestamps(srcMode, src, dest) {
  if (fileIsNotWritable(srcMode)) makeFileWritable(dest, srcMode);
  return setDestTimestamps(src, dest);
}
function fileIsNotWritable(srcMode) {
  return (srcMode & 128) === 0;
}
function makeFileWritable(dest, srcMode) {
  return setDestMode(dest, srcMode | 128);
}
function setDestMode(dest, srcMode) {
  return fs$c.chmodSync(dest, srcMode);
}
function setDestTimestamps(src, dest) {
  const updatedSrcStat = fs$c.statSync(src);
  return utimesMillisSync(dest, updatedSrcStat.atime, updatedSrcStat.mtime);
}
function onDir(srcStat, destStat, src, dest, opts) {
  if (!destStat) return mkDirAndCopy(srcStat.mode, src, dest, opts);
  return copyDir(src, dest, opts);
}
function mkDirAndCopy(srcMode, src, dest, opts) {
  fs$c.mkdirSync(dest);
  copyDir(src, dest, opts);
  return setDestMode(dest, srcMode);
}
function copyDir(src, dest, opts) {
  fs$c.readdirSync(src).forEach((item) => copyDirItem(item, src, dest, opts));
}
function copyDirItem(item, src, dest, opts) {
  const srcItem = path$9.join(src, item);
  const destItem = path$9.join(dest, item);
  const { destStat } = stat$2.checkPathsSync(srcItem, destItem, "copy", opts);
  return startCopy(destStat, srcItem, destItem, opts);
}
function onLink(destStat, src, dest, opts) {
  let resolvedSrc = fs$c.readlinkSync(src);
  if (opts.dereference) {
    resolvedSrc = path$9.resolve(process.cwd(), resolvedSrc);
  }
  if (!destStat) {
    return fs$c.symlinkSync(resolvedSrc, dest);
  } else {
    let resolvedDest;
    try {
      resolvedDest = fs$c.readlinkSync(dest);
    } catch (err) {
      if (err.code === "EINVAL" || err.code === "UNKNOWN") return fs$c.symlinkSync(resolvedSrc, dest);
      throw err;
    }
    if (opts.dereference) {
      resolvedDest = path$9.resolve(process.cwd(), resolvedDest);
    }
    if (stat$2.isSrcSubdir(resolvedSrc, resolvedDest)) {
      throw new Error(`Cannot copy '${resolvedSrc}' to a subdirectory of itself, '${resolvedDest}'.`);
    }
    if (fs$c.statSync(dest).isDirectory() && stat$2.isSrcSubdir(resolvedDest, resolvedSrc)) {
      throw new Error(`Cannot overwrite '${resolvedDest}' with '${resolvedSrc}'.`);
    }
    return copyLink(resolvedSrc, dest);
  }
}
function copyLink(resolvedSrc, dest) {
  fs$c.unlinkSync(dest);
  return fs$c.symlinkSync(resolvedSrc, dest);
}
var copySync_1 = copySync$1;
const u$8 = universalify$1.fromCallback;
var copy$1 = {
  copy: u$8(copy_1),
  copySync: copySync_1
};
const fs$b = gracefulFs;
const path$8 = path$d;
const assert = require$$5;
const isWindows = process.platform === "win32";
function defaults(options) {
  const methods = [
    "unlink",
    "chmod",
    "stat",
    "lstat",
    "rmdir",
    "readdir"
  ];
  methods.forEach((m) => {
    options[m] = options[m] || fs$b[m];
    m = m + "Sync";
    options[m] = options[m] || fs$b[m];
  });
  options.maxBusyTries = options.maxBusyTries || 3;
}
function rimraf$1(p, options, cb) {
  let busyTries = 0;
  if (typeof options === "function") {
    cb = options;
    options = {};
  }
  assert(p, "rimraf: missing path");
  assert.strictEqual(typeof p, "string", "rimraf: path should be a string");
  assert.strictEqual(typeof cb, "function", "rimraf: callback function required");
  assert(options, "rimraf: invalid options argument provided");
  assert.strictEqual(typeof options, "object", "rimraf: options should be object");
  defaults(options);
  rimraf_(p, options, function CB(er) {
    if (er) {
      if ((er.code === "EBUSY" || er.code === "ENOTEMPTY" || er.code === "EPERM") && busyTries < options.maxBusyTries) {
        busyTries++;
        const time = busyTries * 100;
        return setTimeout(() => rimraf_(p, options, CB), time);
      }
      if (er.code === "ENOENT") er = null;
    }
    cb(er);
  });
}
function rimraf_(p, options, cb) {
  assert(p);
  assert(options);
  assert(typeof cb === "function");
  options.lstat(p, (er, st) => {
    if (er && er.code === "ENOENT") {
      return cb(null);
    }
    if (er && er.code === "EPERM" && isWindows) {
      return fixWinEPERM(p, options, er, cb);
    }
    if (st && st.isDirectory()) {
      return rmdir(p, options, er, cb);
    }
    options.unlink(p, (er2) => {
      if (er2) {
        if (er2.code === "ENOENT") {
          return cb(null);
        }
        if (er2.code === "EPERM") {
          return isWindows ? fixWinEPERM(p, options, er2, cb) : rmdir(p, options, er2, cb);
        }
        if (er2.code === "EISDIR") {
          return rmdir(p, options, er2, cb);
        }
      }
      return cb(er2);
    });
  });
}
function fixWinEPERM(p, options, er, cb) {
  assert(p);
  assert(options);
  assert(typeof cb === "function");
  options.chmod(p, 438, (er2) => {
    if (er2) {
      cb(er2.code === "ENOENT" ? null : er);
    } else {
      options.stat(p, (er3, stats) => {
        if (er3) {
          cb(er3.code === "ENOENT" ? null : er);
        } else if (stats.isDirectory()) {
          rmdir(p, options, er, cb);
        } else {
          options.unlink(p, cb);
        }
      });
    }
  });
}
function fixWinEPERMSync(p, options, er) {
  let stats;
  assert(p);
  assert(options);
  try {
    options.chmodSync(p, 438);
  } catch (er2) {
    if (er2.code === "ENOENT") {
      return;
    } else {
      throw er;
    }
  }
  try {
    stats = options.statSync(p);
  } catch (er3) {
    if (er3.code === "ENOENT") {
      return;
    } else {
      throw er;
    }
  }
  if (stats.isDirectory()) {
    rmdirSync(p, options, er);
  } else {
    options.unlinkSync(p);
  }
}
function rmdir(p, options, originalEr, cb) {
  assert(p);
  assert(options);
  assert(typeof cb === "function");
  options.rmdir(p, (er) => {
    if (er && (er.code === "ENOTEMPTY" || er.code === "EEXIST" || er.code === "EPERM")) {
      rmkids(p, options, cb);
    } else if (er && er.code === "ENOTDIR") {
      cb(originalEr);
    } else {
      cb(er);
    }
  });
}
function rmkids(p, options, cb) {
  assert(p);
  assert(options);
  assert(typeof cb === "function");
  options.readdir(p, (er, files) => {
    if (er) return cb(er);
    let n = files.length;
    let errState;
    if (n === 0) return options.rmdir(p, cb);
    files.forEach((f) => {
      rimraf$1(path$8.join(p, f), options, (er2) => {
        if (errState) {
          return;
        }
        if (er2) return cb(errState = er2);
        if (--n === 0) {
          options.rmdir(p, cb);
        }
      });
    });
  });
}
function rimrafSync(p, options) {
  let st;
  options = options || {};
  defaults(options);
  assert(p, "rimraf: missing path");
  assert.strictEqual(typeof p, "string", "rimraf: path should be a string");
  assert(options, "rimraf: missing options");
  assert.strictEqual(typeof options, "object", "rimraf: options should be object");
  try {
    st = options.lstatSync(p);
  } catch (er) {
    if (er.code === "ENOENT") {
      return;
    }
    if (er.code === "EPERM" && isWindows) {
      fixWinEPERMSync(p, options, er);
    }
  }
  try {
    if (st && st.isDirectory()) {
      rmdirSync(p, options, null);
    } else {
      options.unlinkSync(p);
    }
  } catch (er) {
    if (er.code === "ENOENT") {
      return;
    } else if (er.code === "EPERM") {
      return isWindows ? fixWinEPERMSync(p, options, er) : rmdirSync(p, options, er);
    } else if (er.code !== "EISDIR") {
      throw er;
    }
    rmdirSync(p, options, er);
  }
}
function rmdirSync(p, options, originalEr) {
  assert(p);
  assert(options);
  try {
    options.rmdirSync(p);
  } catch (er) {
    if (er.code === "ENOTDIR") {
      throw originalEr;
    } else if (er.code === "ENOTEMPTY" || er.code === "EEXIST" || er.code === "EPERM") {
      rmkidsSync(p, options);
    } else if (er.code !== "ENOENT") {
      throw er;
    }
  }
}
function rmkidsSync(p, options) {
  assert(p);
  assert(options);
  options.readdirSync(p).forEach((f) => rimrafSync(path$8.join(p, f), options));
  if (isWindows) {
    const startTime = Date.now();
    do {
      try {
        const ret = options.rmdirSync(p, options);
        return ret;
      } catch {
      }
    } while (Date.now() - startTime < 500);
  } else {
    const ret = options.rmdirSync(p, options);
    return ret;
  }
}
var rimraf_1 = rimraf$1;
rimraf$1.sync = rimrafSync;
const fs$a = gracefulFs;
const u$7 = universalify$1.fromCallback;
const rimraf = rimraf_1;
function remove$2(path2, callback) {
  if (fs$a.rm) return fs$a.rm(path2, { recursive: true, force: true }, callback);
  rimraf(path2, callback);
}
function removeSync$1(path2) {
  if (fs$a.rmSync) return fs$a.rmSync(path2, { recursive: true, force: true });
  rimraf.sync(path2);
}
var remove_1 = {
  remove: u$7(remove$2),
  removeSync: removeSync$1
};
const u$6 = universalify$1.fromPromise;
const fs$9 = fs$j;
const path$7 = path$d;
const mkdir$3 = mkdirs$2;
const remove$1 = remove_1;
const emptyDir = u$6(async function emptyDir2(dir) {
  let items;
  try {
    items = await fs$9.readdir(dir);
  } catch {
    return mkdir$3.mkdirs(dir);
  }
  return Promise.all(items.map((item) => remove$1.remove(path$7.join(dir, item))));
});
function emptyDirSync(dir) {
  let items;
  try {
    items = fs$9.readdirSync(dir);
  } catch {
    return mkdir$3.mkdirsSync(dir);
  }
  items.forEach((item) => {
    item = path$7.join(dir, item);
    remove$1.removeSync(item);
  });
}
var empty = {
  emptyDirSync,
  emptydirSync: emptyDirSync,
  emptyDir,
  emptydir: emptyDir
};
const u$5 = universalify$1.fromCallback;
const path$6 = path$d;
const fs$8 = gracefulFs;
const mkdir$2 = mkdirs$2;
function createFile$1(file2, callback) {
  function makeFile() {
    fs$8.writeFile(file2, "", (err) => {
      if (err) return callback(err);
      callback();
    });
  }
  fs$8.stat(file2, (err, stats) => {
    if (!err && stats.isFile()) return callback();
    const dir = path$6.dirname(file2);
    fs$8.stat(dir, (err2, stats2) => {
      if (err2) {
        if (err2.code === "ENOENT") {
          return mkdir$2.mkdirs(dir, (err3) => {
            if (err3) return callback(err3);
            makeFile();
          });
        }
        return callback(err2);
      }
      if (stats2.isDirectory()) makeFile();
      else {
        fs$8.readdir(dir, (err3) => {
          if (err3) return callback(err3);
        });
      }
    });
  });
}
function createFileSync$1(file2) {
  let stats;
  try {
    stats = fs$8.statSync(file2);
  } catch {
  }
  if (stats && stats.isFile()) return;
  const dir = path$6.dirname(file2);
  try {
    if (!fs$8.statSync(dir).isDirectory()) {
      fs$8.readdirSync(dir);
    }
  } catch (err) {
    if (err && err.code === "ENOENT") mkdir$2.mkdirsSync(dir);
    else throw err;
  }
  fs$8.writeFileSync(file2, "");
}
var file = {
  createFile: u$5(createFile$1),
  createFileSync: createFileSync$1
};
const u$4 = universalify$1.fromCallback;
const path$5 = path$d;
const fs$7 = gracefulFs;
const mkdir$1 = mkdirs$2;
const pathExists$4 = pathExists_1.pathExists;
const { areIdentical: areIdentical$1 } = stat$4;
function createLink$1(srcpath, dstpath, callback) {
  function makeLink(srcpath2, dstpath2) {
    fs$7.link(srcpath2, dstpath2, (err) => {
      if (err) return callback(err);
      callback(null);
    });
  }
  fs$7.lstat(dstpath, (_, dstStat) => {
    fs$7.lstat(srcpath, (err, srcStat) => {
      if (err) {
        err.message = err.message.replace("lstat", "ensureLink");
        return callback(err);
      }
      if (dstStat && areIdentical$1(srcStat, dstStat)) return callback(null);
      const dir = path$5.dirname(dstpath);
      pathExists$4(dir, (err2, dirExists) => {
        if (err2) return callback(err2);
        if (dirExists) return makeLink(srcpath, dstpath);
        mkdir$1.mkdirs(dir, (err3) => {
          if (err3) return callback(err3);
          makeLink(srcpath, dstpath);
        });
      });
    });
  });
}
function createLinkSync$1(srcpath, dstpath) {
  let dstStat;
  try {
    dstStat = fs$7.lstatSync(dstpath);
  } catch {
  }
  try {
    const srcStat = fs$7.lstatSync(srcpath);
    if (dstStat && areIdentical$1(srcStat, dstStat)) return;
  } catch (err) {
    err.message = err.message.replace("lstat", "ensureLink");
    throw err;
  }
  const dir = path$5.dirname(dstpath);
  const dirExists = fs$7.existsSync(dir);
  if (dirExists) return fs$7.linkSync(srcpath, dstpath);
  mkdir$1.mkdirsSync(dir);
  return fs$7.linkSync(srcpath, dstpath);
}
var link = {
  createLink: u$4(createLink$1),
  createLinkSync: createLinkSync$1
};
const path$4 = path$d;
const fs$6 = gracefulFs;
const pathExists$3 = pathExists_1.pathExists;
function symlinkPaths$1(srcpath, dstpath, callback) {
  if (path$4.isAbsolute(srcpath)) {
    return fs$6.lstat(srcpath, (err) => {
      if (err) {
        err.message = err.message.replace("lstat", "ensureSymlink");
        return callback(err);
      }
      return callback(null, {
        toCwd: srcpath,
        toDst: srcpath
      });
    });
  } else {
    const dstdir = path$4.dirname(dstpath);
    const relativeToDst = path$4.join(dstdir, srcpath);
    return pathExists$3(relativeToDst, (err, exists) => {
      if (err) return callback(err);
      if (exists) {
        return callback(null, {
          toCwd: relativeToDst,
          toDst: srcpath
        });
      } else {
        return fs$6.lstat(srcpath, (err2) => {
          if (err2) {
            err2.message = err2.message.replace("lstat", "ensureSymlink");
            return callback(err2);
          }
          return callback(null, {
            toCwd: srcpath,
            toDst: path$4.relative(dstdir, srcpath)
          });
        });
      }
    });
  }
}
function symlinkPathsSync$1(srcpath, dstpath) {
  let exists;
  if (path$4.isAbsolute(srcpath)) {
    exists = fs$6.existsSync(srcpath);
    if (!exists) throw new Error("absolute srcpath does not exist");
    return {
      toCwd: srcpath,
      toDst: srcpath
    };
  } else {
    const dstdir = path$4.dirname(dstpath);
    const relativeToDst = path$4.join(dstdir, srcpath);
    exists = fs$6.existsSync(relativeToDst);
    if (exists) {
      return {
        toCwd: relativeToDst,
        toDst: srcpath
      };
    } else {
      exists = fs$6.existsSync(srcpath);
      if (!exists) throw new Error("relative srcpath does not exist");
      return {
        toCwd: srcpath,
        toDst: path$4.relative(dstdir, srcpath)
      };
    }
  }
}
var symlinkPaths_1 = {
  symlinkPaths: symlinkPaths$1,
  symlinkPathsSync: symlinkPathsSync$1
};
const fs$5 = gracefulFs;
function symlinkType$1(srcpath, type, callback) {
  callback = typeof type === "function" ? type : callback;
  type = typeof type === "function" ? false : type;
  if (type) return callback(null, type);
  fs$5.lstat(srcpath, (err, stats) => {
    if (err) return callback(null, "file");
    type = stats && stats.isDirectory() ? "dir" : "file";
    callback(null, type);
  });
}
function symlinkTypeSync$1(srcpath, type) {
  let stats;
  if (type) return type;
  try {
    stats = fs$5.lstatSync(srcpath);
  } catch {
    return "file";
  }
  return stats && stats.isDirectory() ? "dir" : "file";
}
var symlinkType_1 = {
  symlinkType: symlinkType$1,
  symlinkTypeSync: symlinkTypeSync$1
};
const u$3 = universalify$1.fromCallback;
const path$3 = path$d;
const fs$4 = fs$j;
const _mkdirs = mkdirs$2;
const mkdirs = _mkdirs.mkdirs;
const mkdirsSync = _mkdirs.mkdirsSync;
const _symlinkPaths = symlinkPaths_1;
const symlinkPaths = _symlinkPaths.symlinkPaths;
const symlinkPathsSync = _symlinkPaths.symlinkPathsSync;
const _symlinkType = symlinkType_1;
const symlinkType = _symlinkType.symlinkType;
const symlinkTypeSync = _symlinkType.symlinkTypeSync;
const pathExists$2 = pathExists_1.pathExists;
const { areIdentical } = stat$4;
function createSymlink$1(srcpath, dstpath, type, callback) {
  callback = typeof type === "function" ? type : callback;
  type = typeof type === "function" ? false : type;
  fs$4.lstat(dstpath, (err, stats) => {
    if (!err && stats.isSymbolicLink()) {
      Promise.all([
        fs$4.stat(srcpath),
        fs$4.stat(dstpath)
      ]).then(([srcStat, dstStat]) => {
        if (areIdentical(srcStat, dstStat)) return callback(null);
        _createSymlink(srcpath, dstpath, type, callback);
      });
    } else _createSymlink(srcpath, dstpath, type, callback);
  });
}
function _createSymlink(srcpath, dstpath, type, callback) {
  symlinkPaths(srcpath, dstpath, (err, relative) => {
    if (err) return callback(err);
    srcpath = relative.toDst;
    symlinkType(relative.toCwd, type, (err2, type2) => {
      if (err2) return callback(err2);
      const dir = path$3.dirname(dstpath);
      pathExists$2(dir, (err3, dirExists) => {
        if (err3) return callback(err3);
        if (dirExists) return fs$4.symlink(srcpath, dstpath, type2, callback);
        mkdirs(dir, (err4) => {
          if (err4) return callback(err4);
          fs$4.symlink(srcpath, dstpath, type2, callback);
        });
      });
    });
  });
}
function createSymlinkSync$1(srcpath, dstpath, type) {
  let stats;
  try {
    stats = fs$4.lstatSync(dstpath);
  } catch {
  }
  if (stats && stats.isSymbolicLink()) {
    const srcStat = fs$4.statSync(srcpath);
    const dstStat = fs$4.statSync(dstpath);
    if (areIdentical(srcStat, dstStat)) return;
  }
  const relative = symlinkPathsSync(srcpath, dstpath);
  srcpath = relative.toDst;
  type = symlinkTypeSync(relative.toCwd, type);
  const dir = path$3.dirname(dstpath);
  const exists = fs$4.existsSync(dir);
  if (exists) return fs$4.symlinkSync(srcpath, dstpath, type);
  mkdirsSync(dir);
  return fs$4.symlinkSync(srcpath, dstpath, type);
}
var symlink = {
  createSymlink: u$3(createSymlink$1),
  createSymlinkSync: createSymlinkSync$1
};
const { createFile, createFileSync } = file;
const { createLink, createLinkSync } = link;
const { createSymlink, createSymlinkSync } = symlink;
var ensure = {
  // file
  createFile,
  createFileSync,
  ensureFile: createFile,
  ensureFileSync: createFileSync,
  // link
  createLink,
  createLinkSync,
  ensureLink: createLink,
  ensureLinkSync: createLinkSync,
  // symlink
  createSymlink,
  createSymlinkSync,
  ensureSymlink: createSymlink,
  ensureSymlinkSync: createSymlinkSync
};
function stringify$3(obj, { EOL = "\n", finalEOL = true, replacer = null, spaces } = {}) {
  const EOF = finalEOL ? EOL : "";
  const str = JSON.stringify(obj, replacer, spaces);
  return str.replace(/\n/g, EOL) + EOF;
}
function stripBom$1(content) {
  if (Buffer.isBuffer(content)) content = content.toString("utf8");
  return content.replace(/^\uFEFF/, "");
}
var utils = { stringify: stringify$3, stripBom: stripBom$1 };
let _fs;
try {
  _fs = gracefulFs;
} catch (_) {
  _fs = fs$k;
}
const universalify = universalify$1;
const { stringify: stringify$2, stripBom } = utils;
async function _readFile(file2, options = {}) {
  if (typeof options === "string") {
    options = { encoding: options };
  }
  const fs2 = options.fs || _fs;
  const shouldThrow = "throws" in options ? options.throws : true;
  let data = await universalify.fromCallback(fs2.readFile)(file2, options);
  data = stripBom(data);
  let obj;
  try {
    obj = JSON.parse(data, options ? options.reviver : null);
  } catch (err) {
    if (shouldThrow) {
      err.message = `${file2}: ${err.message}`;
      throw err;
    } else {
      return null;
    }
  }
  return obj;
}
const readFile = universalify.fromPromise(_readFile);
function readFileSync(file2, options = {}) {
  if (typeof options === "string") {
    options = { encoding: options };
  }
  const fs2 = options.fs || _fs;
  const shouldThrow = "throws" in options ? options.throws : true;
  try {
    let content = fs2.readFileSync(file2, options);
    content = stripBom(content);
    return JSON.parse(content, options.reviver);
  } catch (err) {
    if (shouldThrow) {
      err.message = `${file2}: ${err.message}`;
      throw err;
    } else {
      return null;
    }
  }
}
async function _writeFile(file2, obj, options = {}) {
  const fs2 = options.fs || _fs;
  const str = stringify$2(obj, options);
  await universalify.fromCallback(fs2.writeFile)(file2, str, options);
}
const writeFile = universalify.fromPromise(_writeFile);
function writeFileSync(file2, obj, options = {}) {
  const fs2 = options.fs || _fs;
  const str = stringify$2(obj, options);
  return fs2.writeFileSync(file2, str, options);
}
const jsonfile$1 = {
  readFile,
  readFileSync,
  writeFile,
  writeFileSync
};
var jsonfile_1 = jsonfile$1;
const jsonFile$1 = jsonfile_1;
var jsonfile = {
  // jsonfile exports
  readJson: jsonFile$1.readFile,
  readJsonSync: jsonFile$1.readFileSync,
  writeJson: jsonFile$1.writeFile,
  writeJsonSync: jsonFile$1.writeFileSync
};
const u$2 = universalify$1.fromCallback;
const fs$3 = gracefulFs;
const path$2 = path$d;
const mkdir = mkdirs$2;
const pathExists$1 = pathExists_1.pathExists;
function outputFile$1(file2, data, encoding, callback) {
  if (typeof encoding === "function") {
    callback = encoding;
    encoding = "utf8";
  }
  const dir = path$2.dirname(file2);
  pathExists$1(dir, (err, itDoes) => {
    if (err) return callback(err);
    if (itDoes) return fs$3.writeFile(file2, data, encoding, callback);
    mkdir.mkdirs(dir, (err2) => {
      if (err2) return callback(err2);
      fs$3.writeFile(file2, data, encoding, callback);
    });
  });
}
function outputFileSync$1(file2, ...args) {
  const dir = path$2.dirname(file2);
  if (fs$3.existsSync(dir)) {
    return fs$3.writeFileSync(file2, ...args);
  }
  mkdir.mkdirsSync(dir);
  fs$3.writeFileSync(file2, ...args);
}
var outputFile_1 = {
  outputFile: u$2(outputFile$1),
  outputFileSync: outputFileSync$1
};
const { stringify: stringify$1 } = utils;
const { outputFile } = outputFile_1;
async function outputJson(file2, data, options = {}) {
  const str = stringify$1(data, options);
  await outputFile(file2, str, options);
}
var outputJson_1 = outputJson;
const { stringify } = utils;
const { outputFileSync } = outputFile_1;
function outputJsonSync(file2, data, options) {
  const str = stringify(data, options);
  outputFileSync(file2, str, options);
}
var outputJsonSync_1 = outputJsonSync;
const u$1 = universalify$1.fromPromise;
const jsonFile = jsonfile;
jsonFile.outputJson = u$1(outputJson_1);
jsonFile.outputJsonSync = outputJsonSync_1;
jsonFile.outputJSON = jsonFile.outputJson;
jsonFile.outputJSONSync = jsonFile.outputJsonSync;
jsonFile.writeJSON = jsonFile.writeJson;
jsonFile.writeJSONSync = jsonFile.writeJsonSync;
jsonFile.readJSON = jsonFile.readJson;
jsonFile.readJSONSync = jsonFile.readJsonSync;
var json = jsonFile;
const fs$2 = gracefulFs;
const path$1 = path$d;
const copy = copy$1.copy;
const remove = remove_1.remove;
const mkdirp = mkdirs$2.mkdirp;
const pathExists = pathExists_1.pathExists;
const stat$1 = stat$4;
function move$1(src, dest, opts, cb) {
  if (typeof opts === "function") {
    cb = opts;
    opts = {};
  }
  opts = opts || {};
  const overwrite = opts.overwrite || opts.clobber || false;
  stat$1.checkPaths(src, dest, "move", opts, (err, stats) => {
    if (err) return cb(err);
    const { srcStat, isChangingCase = false } = stats;
    stat$1.checkParentPaths(src, srcStat, dest, "move", (err2) => {
      if (err2) return cb(err2);
      if (isParentRoot$1(dest)) return doRename$1(src, dest, overwrite, isChangingCase, cb);
      mkdirp(path$1.dirname(dest), (err3) => {
        if (err3) return cb(err3);
        return doRename$1(src, dest, overwrite, isChangingCase, cb);
      });
    });
  });
}
function isParentRoot$1(dest) {
  const parent = path$1.dirname(dest);
  const parsedPath = path$1.parse(parent);
  return parsedPath.root === parent;
}
function doRename$1(src, dest, overwrite, isChangingCase, cb) {
  if (isChangingCase) return rename$1(src, dest, overwrite, cb);
  if (overwrite) {
    return remove(dest, (err) => {
      if (err) return cb(err);
      return rename$1(src, dest, overwrite, cb);
    });
  }
  pathExists(dest, (err, destExists) => {
    if (err) return cb(err);
    if (destExists) return cb(new Error("dest already exists."));
    return rename$1(src, dest, overwrite, cb);
  });
}
function rename$1(src, dest, overwrite, cb) {
  fs$2.rename(src, dest, (err) => {
    if (!err) return cb();
    if (err.code !== "EXDEV") return cb(err);
    return moveAcrossDevice$1(src, dest, overwrite, cb);
  });
}
function moveAcrossDevice$1(src, dest, overwrite, cb) {
  const opts = {
    overwrite,
    errorOnExist: true
  };
  copy(src, dest, opts, (err) => {
    if (err) return cb(err);
    return remove(src, cb);
  });
}
var move_1 = move$1;
const fs$1 = gracefulFs;
const path = path$d;
const copySync = copy$1.copySync;
const removeSync = remove_1.removeSync;
const mkdirpSync = mkdirs$2.mkdirpSync;
const stat = stat$4;
function moveSync(src, dest, opts) {
  opts = opts || {};
  const overwrite = opts.overwrite || opts.clobber || false;
  const { srcStat, isChangingCase = false } = stat.checkPathsSync(src, dest, "move", opts);
  stat.checkParentPathsSync(src, srcStat, dest, "move");
  if (!isParentRoot(dest)) mkdirpSync(path.dirname(dest));
  return doRename(src, dest, overwrite, isChangingCase);
}
function isParentRoot(dest) {
  const parent = path.dirname(dest);
  const parsedPath = path.parse(parent);
  return parsedPath.root === parent;
}
function doRename(src, dest, overwrite, isChangingCase) {
  if (isChangingCase) return rename(src, dest, overwrite);
  if (overwrite) {
    removeSync(dest);
    return rename(src, dest, overwrite);
  }
  if (fs$1.existsSync(dest)) throw new Error("dest already exists.");
  return rename(src, dest, overwrite);
}
function rename(src, dest, overwrite) {
  try {
    fs$1.renameSync(src, dest);
  } catch (err) {
    if (err.code !== "EXDEV") throw err;
    return moveAcrossDevice(src, dest, overwrite);
  }
}
function moveAcrossDevice(src, dest, overwrite) {
  const opts = {
    overwrite,
    errorOnExist: true
  };
  copySync(src, dest, opts);
  return removeSync(src);
}
var moveSync_1 = moveSync;
const u = universalify$1.fromCallback;
var move = {
  move: u(move_1),
  moveSync: moveSync_1
};
var lib = {
  // Export promiseified graceful-fs:
  ...fs$j,
  // Export extra methods:
  ...copy$1,
  ...empty,
  ...ensure,
  ...json,
  ...mkdirs$2,
  ...move,
  ...outputFile_1,
  ...pathExists_1,
  ...remove_1
};
const fs = /* @__PURE__ */ getDefaultExportFromCjs(lib);
function getUpdater() {
  const { autoUpdater } = electronUpdater;
  return autoUpdater;
}
class AutoUpdater {
  updater;
  constructor() {
    this.updater = getUpdater();
    this.updater.forceDevUpdateConfig = true;
  }
  setup(mainWindow2) {
    this.updater.on("checking-for-update", () => {
      log.info("Checking for update...");
      mainWindow2.webContents.send("checking-for-update");
    });
    this.updater.on("update-available", (info) => {
      log.info("Update available.", info);
      mainWindow2.webContents.send("update-available", info);
    });
    this.updater.on("update-not-available", (info) => {
      log.info("Update not available.", info);
    });
    this.updater.on("error", (err) => {
      log.error("Error in auto-updater.", err);
    });
    this.updater.on("download-progress", (progressObj) => {
      let logMessage = `Download speed: ${progressObj.bytesPerSecond}`;
      logMessage += ` - Downloaded ${progressObj.percent}%`;
      logMessage += ` (${progressObj.transferred}/${progressObj.total})`;
      log.info(logMessage);
    });
    this.updater.on("update-downloaded", (info) => {
      log.log("Update downloaded", info);
      mainWindow2.webContents.send("update-downloaded", info);
    });
    electron.ipcMain.on("restart-and-update", () => {
      log.log("Restarting and updating...");
      setTimeout(() => {
        this.updater.quitAndInstall();
      }, 1e3);
    });
    electron.ipcMain.on("check-update", () => {
      log.log("Checking for update...");
      this.updater.checkForUpdatesAndNotify();
    });
  }
}
class CustomHotUpdater {
  getUserDataPath = () => electron.app.getPath("userData");
  MAIN_WINDOW_HTML_PATH = path$d.join(this.getUserDataPath(), "assets/renderer/index.html");
  PRELOAD_PATH = path$d.join(this.getUserDataPath(), "assets/preload/index.js");
  // Utility to extract a ZIP file
  extractZip = async (zipPath, extractTo) => {
    return fs.createReadStream(zipPath).pipe(unzipper.Extract({ path: extractTo })).promise();
  };
  // Function to download and extract assets ZIP
  downloadAndExtractAssets = async (downloadUrl, localFilename) => {
    const assetsPath = path$d.join(this.getUserDataPath(), "assets");
    const tempZipPath = path$d.join(this.getUserDataPath(), localFilename);
    console.log(`Downloading assets ZIP from: ${downloadUrl}`);
    await this.downloadFile(downloadUrl, tempZipPath);
    console.log(`Downloaded assets ZIP to: ${tempZipPath}`);
    await fs.ensureDir(assetsPath);
    console.log(`Extracting ZIP to: ${assetsPath}`);
    await this.extractZip(tempZipPath, assetsPath);
    await fs.remove(tempZipPath);
    console.log("Assets updated successfully");
  };
  // Utility to download and save a file
  downloadFile = async (remoteUrl, localPath) => {
    const response = await axios.get(remoteUrl, { responseType: "arraybuffer" });
    fs.removeSync(localPath);
    await fs.outputFile(localPath, response.data);
    console.log(`Downloaded and saved: ${localPath}`);
  };
  // Function to download all files
  downloadFiles = async () => {
    const DownloadFileMap = {
      "renderer.zip": `https://github.com/${RELEASE_REPO_NAME}/raw/main/renderer.zip`,
      "main.zip": `https://github.com/${RELEASE_REPO_NAME}/raw/main/main.zip`,
      "preload.zip": `https://github.com/${RELEASE_REPO_NAME}/raw/main/preload.zip`
    };
    for (const [localFilename, remoteUrl] of Object.entries(DownloadFileMap)) {
      await this.downloadAndExtractAssets(remoteUrl, localFilename);
    }
  };
  saveVersionDate = (date) => {
    let dateStr = date.toISOString();
    dateStr = dateStr.split(".")[0] + "Z";
    fs.writeFileSync(path$d.join(this.getUserDataPath(), "versionDate"), dateStr);
  };
  getVersionDate = () => {
    if (!fs.existsSync(path$d.join(this.getUserDataPath(), "versionDate"))) {
      return new Date(2e3, 1, 1);
    }
    const dateStr = fs.readFileSync(path$d.join(this.getUserDataPath(), "versionDate"), "utf-8");
    return new Date(dateStr);
  };
  checkAndUpdate = async () => {
    const res = await fetch(`https://api.github.com/repos/${RELEASE_REPO_NAME}/commits?per_page=1`);
    const lastCommitInfo = await res.json();
    const lastCommitDate = new Date(lastCommitInfo[0].commit.author.date);
    if (lastCommitDate > this.getVersionDate()) {
      await this.downloadFiles();
      this.saveVersionDate(lastCommitDate);
    }
  };
}
const customUpdater = new CustomHotUpdater();
const WINDOW_WIDTH$1 = 1380;
const WINDOW_HEIGHT$1 = 800;
const NAVBAR_HEIGHT = 56;
let mainWindow = null;
async function loadMainWindow() {
  if (!mainWindow) return;
  if (utils$2.is.dev && process.env["ELECTRON_RENDERER_URL"]) {
    await mainWindow.loadURL(process.env["ELECTRON_RENDERER_URL"]);
    return;
  }
  await customUpdater.checkAndUpdate();
  await mainWindow.loadFile(MAIN_WINDOW_HTML_PATH);
}
function getMainWindow() {
  return mainWindow;
}
function createMainWindow() {
  const _mainWindow = new electron.BrowserWindow({
    width: WINDOW_WIDTH$1,
    height: WINDOW_HEIGHT$1,
    frame: false,
    transparent: true,
    titleBarStyle: "hidden",
    trafficLightPosition: {
      x: 16,
      y: NAVBAR_HEIGHT / 2 - 8
    },
    vibrancy: "fullscreen-ui",
    backgroundMaterial: "auto",
    backgroundColor: "#00000000",
    show: false,
    autoHideMenuBar: true,
    ...process.platform === "linux" ? { icon } : {},
    webPreferences: {
      preload: PRELOAD_PATH,
      sandbox: false,
      partition: CANVAS_SESSION_PARTITION_KEY,
      nodeIntegration: true,
      webviewTag: true
      // devTools: true,
    }
  });
  _mainWindow.on("ready-to-show", () => {
    _mainWindow.show();
  });
  _mainWindow.webContents.setWindowOpenHandler((details) => {
    electron.shell.openExternal(details.url);
    return { action: "deny" };
  });
  _mainWindow.webContents.on("did-navigate", async (event, url) => {
    console.log("did-navigate", url);
  });
  mainWindow = _mainWindow;
  loadMainWindow();
  return _mainWindow;
}
const COMMON_HEADERS$1 = {
  accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  "accept-language": "en-US,en;q=0.9",
  connection: "keep-alive",
  "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0"
};
function stringifyCookies(cookies) {
  return cookies.map(
    (cookie) => `${cookie.name}=${decodeURIComponent(cookie.value)}`
  ).join("; ");
}
async function fetch_wrapper(url, options) {
  const canvasSession = await userDataStore.getCurrentCanvasUserData();
  if (!canvasSession || !canvasSession.session) {
    throw new Error("Canvas session not found");
  }
  const _url = `https://${canvasSession.hostname}${url}`;
  const { headers, ...rest } = {};
  const res = await fetch(_url, {
    headers: {
      ...COMMON_HEADERS$1,
      cookie: stringifyCookies(canvasSession.session.cookies),
      host: canvasSession.hostname,
      ...headers ?? {}
    },
    ...rest ?? {}
  });
  console.log(`🚀 [${res.status}] ${_url}`);
  return res;
}
function extract_home_env_info_from_html(html) {
  const doc = new jsdom.JSDOM(html).window.document;
  let script = doc.querySelectorAll("script")[1];
  let t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  if (!t) {
    script = doc.querySelectorAll("script")[2];
    t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  }
  if (!t) {
    console.log("No ENV found in Canvas home page", script);
    return null;
  }
  try {
    const data = JSON.parse(t + "}");
    return {
      user: {
        id: data["current_user"]["id"],
        display_name: data["current_user"]["display_name"],
        avatar_image_url: data["current_user"]["avatar_image_url"],
        html_url: data["current_user"]["html_url"],
        pronouns: data["current_user"]["pronouns"],
        email: data["current_user"]["email"]
      },
      preferences: {
        custom_colors: data["PREFERENCES"]["custom_colors"]
      },
      courses: data["STUDENT_PLANNER_COURSES"].map((c) => ({ ...c, tabs: [] }))
    };
  } catch (e) {
    console.error("failed to parse Canvas Home env", e);
    console.log("env_str", t);
    return null;
  }
}
async function get_home_info() {
  const res = await fetch_wrapper("/");
  if (res.status === 401) {
    return null;
  }
  const html = await res.text();
  return extract_home_env_info_from_html(html);
}
const pagination_wrapper = async (make_fetch, page_size) => {
  let cur_page = 1;
  let res = await make_fetch(page_size, cur_page);
  const data = await res.json();
  let cur = data;
  let output = [...cur];
  while (cur.length === page_size) {
    cur_page += 1;
    res = await make_fetch(page_size, cur_page);
    cur = await res.json();
    output = [...output, ...cur];
  }
  return output;
};
async function fetch_course_announcements(courseId, page_size = 10) {
  const res = await pagination_wrapper(
    (page_size2, page) => fetch_wrapper(
      `/api/v1/courses/${courseId}/discussion_topics?only_announcements=true&per_page=${page_size2}&page=${page}&filter_by=all&no_avatar_fallback=1&include[]=sections_user_count&include[]=sections`
    ),
    page_size
  );
  return res.map((a) => ({
    ...a,
    id: `${a.id}`,
    // @ts-ignore
    author: !!a.author ? a.author : null,
    course_id: courseId
  }));
}
async function fetch_course_syllabus(courseId) {
  const res = await fetch_wrapper(`/courses/${courseId}/assignments/syllabus`);
  const html = await res.text();
  const win = new jsdom.JSDOM(html);
  return win.window.document.querySelector("#content")?.innerHTML ?? "";
}
const search_universities_by_domain = async (domain) => {
  const universities = await fetch(
    "https://sso.canvaslms.com/api/v1/accounts/search?domain=" + domain
  ).then((res) => res.json());
  return universities;
};
const search_universities_by_name = async (name) => {
  const universities = await fetch(
    "https://sso.canvaslms.com/api/v1/accounts/search?name=" + name
  ).then((res) => res.json());
  return universities;
};
function getAssignmentDueDate(assignment) {
  return !!assignment.due_at ? new Date(assignment.due_at) : null;
}
function groupAssignmentsByDueDate(assignmentList) {
  const dateMap = /* @__PURE__ */ new Map();
  dateMap.set("invalid", {
    items: []
  });
  const dateArray = [];
  assignmentList.forEach((assignment) => {
    const dueDate = getAssignmentDueDate(assignment);
    if (!dueDate) {
      dateMap.get("invalid").items.push(assignment);
    } else {
      const date = getDateString(dueDate);
      if (!dateMap.has(date)) {
        dateMap.set(date, {
          items: [],
          nextDate: void 0,
          prevDate: void 0
        });
        dateArray.push(date);
      }
      dateMap.get(date).items.push(assignment);
    }
  });
  dateArray.sort();
  dateArray.forEach((date, index) => {
    if (index < dateArray.length - 1) {
      dateMap.get(date).nextDate = dateArray[index + 1];
    }
    if (index > 0) {
      dateMap.get(date).prevDate = dateArray[index - 1];
    }
  });
  return { dateMap, dateArray };
}
function calculateAssignmentDoneState(assignment) {
  if (!assignment.submissions || assignment.submissions.length === 0 || assignment.submissions[0].workflow_state === "unsubmitted" || assignment.submissions[0].missing || !assignment.submissions[0].submitted_at) {
    return false;
  }
  return true;
}
const appStatePath = path$d.join(electron.app.getPath("userData"), "appState.json");
function ensureAppStateFile() {
  if (!fs$k.existsSync(appStatePath)) {
    const initialState = {};
    fs$k.writeFileSync(appStatePath, JSON.stringify(initialState, null, 2));
  }
}
function getAppState() {
  ensureAppStateFile();
  const rawData = fs$k.readFileSync(appStatePath, "utf-8");
  return JSON.parse(rawData);
}
function setAppState(newState) {
  ensureAppStateFile();
  const oldAppState = getAppState();
  fs$k.writeFileSync(
    appStatePath,
    JSON.stringify({ ...oldAppState, ...newState }, null, 2)
  );
}
ensureAppStateFile();
const DB_PATH = path$d.join(electron.app.getPath("userData"), "database.db");
if (utils$2.is.dev && fs$k.existsSync(DB_PATH)) {
  fs$k.unlinkSync(DB_PATH);
  setAppState({
    lastFetchedAllCoursesTimestamp: void 0
  });
  console.log("Development mode: Database reset.");
}
const db = new Database(DB_PATH, {
  // verbose: console.log,
});
function initializeDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS user (
      id TEXT PRIMARY KEY,
      display_name TEXT,
      avatar_image_url TEXT,
      html_url TEXT,
      pronouns TEXT,
      email TEXT
    );

    CREATE TABLE IF NOT EXISTS course (
      id TEXT PRIMARY KEY,
      courseCode TEXT,
      dataInit BOOLEAN DEFAULT 0,
      pinned BOOLEAN,
      data TEXT
    );

    CREATE TABLE IF NOT EXISTS assignment_groups (
      id INTEGER PRIMARY KEY,
      courseId TEXT,
      name TEXT,
      data TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS assignments (
      id INTEGER PRIMARY KEY,
      courseId TEXT,
      assignmentGroupId INTEGER,
      name TEXT,
      dueAt TEXT,
      done BOOLEAN,
      done_local_overwrite BOOLEAN,
      data TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id),
      FOREIGN KEY (assignmentGroupId) REFERENCES assignment_groups (id)
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id TEXT PRIMARY KEY,
      courseId TEXT,
      data TEXT,
      postedAt TEXT,
      readState TEXT,
      title TEXT,
      message TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY,
      assignmentId INTEGER,
      data TEXT,

      FOREIGN KEY (assignmentId) REFERENCES assignments (id)
    );

    CREATE TABLE IF NOT EXISTS course_root_folders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      courseId TEXT UNIQUE,
      folderId INTEGER,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS folders (
      id INTEGER PRIMARY KEY,
      parentFolderId INTEGER,
      data TEXT
    );

    CREATE TABLE IF NOT EXISTS files (
      id INTEGER PRIMARY KEY,
      folderId INTEGER,
      url TEXT,
      displayName TEXT,
      createdAt TEXT,
      updatedAt TEXT,
      data TEXT,

      FOREIGN KEY (folderId) REFERENCES folders (id)
    );

    CREATE TABLE IF NOT EXISTS pages (
      id TEXT PRIMARY KEY,
      title TEXT,
      courseId TEXT,
      data TEXT,
      createdAt TEXT,
      updatedAt TEXT,

      FOREIGN KEY (courseId) REFERENCES course (id)
    );

    CREATE TABLE IF NOT EXISTS planner_items (
      id TEXT PRIMARY KEY,
      courseId TEXT,
      title TEXT,
      date TEXT,
      done BOOLEAN DEFAULT 0,
      ignored BOOLEAN DEFAULT 0,
      data TEXT
    );
  `);
}
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
initializeDb();
function upsertCourseAssignments(courseId, assignmentGroups) {
  const upsertAssignmentGroupStmt = db.prepare(`
    INSERT INTO assignment_groups (id, courseId, name, data)
    VALUES (@id, @courseId, @name, @data)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      data = excluded.data;
  `);
  const upsertAssignmentStmt = db.prepare(`
    INSERT INTO assignments (id, courseId, assignmentGroupId, data, dueAt, name)
    VALUES (@id, @courseId, @assignmentGroupId, @data, @dueAt, @name)
    ON CONFLICT(id) DO UPDATE SET
      assignmentGroupId = excluded.assignmentGroupId,
      dueAt = excluded.dueAt,
      name = excluded.name,
      data = excluded.data;
  `);
  const transaction = db.transaction((assignmentGroups2) => {
    for (const group of assignmentGroups2) {
      upsertAssignmentGroupStmt.run({
        id: group.id,
        courseId,
        name: group.name,
        data: JSON.stringify(group)
      });
      for (const assignment of group.assignments) {
        upsertAssignmentStmt.run({
          id: assignment.id,
          courseId,
          assignmentGroupId: group.id,
          dueAt: assignment.due_at,
          name: assignment.name,
          data: JSON.stringify(assignment)
        });
      }
    }
  });
  transaction(assignmentGroups);
}
function getAssignmentGroupRowsByCourseId(courseId) {
  const stmt = db.prepare(`
    SELECT id, courseId, name, data FROM assignment_groups WHERE courseId = ?
  `);
  return stmt.all(courseId).map((row) => {
    return {
      ...JSON.parse(row.data),
      id: row.id,
      assignments: [],
      course_id: row.courseId,
      name: row.name
    };
  });
}
function getCourseAssignmentGroups(courseId) {
  const assignmentGroupRows = getAssignmentGroupRowsByCourseId(courseId);
  const output = assignmentGroupRows.map((g) => {
    const aData = getAssignments({
      assignmentGroupId: g.id,
      limit: 100,
      page: 1
    });
    return {
      ...g,
      assignments: aData
    };
  });
  return output;
}
function mergeAssignmentSubmissionRows(assignmentSubmissionRows) {
  const aIdToSId = /* @__PURE__ */ new Map();
  const sMap = /* @__PURE__ */ new Map();
  const aMap = /* @__PURE__ */ new Map();
  for (const row of assignmentSubmissionRows) {
    const aId = `${row.assignmentId}`;
    const sId = !!row.submissionId ? `${row.submissionId}` : null;
    if (!aIdToSId.has(aId)) {
      aIdToSId.set(aId, !sId ? [] : [sId]);
    } else if (!!sId) {
      aIdToSId.get(aId).push(sId);
    }
    if (!!sId) {
      sMap.set(sId, JSON.parse(row.submissionData));
    }
    aMap.set(aId, {
      ...JSON.parse(row.assignmentData),
      done: row.done,
      done_local_overwrite: row.done_local_overwrite
    });
  }
  const assignments = [];
  for (const [aId, sIds] of aIdToSId) {
    const assignment = aMap.get(aId);
    assignments.push({
      ...assignment,
      submissions: sIds.map((sId) => sMap.get(sId))
    });
  }
  return assignments;
}
function getAssignments(options) {
  if (!options.page || !options.limit) {
    options.page = 1;
    options.limit = 100;
  }
  if (!options.order) {
    options.order = "desc";
  }
  if (!options.courseIds) {
    options.courseIds = [];
  }
  let where = "";
  if (options.courseIds.length > 0 || !!options.assignmentGroupId || !!options.searchTerm || typeof options.done === "boolean" || !!options.dueAtStart || !!options.dueAtEnd || !!options.favoriteOnly) {
    where += "where ";
    let whereItems = [];
    if (options.courseIds.length > 0) {
      whereItems.push(`courseId in (${options.courseIds.map((id) => `'${id}'`).join(",")})`);
    }
    if (!!options.assignmentGroupId) {
      whereItems.push(`assignmentGroupId = '${options.assignmentGroupId}'`);
    }
    if (!!options.searchTerm) {
      whereItems.push(`assignments.name like '%${options.searchTerm}%'`);
    }
    if (typeof options.done === "boolean") {
      whereItems.push(`done = ${options.done ? 1 : 0}`);
    }
    if (!!options.dueAtStart) {
      whereItems.push(`dueAt >= '${options.dueAtStart}'`);
    }
    if (!!options.dueAtEnd) {
      whereItems.push(`dueAt <= '${options.dueAtEnd}'`);
    }
    if (!!options.favoriteOnly) {
      whereItems.push(`course.favorite = 1`);
    }
    where += whereItems.join(" and ");
  }
  const assignmentsStmt = db.prepare(`
    SELECT 
      assignments.id as assignmentId, courseId, assignments.data as assignmentData, dueAt, done, done_local_overwrite,
      submissions.id as submissionId, submissions.data as submissionData
    FROM assignments
    left join submissions on assignments.id = submissions.assignmentId
    inner join course on assignments.courseId = course.id
    ${where}
    ORDER BY ${options.orderBy || "dueAt"} ${options.order.toUpperCase()}
    LIMIT ? OFFSET ?
  `);
  const assignmentSubmissionRows = assignmentsStmt.all([
    options.limit,
    (options.page - 1) * options.limit
  ]);
  const assignments = mergeAssignmentSubmissionRows(
    assignmentSubmissionRows
  );
  assignments.sort((a, b) => {
    const aDate = new Date(a.due_at ?? "");
    const bDate = new Date(b.due_at ?? "");
    if (options.order === "asc") {
      return aDate.getTime() - bDate.getTime();
    } else {
      return bDate.getTime() - aDate.getTime();
    }
  });
  return assignments;
}
function getAssignmentById(id) {
  const stmt = db.prepare(`
    SELECT 
      assignments.id as assignmentId, courseId, assignments.data as assignmentData, dueAt, done, done_local_overwrite,
      submissions.id as submissionId, submissions.data as submissionData
    FROM assignments
    left join submissions on assignments.id = submissions.assignmentId
    WHERE assignments.id = ?
  `);
  const rows = stmt.all(id);
  if (rows.length > 0) {
    return mergeAssignmentSubmissionRows(rows)[0];
  }
  return null;
}
function updateAssignmentById(id, params) {
  const oldAssignment = getAssignmentById(id);
  if (!params.data) {
    params.data = JSON.stringify(oldAssignment);
  }
  if (!params.done) {
    params.done = calculateAssignmentDoneState(oldAssignment);
  }
  if (!params.done_local_overwrite) {
    params.done_local_overwrite = !!oldAssignment.done_local_overwrite;
  }
  const stmt = db.prepare(`
    UPDATE assignments
    SET data = ?, done = ?, done_local_overwrite = ?
    WHERE id = ?
  `);
  stmt.run(
    params.data,
    params.done ? 1 : 0,
    params.done_local_overwrite ? 1 : 0,
    id
  );
}
function syncAssignmentsWithSubmissions(assignmentIds) {
  assignmentIds.forEach((id) => {
    const oldAssignment = getAssignmentById(id);
    if (!oldAssignment) {
      return;
    }
    const doneFromServer = calculateAssignmentDoneState(oldAssignment);
    const overwrite = !!oldAssignment.done === doneFromServer ? false : !!oldAssignment.done_local_overwrite;
    updateAssignmentById(id, {
      data: JSON.stringify(oldAssignment),
      // respect user's overwrite state
      done: overwrite ? oldAssignment.done : doneFromServer,
      // if the server state is the same from the local state, set done_local_overwrite
      // to false, otherwise leave it unchanged
      done_local_overwrite: overwrite
    });
  });
}
function getCourseAssignmentsSummary(courseId) {
  const allAssignments = getAssignments({
    courseIds: [courseId],
    limit: 1e3
  });
  const { dateMap } = groupAssignmentsByDueDate(allAssignments);
  const dateMapShort = /* @__PURE__ */ new Map();
  dateMap.forEach((value, key) => {
    dateMapShort.set(key, {
      count: value.items.length,
      doneCount: value.items.filter((a) => a.done).length
    });
  });
  return {
    dateMap: dateMapShort
  };
}
function upsertAnnouncements(announcements) {
  const upsertAnnouncementStmt = db.prepare(`
    INSERT INTO announcements (id, courseId, data, postedAt, readState, title, message)
    VALUES (@id, @courseId, @data, @postedAt, @readState, @title, @message)
    ON CONFLICT(id) DO UPDATE SET
      courseId = excluded.courseId,
      data = excluded.data,
      postedAt = excluded.postedAt,
      readState = excluded.readState,
      title = excluded.title,
      message = excluded.message;
  `);
  const transaction = db.transaction((announcements2) => {
    for (const announcement of announcements2) {
      upsertAnnouncementStmt.run({
        id: announcement.id,
        courseId: announcement.course_id,
        data: JSON.stringify(announcement),
        postedAt: announcement.posted_at,
        readState: announcement.read_state,
        title: announcement.title,
        message: announcement.message
      });
    }
  });
  transaction(announcements);
}
function getAnnouncements(options) {
  let whereItems = [];
  if (!!options.courseId || !!options.courseIds || !!options.unreadOnly) {
    if (!!options.courseId) {
      whereItems.push(`courseId = '${options.courseId}'`);
    } else if (!!options.courseIds) {
      whereItems.push(
        `courseId IN (${options.courseIds.map((courseId) => `'${courseId}'`).join(", ")})`
      );
    }
    if (!!options.unreadOnly) {
      whereItems.push(`readState = 'unread'`);
    }
  }
  const where = whereItems.length > 0 ? `WHERE ${whereItems.join(" AND ")}` : "";
  const getAllAnnouncementsStmt = db.prepare(`
    SELECT id, courseId, data, postedAt, readState, title, message
    FROM announcements
    ${where}
    ORDER BY ${options.orderBy || "postedAt"} DESC
    LIMIT ? OFFSET ?
  `);
  const rows = getAllAnnouncementsStmt.all([
    options.limit,
    (options.page - 1) * options.limit
  ]);
  return rows.map((row) => {
    return {
      id: row.id,
      course_id: row.courseId,
      posted_at: row.postedAt,
      read_state: row.readState,
      title: row.title,
      message: row.message,
      ...JSON.parse(row.data)
    };
  });
}
function getAnnouncementById(id) {
  const getAnnouncementByIdStmt = db.prepare(`
    SELECT *
    FROM announcements
    WHERE id = ?
  `);
  const row = getAnnouncementByIdStmt.get(id);
  if (row) {
    return {
      id: row.id,
      course_id: row.courseId,
      posted_at: row.postedAt,
      read_state: row.readState,
      title: row.title,
      message: row.message,
      ...JSON.parse(row.data)
    };
  }
  return null;
}
function updateAnnouncementById(id, newData) {
  const data = getAnnouncementById(id);
  if (!data) {
    return;
  }
  const updateStmt = db.prepare(`
    UPDATE announcements
    SET data = @data
    WHERE id = @id
  `);
  updateStmt.run({
    id,
    data: JSON.stringify({
      ...data,
      ...newData
    })
  });
}
function getLatestAnnouncementDate() {
  const getLatestAnnouncementDateStmt = db.prepare(`
    SELECT MAX(postedAt) as latestDate
    FROM announcements
  `);
  return getLatestAnnouncementDateStmt.get().latestDate;
}
function build_include_fields(fields) {
  return fields.map((f) => `include[]=${f}`).join("&");
}
function stringify_cookies(cookies) {
  return cookies.map(
    (cookie) => `${cookie.name}=${decodeURIComponent(cookie.value)}`
  ).join("; ");
}
function build_search_queries(options) {
  return Object.entries(options).map(([key, value]) => {
    if (Array.isArray(value)) {
      return value.map((v) => `${key}=${v}`).join("&");
    } else {
      return `${key}=${value}`;
    }
  }).join("&");
}
function parseCookiesFromResponse(response) {
  const rawSetCookieHeaders = response.headers.get("set-cookie")?.split(", ");
  if (!rawSetCookieHeaders || rawSetCookieHeaders.length === 0) {
    return [];
  }
  const domain = new URL(response.url).hostname;
  const cookies = rawSetCookieHeaders.map((setCookieStr) => {
    return parseSetCookieString(setCookieStr, domain);
  });
  return cookies.filter(Boolean);
}
function parseSetCookieString(setCookieStr, domain) {
  const parts = setCookieStr.split("; ").map((p) => p.trim());
  const [nameValue, ...attributes] = parts;
  if (!nameValue) {
    return null;
  }
  const [cookieName, cookieValue] = nameValue.split("=");
  if (!cookieName || cookieValue === void 0) {
    return null;
  }
  const cookie = {
    name: cookieName,
    value: cookieValue,
    domain,
    path: "/",
    secure: false,
    httpOnly: false,
    sameSite: "lax"
    // You can include other Electron.Cookie attributes as needed
    // e.g. expirationDate
  };
  attributes.forEach((attr) => {
    const [key, val] = attr.split("=");
    const lowerKey = key.toLowerCase().trim();
    switch (lowerKey) {
      case "domain":
        cookie.domain = val;
        break;
      case "path":
        cookie.path = val;
        break;
      case "secure":
        cookie.secure = true;
        break;
      case "httponly":
        cookie.httpOnly = true;
        break;
    }
  });
  return cookie;
}
function mergeCookieLists(listA, listB) {
  const cookieMap = /* @__PURE__ */ new Map();
  function createCookieKey(cookie) {
    const domain = cookie.domain || "";
    const path2 = cookie.path || "";
    const name = cookie.name || "";
    return `${domain}::${path2}::${name}`;
  }
  for (const cookie of listA) {
    cookieMap.set(createCookieKey(cookie), cookie);
  }
  for (const cookie of listB) {
    cookieMap.set(createCookieKey(cookie), cookie);
  }
  return Array.from(cookieMap.values());
}
function extractEnvFromCoursePageHTML(html) {
  const doc = new jsdom.JSDOM(html).window.document;
  let script = doc.querySelectorAll("script")[1];
  let t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  if (!t) {
    script = doc.querySelectorAll("script")[2];
    t = script.innerHTML.split("ENV = ")[1]?.split("};")[0];
  }
  if (!t) {
    return null;
  }
  try {
    const data = JSON.parse(t + "}");
    return data;
  } catch (e) {
    console.error("failed to parse ENV from course page HTML:", e);
    return null;
  }
}
function SetDiscussionReadGraphQLMutationParams(discussionId, read = true) {
  return {
    operationName: "UpdateDiscussionReadState",
    variables: {
      discussionTopicId: `${discussionId}`,
      read
    },
    query: `mutation UpdateDiscussionReadState($discussionTopicId: ID!, $read: Boolean!) {
      updateDiscussionReadState(input: {discussionTopicId: $discussionTopicId, read: $read}) {
        discussionTopic {
          id
          title
          message
          createdAt
          updatedAt
          __typename
        }
        __typename
      }
    }`
  };
}
const CourseIncludeFields = [
  "tabs",
  // favorite is not accurate; use get dashboard courses instead
  "favorites",
  "banner_image",
  "syllabus_body",
  "total_students",
  "term",
  "course_image",
  "teachers",
  "concluded"
];
const COMMON_HEADERS = {
  accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  "accept-language": "en-US,en;q=0.9",
  connection: "keep-alive",
  "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0"
};
function createCanvasClient() {
  const canvasUserData = userDataStore.getCurrentCanvasUserData();
  const session = canvasUserData?.session;
  if (!session) {
    throw new Error("No canvas user data found");
  }
  return new CanvasClient(
    canvasUserData.hostname,
    session,
    canvasUserData.access_token
  );
}
class CanvasClient {
  hostname;
  cookies;
  cookieString;
  csrfToken;
  accessToken;
  constructor(hostname, canvasSession, accessToken) {
    this.hostname = hostname;
    this.cookies = canvasSession.cookies;
    this.csrfToken = canvasSession.csrfToken;
    this.cookieString = stringify_cookies(canvasSession.cookies);
    this.accessToken = accessToken ?? "";
  }
  async fetch_wrapper(url, options, {
    rawUrl = false
  } = {}) {
    const _url = rawUrl ? url : `https://${this.hostname}${url}`;
    const { headers, ...rest } = options ?? {};
    const start = performance.now();
    const _headers = {
      ...COMMON_HEADERS,
      authorization: `Bearer ${this.accessToken}`,
      cookie: this.cookieString,
      host: this.hostname,
      ...headers
    };
    const res = await fetch(_url, {
      headers: _headers,
      ...rest ?? {}
    });
    const end = performance.now();
    const newCookies = parseCookiesFromResponse(res);
    if (newCookies.length > 0) {
      newCookies.map((c) => c.name).join(", ");
      this.cookies = mergeCookieLists(this.cookies, newCookies);
      userDataStore.updateCurrentUserCanvasCookies(this.cookies);
      this.cookieString = stringify_cookies(this.cookies);
    }
    console.log(`🚀 [${res.status}] (+${(end - start).toFixed(2)}ms) ${_url}`);
    return res;
  }
  async fetch_json(url, options) {
    const { headers = {}, ...rest } = options ?? {};
    const res = await this.fetch_wrapper(url, {
      headers: {
        accept: "application/json+canvas-string-ids, application/json",
        "x-csrf-token": this.csrfToken,
        "x-requested-with": "XMLHttpRequest",
        ...headers
      },
      ...rest
    });
    if (res.status >= 400) {
      console.error(
        `Failed to fetch ${url} (${res.status})`
      );
      throw new Error(`Failed to fetch ${url}`);
    }
    const json2 = await res.json();
    return json2;
  }
  async graphql(params) {
    const res = await this.fetch_json("/api/graphql", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(params)
    });
    const data = res;
    return data;
  }
  async fetch_dashboard_courses() {
    const includeFields = build_include_fields(CourseIncludeFields);
    const res = await this.fetch_json(
      `/api/v1/users/self/favorites/courses?${includeFields}`
    );
    return res.map((c) => ({
      id: `${c.id}`,
      root_folder_id: null,
      // is_favorite: true,
      // tabs: [],
      ...c
    }));
  }
  /**
   * Using https://canvas.instructure.com/doc/api/courses.html#method.courses.index
   * @returns
   */
  async fetch_courses(options = {}) {
    if (!options["include[]"]) {
      options["include[]"] = CourseIncludeFields;
    }
    if (!options["state[]"]) {
      options["state[]"] = ["available", "completed", "deleted"];
    }
    const queries = build_search_queries(options);
    const res = await this.fetch_json(
      `/api/v1/courses?${queries}&per_page=150`
    );
    return res.map((c) => ({
      id: `${c.id}`,
      root_folder_id: null,
      // tabs: [],
      ...c
    }));
  }
  async set_course_favorite(courseId, favorite) {
    const res = await this.fetch_wrapper(
      `/api/v1/users/self/favorites/courses/${courseId}`,
      {
        method: favorite ? "POST" : "DELETE",
        headers: {
          "content-length": "0"
        }
      }
    );
    if (!res.ok) {
      console.error(
        `Failed to set favorite to ${favorite} for course ${courseId}`
      );
      throw new Error(`Failed to set favorite for course ${courseId}`);
    }
  }
  async fetch_course_home_page(courseId) {
    const res = await this.fetch_wrapper(`/courses/${courseId}`);
    const html = await res.text();
    const data = extractEnvFromCoursePageHTML(html);
    return {
      wiki_page: data?.["WIKI_PAGE"] ?? null
    };
  }
  async fetch_course_tabs(courseId) {
    const res = await this.fetch_json(`/api/v1/courses/${courseId}/tabs`);
    return res;
  }
  /**
   * Using https://canvas.instructure.com/doc/api/planner.html#method.planner.index
   * @returns
   */
  async fetch_planner_items({
    per_page = 100,
    page = 1,
    start_date,
    order = "asc"
  }) {
    const res = await this.fetch_json(
      `/api/v1/planner/items?per_page=${per_page}&page=${page}&start_date=${start_date}&order=${order}`
    );
    return res;
  }
  async fetch_course_quizzes(courseId) {
    const res = await this.fetch_json(`/api/v1/courses/${courseId}/quizzes`);
    return res;
  }
  async fetch_course_assignments(courseId, { per_page = 100 } = {}) {
    const AssignmentsOptions = {
      "exclude_assignment_submission_types[]": ["wiki_page"],
      "exclude_response_fields[]": ["description", "rubric"],
      "include[]": ["assignments", "discussion_topic", "assessment_requests"],
      "per_page": per_page
    };
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/assignment_groups?` + build_search_queries(
        AssignmentsOptions
      )
    );
    return res;
  }
  async fetch_course_submissions(courseId, { limit = 100 } = {}) {
    const options = {
      "include[]": ["submission_comments"],
      "per_page": limit
    };
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/students/submissions?` + build_search_queries(options)
    );
    console.log(`Fetched ${res.length} submissions for course ${courseId}`);
    return res;
  }
  async fetch_course_files(courseId, { limit = 100 } = {}) {
    const COURSE_FILE_INCLUDE_FIELDS = ["enhanced_preview_url"];
    const includeFields = build_include_fields(COURSE_FILE_INCLUDE_FIELDS);
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/files?per_page=${limit}&${includeFields}`
    );
    return res.map((f) => ({ ...f, course_id: courseId }));
  }
  async fetch_course_folders(courseId, { limit = 100 } = {}) {
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/folders?per_page=${limit}`
    );
    return res;
  }
  async fetch_course_root_folder(courseId) {
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/folders/root`
    );
    return res;
  }
  async fetch_announcements(courseIds, {
    limit = 200,
    start_date = toISODatetimeString(new Date(2024, 0, 1)),
    end_date = toISODatetimeString(/* @__PURE__ */ new Date())
  } = {}) {
    const queryObj = {
      start_date,
      end_date,
      per_page: limit.toString(),
      "context_codes[]": courseIds.map((c) => `course_${c}`)
    };
    const queries = build_search_queries(queryObj);
    const res = await this.fetch_json(`/api/v1/announcements?${queries}`);
    const byCourse = res.reduce((acc, a) => {
      if (!acc[a["context_code"]]) {
        acc[a["context_code"]] = [];
      }
      acc[a["context_code"]].push(a);
      return acc;
    }, {});
    Object.entries(byCourse).forEach(([contextCode, announcements]) => {
      const courseId = contextCode.split("_")[1];
      console.log(
        `Course ${courseId} has ${announcements.length} announcements`
      );
    });
    console.log("Total announcements:", res.length);
    return res.map((a) => ({
      ...a,
      course_id: a["context_code"].split("_")[1]
    }));
  }
  async fetch_course_pages(courseId) {
    const Fields = {
      sort: "title",
      per_page: 100,
      order: "asc"
    };
    const res = await this.fetch_json(
      `/api/v1/courses/${courseId}/pages?` + build_search_queries(Fields)
    );
    return res;
  }
  async set_color(name, color) {
    const userId = userDataStore.getCurrentCanvasUserId();
    if (!userId) {
      throw new Error("No canvas user data found");
    }
    const formData = new URLSearchParams();
    formData.set("hexcode", color);
    await this.fetch_json(
      `/api/v1/users/${userId}/colors/${name}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: formData
      }
    );
  }
  async set_course_color(courseId, color) {
    await this.set_color(`course_${courseId}`, color);
  }
  // async fetch_assignment_description(assignmentId: number): Promise<string> {
  async fetch_assignment_description(href) {
    const res = await this.fetch_wrapper(href, {}, {
      rawUrl: true
    });
    const html = await res.text();
    const doc = new jsdom.JSDOM(html);
    const content = doc.window.document.querySelector("div.user_content");
    return content?.innerHTML ?? "";
  }
  /**
   * ****************************************
   * GraphQL-Based APIs
   */
  async mark_discussion_as_read(discussionId) {
    await this.graphql(
      SetDiscussionReadGraphQLMutationParams(discussionId)
    );
  }
  async download_file(url, filePath) {
    fs$k.mkdirSync(path$d.dirname(filePath), { recursive: true });
    const response = await this.fetch_wrapper(url, {}, { rawUrl: true });
    if (!response.ok) {
      throw new Error(
        `Failed to download file: ${response.status} ${response.statusText}`
      );
    }
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    fs$k.writeFileSync(filePath, new Uint8Array(buffer));
    return filePath;
  }
}
function upsertCourses(courses) {
  const upsertCourseStmt = db.prepare(`
    INSERT INTO course (id, courseCode, pinned, data)
    VALUES (@id, @courseCode, @pinned, @data)
    ON CONFLICT(id) DO UPDATE SET
      courseCode = excluded.courseCode,
      pinned = excluded.pinned,
      dataInit = 1;
  `);
  const allCourseIdSet = getAllCourseIdSet();
  const transaction = db.transaction((courses2) => {
    for (const course of courses2) {
      upsertCourseStmt.run({
        id: course.id,
        courseCode: course.course_code,
        pinned: course.is_favorite ? 1 : 0,
        data: JSON.stringify(course)
      });
      if (allCourseIdSet.has(course.id)) {
        updateCourse(course.id, course);
      }
    }
  });
  transaction(courses);
}
function updateCourse(courseId, data) {
  const existing = db.prepare(
    `
    SELECT id, data FROM course WHERE id = ?
  `
  ).get(courseId);
  const newData = { ...JSON.parse(existing.data), ...data };
  const updateCourseStmt = db.prepare(
    `
    UPDATE course
    SET data = @data, pinned = @is_favorite
    WHERE id = @id
  `
  );
  updateCourseStmt.run({
    id: courseId,
    data: JSON.stringify(newData),
    is_favorite: newData.is_favorite ? 1 : 0
  });
}
function getPinnedCourses() {
  const getPinnedCoursesStmt = db.prepare(`
    SELECT id, courseCode, pinned, data
    FROM course
    WHERE pinned = 1
  `);
  const rows = getPinnedCoursesStmt.all();
  return rows.map((row) => {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      pinned: !!row.pinned,
      ...parsedData
    };
  });
}
function getAllCourses() {
  const getAllCoursesStmt = db.prepare(`
    SELECT id, courseCode, pinned, data, dataInit
    FROM course
  `);
  const rows = getAllCoursesStmt.all();
  return rows.map((row) => {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      pinned: !!row.pinned,
      ...parsedData,
      dataInit: !!row.dataInit
    };
  });
}
function getCourseById(courseId) {
  const stmt = db.prepare(`
    SELECT id, courseCode, pinned, data
    FROM course
    WHERE id = ?
  `);
  const row = stmt.get(courseId);
  if (row) {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      ...parsedData
    };
  }
  return null;
}
function getAllCourseIdSet() {
  const getAllCourseIdsStmt = db.prepare(`
    SELECT id
    FROM course
  `);
  return new Set(getAllCourseIdsStmt.all().map((row) => row.id));
}
function setFavoriteCourses(courseIds) {
  const allCourseIds = getAllCourseIdSet();
  const favoriteCourseIds = new Set(courseIds);
  const favoriteCourses = new Set(
    Array.from(allCourseIds).filter((id) => favoriteCourseIds.has(id))
  );
  const stmt = db.prepare(`
    UPDATE course
    SET pinned = CASE WHEN id IN (${Array.from(favoriteCourses).join(
    ","
  )}) THEN 1 ELSE 0 END
  `);
  stmt.run();
  allCourseIds.forEach((cid) => {
    updateCourse(cid, {
      is_favorite: favoriteCourses.has(cid)
    });
  });
}
function getCourses({ searchTerm }) {
  const stmt = db.prepare(`
    SELECT id, courseCode, pinned, data
    FROM course
    WHERE courseCode LIKE '%${searchTerm}%'
  `);
  return stmt.all().map((row) => {
    const parsedData = JSON.parse(row.data);
    return {
      id: row.id,
      pinned: !!row.pinned,
      ...parsedData
    };
  });
}
function upsertSubmissions(submissions) {
  const upsertSubmissionStmt = db.prepare(`
    INSERT INTO submissions (id, data, assignmentId)
    VALUES (@id, @data, @assignmentId)
    ON CONFLICT(id) DO UPDATE SET
      data = excluded.data;
  `);
  const transaction = db.transaction((submissions2) => {
    for (const submission of submissions2) {
      upsertSubmissionStmt.run({
        id: submission.id,
        assignmentId: submission.assignment_id,
        data: JSON.stringify(submission)
      });
    }
  });
  transaction(submissions);
}
function upsertFolders(folders) {
  const upsertFolderStmt = db.prepare(`
    INSERT INTO folders (id, parentFolderId, data)
    VALUES (@id, @parentFolderId, @data)
    ON CONFLICT(id) DO UPDATE SET
      parentFolderId = excluded.parentFolderId,
      data = excluded.data;
  `);
  const transaction = db.transaction((folders2) => {
    for (const folder of folders2) {
      upsertFolderStmt.run({
        id: folder.id,
        parentFolderId: folder.parent_folder_id ?? null,
        data: JSON.stringify(folder)
      });
    }
  });
  transaction(folders);
}
function upsertFiles(files) {
  const upsertFileStmt = db.prepare(`
    INSERT INTO files (id, folderId, url, displayName, createdAt, updatedAt, data)
    VALUES (@id, @folderId, @url, @displayName, @createdAt, @updatedAt, @data)
    ON CONFLICT(id) DO UPDATE SET
      folderId = excluded.folderId,
      url = excluded.url,
      displayName = excluded.displayName,
      createdAt = excluded.createdAt,
      updatedAt = excluded.updatedAt,
      data = excluded.data;
  `);
  const transaction = db.transaction((files2) => {
    for (const file2 of files2) {
      upsertFileStmt.run({
        id: file2.id,
        folderId: file2.folder_id,
        url: file2.url,
        displayName: file2.display_name,
        createdAt: file2.created_at,
        updatedAt: file2.updated_at,
        data: JSON.stringify(file2)
      });
    }
  });
  transaction(files);
}
function getItemsByFolderId(folderId) {
  const getFoldersStmt = db.prepare(`
    SELECT id, parentFolderId, data
    FROM folders
    WHERE parentFolderId = ?
  `);
  const getFilesStmt = db.prepare(`
    SELECT id, folderId, url, displayName, createdAt, updatedAt, data
    FROM files
    WHERE folderId = ?
  `);
  const folders = getFoldersStmt.all(folderId).map((row) => ({
    ...JSON.parse(row.data),
    id: row.id,
    parentFolderId: row.parent_folder_id
  }));
  const files = getFilesStmt.all(folderId).map((row) => ({
    ...JSON.parse(row.data),
    id: row.id,
    folderId: row.folder_id,
    url: row.url,
    displayName: row.display_name,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt
  }));
  return {
    files,
    folders
  };
}
function upsertCourseRootFolderId(courseId, folderId) {
  const possibleRootFolderId = getCourseRootFolderId(courseId);
  if (possibleRootFolderId) {
    db.prepare(`
      UPDATE course_root_folders
      SET folderId = ?
      WHERE courseId = ?
    `).run([folderId, courseId]);
  } else {
    db.prepare(`
      INSERT INTO course_root_folders (courseId, folderId)
      VALUES (?, ?)
    `).run([courseId, folderId]);
  }
}
function getCourseRootFolderId(courseId) {
  const stmt = db.prepare(`
    SELECT folderId
    FROM course_root_folders
    WHERE courseId = ?
  `);
  const row = stmt.get(courseId);
  return row?.folderId ?? null;
}
function getRecursiveParentFolders(folderId) {
  const stmt = db.prepare(`
    SELECT id, parentFolderId, data
    FROM folders
    WHERE id = ?
  `);
  const row = stmt.get(folderId);
  if (!row) return [];
  return [
    ...getRecursiveParentFolders(row.parentFolderId),
    {
      id: row.id,
      parent_folder_id: row.parentFolderId,
      ...JSON.parse(row.data)
    }
  ];
}
function getFiles({ folderId, searchTerm }) {
  let where = "";
  if (!!folderId || !!searchTerm) {
    where += "where ";
    let whereItems = [];
    if (!!folderId) {
      whereItems.push(`folderId = ${folderId}`);
    }
    if (!!searchTerm) {
      whereItems.push(`displayName LIKE '%${searchTerm}%'`);
    }
    where += whereItems.join(" AND ");
  }
  const stmt = db.prepare(`
    SELECT id, folderId, url, displayName, createdAt, updatedAt, data
    FROM files
    ${where}
  `);
  return stmt.all().map((row) => ({
    ...JSON.parse(row.data)
  }));
}
function getFileById(id) {
  const stmt = db.prepare(`
    SELECT id, folderId, url, displayName, createdAt, updatedAt, data
    FROM files
    WHERE id = ?
  `);
  const row = stmt.get(id);
  if (!row) return null;
  return {
    ...JSON.parse(row.data)
  };
}
const CUSTOM_MENU_LABELS = ["Courses", "Window"];
function makeMenu() {
  const defaultMenu = electron.Menu.getApplicationMenu() ?? { items: [] };
  const courses = getPinnedCourses();
  const menuTemplate = [
    ...defaultMenu.items.map((item) => item).filter(
      (item) => !CUSTOM_MENU_LABELS.includes(item.label)
    ),
    // {
    //   label: "Window",
    //   submenu: [
    //     {
    //       label: "New Window",
    //       click: () => {
    //         // window.electron.ipcRenderer.send("openCourse", course.id);
    //       },
    //     },
    //   ],
    // },
    {
      label: "Courses",
      submenu: courses.map((course) => ({
        label: course.course_code,
        submenu: course.tabs.map((t) => ({
          label: t.label,
          click: () => {
            electron.shell.openExternal(t.full_url);
          }
        }))
      }))
    }
  ];
  return menuTemplate;
}
function updateMenu() {
  const menuTemplate = makeMenu();
  const menu = electron.Menu.buildFromTemplate(menuTemplate);
  electron.Menu.setApplicationMenu(menu);
}
function upsertPages(pages, courseId) {
  const stmt = db.prepare(
    `
    INSERT OR REPLACE INTO pages (id, courseId, data, title, updatedAt, createdAt)
    VALUES (@id, @courseId, @data, @title, @updatedAt, @createdAt)
    ON CONFLICT(id) DO UPDATE SET
      data = excluded.data,
      title = excluded.title,
      updatedAt = excluded.updatedAt,
      createdAt = excluded.createdAt;
  `
  );
  const transaction = db.transaction((pages2) => {
    for (const page of pages2) {
      stmt.run({
        id: `${page.url}:${courseId}`,
        courseId,
        data: JSON.stringify(page),
        title: page.title,
        updatedAt: page.updated_at,
        createdAt: page.created_at
      });
    }
  });
  transaction(pages);
}
function upsertPlannerItems(items) {
  const insertStmt = db.prepare(`
    INSERT INTO planner_items (id, courseId, title, date, data)
    VALUES (@id, @courseId, @title, @date, @data)
    ON CONFLICT(id) DO UPDATE SET
      title = excluded.title,
      date = excluded.date,
      data = excluded.data;
    `);
  const transaction = db.transaction((items2) => {
    for (const item of items2) {
      insertStmt.run({
        id: item.plannable_id,
        courseId: item.course_id,
        title: item.plannable.title,
        date: item.plannable_date,
        data: JSON.stringify(item)
      });
    }
  });
  transaction(items);
}
function getPlannerItems(options = {}) {
  if (!options.page || !options.limit) {
    options.page = 1;
    options.limit = 100;
  }
  if (!options.order) {
    options.order = "asc";
  }
  let where = "";
  if (!!options.courseId) {
    where += "where courseId = ?";
  }
  const plannerItemsStmt = db.prepare(`
    SELECT id, courseId, title, date, data, done, ignored
    FROM planner_items
    ${where}
    ORDER BY date ${options.order.toUpperCase()}
    LIMIT ? OFFSET ?
  `);
  const plannerItemsRows = plannerItemsStmt.all([
    options.courseId,
    options.limit,
    (options.page - 1) * options.limit
  ]);
  return plannerItemsRows.map((row) => ({
    id: row.id,
    courseId: row.courseId,
    title: row.title,
    date: row.date,
    data: JSON.parse(row.data)
  }));
}
function getPlannerItemById(id) {
  const stmt = db.prepare(`
    SELECT id, courseId, title, date, data, done, ignored
    FROM planner_items
    WHERE id = ?
  `);
  const row = stmt.get(id);
  if (!row) return null;
  return {
    id: row.id,
    courseId: row.courseId,
    title: row.title,
    date: row.date,
    done: row.done,
    ignored: row.ignored,
    data: JSON.parse(row.data)
  };
}
function updatePlannerItemById(id, data) {
  const oldData = getPlannerItemById(id);
  if (!oldData) {
    return;
  }
  if (!data.data) {
    data.data = oldData.data;
  }
  if (!data.done) {
    data.done = oldData.done;
  }
  if (!data.ignored) {
    data.ignored = oldData.ignored;
  }
  const stmt = db.prepare(`
    UPDATE planner_items
    SET data = @data, done = @done, ignored = @ignored
    WHERE id = @id
  `);
  stmt.run({ ...data, id });
}
const courseDataFetchers = {
  // announcements: async (client, courseId) => {
  //   const announcements = await client.fetch_announcements([courseId]);
  //   upsertAnnouncements(announcements);
  // },
  // "files" tab might imply fetching root folder, folder listings, and file listings.
  files: async (client, courseId) => {
    const [rootFolder, files, folders] = await Promise.all([
      client.fetch_course_root_folder(courseId),
      client.fetch_course_files(courseId),
      client.fetch_course_folders(courseId)
    ]);
    upsertCourseRootFolderId(courseId, rootFolder.id);
    upsertFolders(folders);
    upsertFiles(files);
  },
  pages: async (client, courseId) => {
    const pages = await client.fetch_course_pages(courseId);
    upsertPages(pages, courseId);
  }
  // syllabus: async (client, courseId) => {
  //   const syllabus = await fetch_course_syllabus(courseId);
  //   updateCourse(courseId, { syllabus_body: syllabus });
  // },
};
const NonTabCourseDataFetchers = [
  async (client, courseId) => {
    const env = await client.fetch_course_home_page(courseId);
    updateCourse(courseId, { ...env });
  },
  async (client, courseId) => {
    const [assignmentGroups, submissions] = await Promise.all([
      client.fetch_course_assignments(courseId),
      client.fetch_course_submissions(courseId)
    ]);
    upsertCourseAssignments(courseId, assignmentGroups);
    upsertSubmissions(submissions);
    syncAssignmentsWithSubmissions(
      assignmentGroups.flatMap((g) => g.assignments.map((a) => a.id))
    );
  }
];
const TabsWithDataFetchers = new Set(Object.keys(courseDataFetchers));
async function fetch_global_course_data(client, courseIds) {
  const [announcements, plannerItems] = await Promise.all([
    client.fetch_announcements(courseIds),
    client.fetch_planner_items({ start_date: "2024-01-01" })
  ]);
  upsertAnnouncements(announcements);
  upsertPlannerItems(plannerItems);
}
async function fetch_global_course_data_quick(client, courseIds) {
  const latestAnnouncementDate = getLatestAnnouncementDate();
  const [announcements, plannerItems] = await Promise.all([
    client.fetch_announcements(courseIds, {
      start_date: latestAnnouncementDate
    }),
    client.fetch_planner_items({ start_date: "2024-01-01" })
  ]);
  upsertAnnouncements(announcements);
  upsertPlannerItems(plannerItems);
}
async function fetch_single_course_data(client, course) {
  await Promise.all(
    [
      ...course.tabs.map((t) => t.label.toLowerCase()).filter(
        (t) => TabsWithDataFetchers.has(t)
      ).map((t) => courseDataFetchers[t](client, course.id)),
      ...NonTabCourseDataFetchers.map((f) => f(client, course.id))
    ]
  );
}
async function fetch_single_course_data_quick(client, course) {
  await Promise.all(
    [
      // ...course.tabs.map((t) => t.label.toLowerCase()).filter((t) =>
      //   TabsWithDataFetchers.has(t)
      // ).map((t) => courseDataFetchers[t](client, course.id)),
      // ...NonTabCourseDataFetchers.map((f) => f(client, course.id)),
    ]
  );
}
const APIHandlers = {
  "fetch-main-courses": async () => {
    const client = createCanvasClient();
    let courses = await client.fetch_dashboard_courses();
    upsertCourses(courses);
    setFavoriteCourses(courses.map((c) => c.id));
    updateMenu();
    return courses.filter((c) => c.is_favorite);
  },
  "fetch-main-course-data": async () => {
    const mainCourses = getPinnedCourses();
    const client = createCanvasClient();
    await Promise.all([
      fetch_global_course_data(client, mainCourses.map((c) => c.id)),
      ...mainCourses.map((c) => fetch_single_course_data(client, c))
    ]);
  },
  "quick-refresh": async () => {
    const mainCourses = getPinnedCourses();
    const client = createCanvasClient();
    await Promise.all([
      fetch_global_course_data_quick(client, mainCourses.map((c) => c.id)),
      ...mainCourses.map((c) => fetch_single_course_data_quick())
    ]);
  },
  "fetch-course-data": async (courseId) => {
    const course = getCourseById(courseId);
    if (!course) {
      console.error(`Course ${courseId} not found`);
      return;
    }
    const client = createCanvasClient();
    fetch_single_course_data(client, course);
  },
  "fetch-course-data-latest": async (courseId) => {
    const client = createCanvasClient();
    const [
      assignmentGroups,
      submissions,
      announcements,
      files,
      folders
    ] = await Promise.all([
      client.fetch_course_assignments(courseId),
      client.fetch_course_submissions(courseId),
      client.fetch_announcements([courseId]),
      client.fetch_course_files(courseId),
      client.fetch_course_folders(courseId)
    ]);
    upsertCourseAssignments(courseId, assignmentGroups);
    upsertSubmissions(submissions);
    upsertAnnouncements(announcements);
    upsertFolders(folders);
    upsertFiles(files);
  },
  "fetch-home-info": async () => {
    try {
      const response = await get_home_info();
      if (!!response) {
        userDataStore.setCurrentCanvasUserData({
          user: response.user,
          canvas_preferences: response.preferences
        });
      }
      return response;
    } catch (e) {
      console.error("Failed to fetch home info:", getErrorMessage(e));
      return null;
    }
  },
  "fetch-all-student-courses": async () => {
    const client = createCanvasClient();
    const [aCourses, cCourses, fCourses] = await Promise.all([
      client.fetch_courses({
        enrollment_type: "student",
        enrollment_state: "active"
      }),
      client.fetch_courses({
        enrollment_type: "student",
        enrollment_state: "completed"
      }),
      client.fetch_dashboard_courses()
    ]);
    const fCourseIdSet = new Set(fCourses.map((c) => c.id));
    const courses = [...aCourses, ...cCourses].map(
      (c) => ({
        ...c,
        is_favorite: fCourseIdSet.has(c.id)
      })
    );
    upsertCourses(courses);
    setAppState({
      lastFetchedAllCoursesTimestamp: Date.now()
    });
    return courses;
  },
  "fetch-course-assignments": async (courseId) => {
    const client = createCanvasClient();
    const [assignments, submissions] = await Promise.all([
      client.fetch_course_assignments(courseId),
      client.fetch_course_submissions(courseId)
    ]);
    upsertCourseAssignments(courseId, assignments);
    upsertSubmissions(submissions);
    return getCourseAssignmentGroups(courseId);
  },
  "fetch-course-announcements": async (courseId) => {
    const response = await fetch_course_announcements(courseId);
    upsertAnnouncements(response);
    return response;
  },
  "fetch-course-syllabus": async (courseId) => {
    const response = await fetch_course_syllabus(courseId);
    return response;
  },
  "fetch-assignment-detail": async (assignmentId) => {
    const client = createCanvasClient();
    const aData = await getAssignmentById(assignmentId);
    if (!aData) return null;
    const description = await client.fetch_assignment_description(
      // assignmentId,
      // aData.id,
      aData.html_url
    );
    return { ...aData, description };
  },
  "fetch-course-files": async (courseId) => {
    const client = createCanvasClient();
    const rootFolderIdFromDb = getCourseRootFolderId(courseId);
    const [files, folders, rootFolderId] = await Promise.all([
      client.fetch_course_files(courseId),
      client.fetch_course_folders(courseId),
      new Promise((resolve) => {
        if (rootFolderIdFromDb) {
          resolve(rootFolderIdFromDb);
        } else {
          client.fetch_course_root_folder(courseId).then((rootFolder) => {
            upsertCourseRootFolderId(courseId, rootFolder.id);
            resolve(rootFolder.id);
          });
        }
      })
    ]);
    upsertFolders(folders);
    upsertFiles(files);
    return {
      files,
      folders,
      rootFolderId
    };
  },
  "fetch-course-pages": async (courseId) => {
    const client = createCanvasClient();
    const pages = await client.fetch_course_pages(courseId);
    upsertPages(pages, courseId);
    return pages;
  },
  "set-course-color": async (courseId, color) => {
    const client = createCanvasClient();
    await client.set_course_color(courseId, color);
  },
  "download-file": async (fileId) => {
    const client = createCanvasClient();
    const f = getFileById(fileId);
    if (!f) {
      console.error(`File ${fileId} not found`);
      return null;
    }
    const filepath = await client.download_file(f.url, "./" + f.display_name);
    electron.shell.openPath(filepath);
    return filepath;
  },
  "set-course-favorite": async (courseId, isFavorite) => {
    const client = createCanvasClient();
    await client.set_course_favorite(courseId, isFavorite);
  },
  "search-universities-by-name": async (name) => {
    const universities = await search_universities_by_name(name);
    return universities;
  },
  "search-universities-by-domain": async (domain) => {
    const universities = await search_universities_by_domain(domain);
    return universities;
  },
  logout: async () => {
    userDataStore.canvasLogoutCurrentUser();
  },
  "mark-discussion-as-read": async (discussionId) => {
    const client = createCanvasClient();
    try {
      await client.mark_discussion_as_read(
        discussionId
      );
      updateAnnouncementById(discussionId, {
        read_state: "read"
      });
    } catch (e) {
      console.error(
        "Failed to set discussion read status:",
        getErrorMessage(e)
      );
    }
  }
};
const POSTHOG_ID_FILENAME = path$d.join(
  electron.app.getPath("userData"),
  "posthog.json"
);
const posthog = new posthogNode.PostHog(
  "phc_HL4vvIv8ExFUd77UgNtpqZL3ZDYECUW6WHNh5uMEkyo",
  { host: "https://us.i.posthog.com" }
);
function writeNewUUID() {
  const uuid = crypto.randomUUID();
  fs$k.writeFileSync(
    POSTHOG_ID_FILENAME,
    JSON.stringify({
      uuid
    })
  );
  return uuid;
}
function getUUID() {
  const fileData = JSON.parse(
    fs$k.readFileSync(POSTHOG_ID_FILENAME, "utf-8")
  );
  return fileData.uuid;
}
function initializePosthog() {
  let uuid;
  if (!fs$k.existsSync(POSTHOG_ID_FILENAME)) {
    uuid = writeNewUUID();
  } else {
    const fileData = JSON.parse(
      fs$k.readFileSync(POSTHOG_ID_FILENAME, "utf-8")
    );
    uuid = fileData.uuid;
    if (typeof uuid !== "string") {
      uuid = writeNewUUID();
    }
  }
  posthog.identify({
    distinctId: uuid
  });
}
function sendStartUpEvent({
  startup_time: startup_time2
}) {
  posthog.capture({
    distinctId: getUUID(),
    event: "Start Up",
    properties: {
      app_version: electron.app.getVersion(),
      platform: process.platform,
      arch: process.arch,
      is_packaged: electron.app.isPackaged,
      node_version: process.versions.node,
      electron_version: process.versions.electron,
      startup_time: startup_time2
    }
  });
}
function sendCanvasLoginSuccessEvent() {
  posthog.capture({
    distinctId: getUUID(),
    event: "Canvas Login Success"
  });
}
const WINDOW_WIDTH = 900;
const WINDOW_HEIGHT = 600;
async function handleCanvasLogin(window2) {
  const ses = electron.session.fromPartition(CANVAS_SESSION_PARTITION_KEY);
  const cookies = await ses.cookies.get({});
  const canvasUserData = extractCanvasUserDataFromCookies(cookies);
  const html = await window2.webContents.executeJavaScript(
    `document.documentElement.innerHTML`
  );
  const info = extract_home_env_info_from_html(html);
  if (!info) {
    throw new Error("Failed to parse home info");
  }
  userDataStore.canvasLogin(
    info.user.id,
    canvasUserData.hostname,
    canvasUserData.session
  );
  userDataStore.setCurrentCanvasUserData({
    user: info.user,
    canvas_preferences: info.preferences
  });
}
function openCanvasLoginWindow(hostname) {
  const _mainWindow = new electron.BrowserWindow({
    width: WINDOW_WIDTH,
    height: WINDOW_HEIGHT,
    title: "Canvas Login",
    backgroundMaterial: "auto",
    backgroundColor: "#00000000",
    show: false,
    ...process.platform === "linux" ? { icon } : {},
    webPreferences: {
      preload: path$d.join(__dirname, "../preload/index.js"),
      sandbox: false,
      partition: CANVAS_SESSION_PARTITION_KEY,
      nodeIntegration: true,
      webviewTag: true
      // devTools: true,
    }
  });
  _mainWindow.on("ready-to-show", () => {
    _mainWindow.show();
  });
  _mainWindow.on("close", () => {
    loadMainWindow();
  });
  _mainWindow.webContents.setWindowOpenHandler((details) => {
    electron.shell.openExternal(details.url);
    return { action: "deny" };
  });
  _mainWindow.webContents.on("did-navigate", async (event, url) => {
    console.log("did-navigate", url);
    const domain = getDomainFromUrl(url);
    const currentCanvasHost = userDataStore.getCurrentCanvasHost();
    if (domain === currentCanvasHost) {
      console.log("Login success");
      sendCanvasLoginSuccessEvent();
      await handleCanvasLogin(_mainWindow);
      _mainWindow.close();
      loadMainWindow();
    }
  });
  _mainWindow.loadURL(`https://${hostname}`);
  return _mainWindow;
}
const NavHandlers = {
  "to-canvas-login": async (hostname) => {
    userDataStore.setCurrentCanvasHost(hostname);
    openCanvasLoginWindow(hostname);
  },
  "open-external": async (url) => {
    electron.shell.openExternal(url);
  },
  "close-window": async () => {
    getMainWindow()?.close();
  },
  "maximize-window": async () => {
    const mainWindow2 = getMainWindow();
    if (!mainWindow2) return;
    if (mainWindow2.isMaximized()) {
      mainWindow2.unmaximize();
    } else {
      mainWindow2.maximize();
    }
  },
  "minimize-window": async () => {
    const mainWindow2 = getMainWindow();
    if (!mainWindow2) return;
    mainWindow2.minimize();
  },
  "show-notification": async (params) => {
    const n = new electron.Notification(params);
    if (!!params.url) {
      n.on("click", () => {
        console.log("Click notification " + params.title);
      });
    }
    n.show();
  }
};
function searchAllItems(searchTerm) {
  const assignments = getAssignments({ searchTerm });
  const files = getFiles({ searchTerm });
  const courses = getCourses({ searchTerm });
  return {
    assignments,
    files,
    courses
  };
}
const StoreHandlers = {
  /**
   * *******************************
   * User Data Queries
   * *******************************
   */
  "get-current-user-data": async () => {
    return userDataStore.getCurrentUserData();
  },
  "get-canvas-current-user-data": async () => {
    return userDataStore.getCurrentCanvasUserData();
  },
  "get-current-canvas-host": async () => {
    return userDataStore.getCurrentCanvasHost();
  },
  "get-app-state": async () => {
    return getAppState();
  },
  /**
   * *******************************
   * Course Queries
   * *******************************
   */
  "get-all-courses": async () => {
    const response = await getAllCourses();
    return response;
  },
  "get-main-courses": async () => {
    const response = await getPinnedCourses();
    return response;
  },
  "get-course-by-id": async (courseId) => {
    const response = await getCourseById(courseId);
    return response;
  },
  "update-course-by-id": async (courseId, params) => {
    await updateCourse(courseId, params);
  },
  /**
   * *******************************
   * Assignment Queries
   * *******************************
   */
  "get-course-assignments": async (courseId) => {
    return getCourseAssignmentGroups(courseId);
  },
  "get-assignments": async (options) => {
    return getAssignments(options);
  },
  "get-course-assignments-summary": async (courseId) => {
    return getCourseAssignmentsSummary(courseId);
  },
  "get-assignment-by-id": async (id) => {
    return getAssignmentById(id);
  },
  "update-assignment-by-id": async (id, data) => {
    return updateAssignmentById(id, data);
  },
  /**
   * *******************************
   * Announcement Queries
   * *******************************
   */
  "get-announcements": async (options) => {
    return getAnnouncements(options);
  },
  "get-announcement-by-id": async (id) => {
    return getAnnouncementById(id);
  },
  /**
   * *******************************
   * Planner Queries
   * *******************************
   */
  "get-planner-items": async (options) => {
    return getPlannerItems(options);
  },
  "update-planner-item": async (id, data) => {
    return updatePlannerItemById(id, data);
  },
  /**
   * *******************************
   * File & Folder Queries
   * *******************************
   */
  "get-course-root-folder-id": async (courseId) => {
    return getCourseRootFolderId(courseId);
  },
  "get-items-by-folder-id": async (folderId) => {
    const { files, folders } = getItemsByFolderId(folderId);
    const parentFolders = getRecursiveParentFolders(folderId);
    return {
      files,
      folders,
      parentFolders
    };
  },
  /**
   * *******************************
   * Search Queries
   * *******************************
   */
  "search-items": async (query) => {
    return searchAllItems(query);
  },
  /**
   * *******************************
   * Settings
   * *******************************
   */
  "save-settings": async (settings) => {
    console.log("Saving settings...");
    userDataStore.saveCurrentUserSettings(settings);
  },
  "save-canvas-data": async (data) => {
    console.log("Saving canvas user data...");
    userDataStore.setCurrentCanvasUserData(data);
  }
};
const setupHandlers = (handleMap) => {
  Object.entries(handleMap).forEach(([key, handler]) => {
    electron.ipcMain.handle(key, (_key, ...args) => {
      return handler(...args);
    });
  });
};
function setupAllIpcRoutes() {
  setupHandlers(APIHandlers);
  setupHandlers(StoreHandlers);
  setupHandlers(NavHandlers);
}
const startup_time = performance.now();
const updater = new AutoUpdater();
electron.app.setName("My Canvas");
electron.app.whenReady().then(() => {
  utils$2.electronApp.setAppUserModelId("com.mycanvas.app");
  electron.app.on("browser-window-created", (_, window2) => {
    utils$2.optimizer.watchWindowShortcuts(window2);
  });
  setupAllIpcRoutes();
  updateMenu();
  const mainWindow2 = createMainWindow();
  updater.setup(mainWindow2);
  electron.app.on("activate", function() {
    if (electron.BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
  initializePosthog();
  sendStartUpEvent({ startup_time: performance.now() - startup_time });
});
electron.app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    electron.app.quit();
  }
});
electron.app.on("before-quit", () => {
  posthog.shutdown();
});
